var require = meteorInstall({"server":{"dbapi":{"methods":{"accounts":{"accountManagement.js":function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/dbapi/methods/accounts/accountManagement.js                                                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
// docs for meteor default methods : http://docs.meteor.com/api/passwords.html
const meteor_1 = require('meteor/meteor');
const accounts_base_1 = require('meteor/accounts-base');
const check_1 = require('meteor/check');
const checkdbaccess_ts_1 = require('/server/dbapi/tools/checkdbaccess.ts');
const index_1 = require("/imports/api/index");
if (meteor_1.Meteor.isServer) {
    meteor_1.Meteor.methods({
        'isUserExistInDB'(email) {
            // --------------------------------------------------------------
            // the response object for client with feedback and data
            // codes :
            // 999 = unknown email address.
            // 404 = Datbase level problem or Unknown error or exceptions
            // 100 = user already exists;
            // ---------------------------------------------------------------
            var response = {
                feedback: "Unknown error while processing request. Please try again.",
                code: 404
            };
            var user = meteor_1.Meteor.users.findOne({ "emails.address": email });
            if (user !== undefined) {
                // console.log("user found");
                //user found
                response.code = 100;
                response.feedback = "This email already registered in the system";
                return response;
            }
            else if (user == undefined) {
                // console.log("user not found");
                //user not found
                response.code = 999;
                response.feedback = "This email doesn't exist in DB";
                return response;
            }
            else {
                return response;
            }
        },
        'getExistingUserData'(email) {
            // --------------------------------------------------------------
            // the response object for client with feedback and data
            // codes :
            // 999 = unknown email address.
            // 404 = Datbase level problem or Unknown error or exceptions
            // 200 = user already exists;
            // ---------------------------------------------------------------
            var response = {
                feedback: "Unknown error while processing request. Please try again.",
                code: 404,
                userData: undefined
            };
            var user = meteor_1.Meteor.users.findOne({ "emails.address": email });
            if (user !== undefined) {
                // console.log("user found");
                //user found now we get user data from profileDB
                let userData = index_1.ProfileDB.findOne({ "userAccountID": user._id });
                response.userData = {
                    firstName: userData.firstName,
                    lastName: userData.lastName,
                    occupation: userData.occupation,
                    campus: userData.campus,
                    role: user["role"],
                    obfID: user["obfID"],
                    lastLogin: user["profile"]["lastLogin"],
                    userAccountID: user._id,
                    profileID: userData._id
                };
                response.code = 200;
                response.feedback = "User exist in Badgelor";
                return response;
            }
            else if (user == undefined) {
                // console.log("user not found");
                //user not found
                response.code = 999;
                response.feedback = "This email doesn't exist in DB";
                return response;
            }
            else {
                return response;
            }
        },
        'isUserTypeAdmin'() {
            // this method is needed for client to know if a user type is admin or not
            // user role will never be published to  client
            // codes :
            // 100 = user is an admin
            // 999 = not admin
            if (!this.userId) {
                return 999;
            }
            var dbAccessChecker = new checkdbaccess_ts_1.Checkdbaccess();
            if (dbAccessChecker.isRoleAdmin(this.userId) === true) {
                return 100;
            }
            else {
                return 999;
            }
        },
        'isUserTypeApplicant'() {
            // this method is needed for client to know if a user type is applicant or not
            // user role will never be published to  client
            // codes :
            // 100 = user is an applicant
            // 999 = not applicant
            if (!this.userId) {
                return 999;
            }
            var dbAccessChecker = new checkdbaccess_ts_1.Checkdbaccess();
            if (dbAccessChecker.isRoleApplicant(this.userId) === true) {
                return 100;
            }
            else {
                return 999;
            }
        },
        'createMyProfile'(data) {
            // add new user profile via signup form ( user: applicant )
            // TODO : this function is called when the user create new account and instanctly logs in for the first time.
            // we need to create another method - when admin creates a user from admin panel
            // (when new user is not singed in , so no valid userID)
            if (!this.userId) {
                return true;
            }
            //first finding the profile of this requesting user.
            var myProfileDB = index_1.ProfileDB.findOne({ "userAccountID": this.userId });
            //console.log(myProfileDB);
            if (myProfileDB === undefined) {
                //the ProfileDB for this user has not been created yet. so creating a new one
                var profileID = index_1.ProfileDB.collection.insert({
                    userAccountID: this.userId
                });
                // now the db is created, so updating the data of this collection
                updateProfile(data, profileID);
                return true;
            }
            else {
                // profileDB exist for this user so making updates
                updateProfile(data, myProfileDB._id);
            }
            // the function to update the ProfileDB
            function updateProfile(data, profileID) {
                index_1.ProfileDB.collection.update(profileID, {
                    $set: {
                        firstName: data.firstName,
                        lastName: data.lastName,
                        campus: data.campus,
                        occupation: data.occupation,
                        imageURL: data.imageURL
                    }
                });
            } // end function updateProfile def
        },
        'addNewUserByAdmin'(registerData, profileData) {
            // --------------------------------------------------------------
            // the response object for client with feedback and data
            // codes :
            // 999 = access denied.
            // 404 = Datbase level problem or Unknown error or exceptions
            // 200 = success;
            // ---------------------------------------------------------------
            var response = {
                feedback: "Unknown error while processing. Please try again.",
                code: 404
            };
            // -------------------------------------------------------
            // access rules :
            // admin can add any number of user
            // other type of users will have no access to this feature
            // --------------------------------------------------------
            // step 1: request validation, basic filtering
            if (!this.userId) {
                response.code = 999;
                response.feedback = "Access denied";
                return response;
            }
            check_1.check(registerData, Object);
            // step 2 : checking DB access rights
            // a flag to make sure this requesting user has the right access to modify this data
            var userHasAccessRights = false;
            var userIsAdmin = false;
            var dbAccessChecker = new checkdbaccess_ts_1.Checkdbaccess();
            userIsAdmin = dbAccessChecker.isRoleAdmin(this.userId); //returns true if admin
            userHasAccessRights = userIsAdmin;
            if (userHasAccessRights === true) {
                try {
                    var userId = accounts_base_1.Accounts.createUser({
                        email: registerData.email,
                        password: registerData.password,
                        profile: {
                            lastLogin: 'Never'
                        }
                    });
                    // now setting up user role
                    setUserRole(registerData.email, registerData.role);
                    // next create a profile for the new user
                    var profileID = index_1.ProfileDB.collection.insert({
                        userAccountID: userId,
                        firstName: profileData.firstName,
                        lastName: profileData.lastName,
                        campus: profileData.campus,
                        occupation: profileData.occupation,
                        imageURL: profileData.imageURL
                    });
                    response.code = 200;
                    response.feedback = "new account created";
                    return response;
                }
                catch (e) {
                    response.code = 999;
                    response.feedback = "Error: " + e;
                    return response;
                }
            } // end if if(userHasAccessRights === true)
            else {
                // no Access right
                response.code = 999;
                response.feedback = "Access denied";
            }
            function setUserRole(email, role) {
                var userDB = meteor_1.Meteor.users.findOne({ "emails.address": email });
                meteor_1.Meteor.users.update(userDB._id, {
                    $set: {
                        "role": role,
                        "obfID": ""
                    }
                });
            }
            return response;
        },
        'deleteUserByAdmin'(profile) {
            // --------------------------------------------------------------
            // the response object for client with feedback and data
            // codes :
            // 999 = access denied.
            // 404 = Datbase level problem or Unknown error or exceptions
            // 200 = success;
            // ---------------------------------------------------------------
            var response = {
                feedback: "Unknown error while processing. Please try again.",
                code: 404
            };
            // -------------------------------------------------------
            // access rules :
            // admin can add any number of user
            // other type of users will have no access to this feature
            // --------------------------------------------------------
            // step 1: request validation, basic filtering
            if (!this.userId) {
                response.code = 999;
                response.feedback = "Access denied";
                return response;
            }
            check_1.check(profile, Object);
            // step 2 : checking DB access rights
            // a flag to make sure this requesting user has the right access to modify this data
            var userHasAccessRights = false;
            var userIsAdmin = false;
            var dbAccessChecker = new checkdbaccess_ts_1.Checkdbaccess();
            userIsAdmin = dbAccessChecker.isRoleAdmin(this.userId); //returns true if admin
            userHasAccessRights = userIsAdmin;
            if (userHasAccessRights === true) {
                try {
                    meteor_1.Meteor.users.remove(profile.userAccountID);
                    index_1.ProfileDB.remove(profile._id);
                    response.code = 200;
                    response.feedback = "User Deleted";
                    return response;
                }
                catch (e) {
                    response.code = 999;
                    response.feedback = "Error: " + e;
                    return response;
                }
            }
            else {
                // no Access right
                response.code = 999;
                response.feedback = "Access denied";
            }
            return response;
        },
        'setUserRole'(email, role) {
            var response = {
                feedback: "Unknown error while processing reset. Please try again.",
                code: 404
            };
            var userDB = meteor_1.Meteor.users.findOne({ "emails.address": email });
            if (userDB != undefined) {
                meteor_1.Meteor.users.update(userDB._id, {
                    $set: {
                        "role": role,
                        "obfID": ""
                    }
                });
                response.feedback = role + " role assigned";
                response.code = 200;
                return response;
            }
            return response;
        },
        'updateLastLoginStatus'() {
            var response = {
                feedback: "Unknown error while processing. Please try again.",
                code: 404
            };
            try {
                meteor_1.Meteor.users.update({ _id: this.userId }, {
                    $set: {
                        "profile.lastLogin": new Date()
                    }
                });
                response.code = 200;
                response.feedback = "last login time updated";
                return response;
            }
            catch (e) {
                response.code = 999;
                response.feedback = "Error: " + e;
                return response;
            }
            // console.log("user status updated");
        },
        'insertUserObfID'(creatorEmail, creatorObfID) {
            console.log(creatorObfID);
            var response = {
                feedback: "Unknown error while processing reset. Please try again.",
                code: 404
            };
            var userDB = meteor_1.Meteor.users.findOne({ "emails.address": creatorEmail });
            if (userDB != undefined) {
                meteor_1.Meteor.users.update(userDB._id, {
                    $set: {
                        "obfID": creatorObfID
                    }
                });
                response.feedback = "Creator details updated, you can import badge now.";
                response.code = 200;
                return response;
            }
            else {
                response.feedback = "Please add this user into badgelor first.";
                response.code = 999;
            }
            return response;
        }
    }); // END of meteor methods
} // END of Meteor.isServer

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"metadata":{"badgeManagement.js":function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/dbapi/methods/metadata/badgeManagement.js                                                                  //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
const meteor_1 = require('meteor/meteor');
const check_1 = require('meteor/check');
const checkdbaccess_ts_1 = require('/server/dbapi/tools/checkdbaccess.ts');
const index_1 = require("/imports/api/index");
if (meteor_1.Meteor.isServer) {
    meteor_1.Meteor.methods({
        'insertMetadataToLocalDB'(data) {
            // --------------------------------------------------------------
            // the response object for client with feedback and data
            // codes :
            // 999 = access denied.
            // 404 = Datbase level problem or Unknown error or exceptions
            // 200 = success;
            // ---------------------------------------------------------------
            var response = {
                feedback: "Unknown error while processing. Please try again.",
                code: 404
            };
            // -------------------------------------------------------
            // access rules :
            // admin and creator can add any number of badges
            // other type of users will have no access to this feature
            // --------------------------------------------------------
            // step 1: request validation, basic filtering
            if (!this.userId) {
                response.code = 999;
                response.feedback = "Access denied";
                return response;
            }
            check_1.check(data, Object);
            // step 2 : checking DB access rights
            // a flag to make sure this requesting user has the right access to modify this data
            var userHasAccessRights = false;
            var userIsAdmin = false;
            var userIsCreator = false;
            var dbAccessChecker = new checkdbaccess_ts_1.Checkdbaccess();
            userIsAdmin = dbAccessChecker.isRoleAdmin(this.userId); //returns true if admin
            userIsCreator = dbAccessChecker.isRoleCreator(this.userId); //returns true if creator
            if (userIsAdmin || userIsCreator) {
                userHasAccessRights = true;
            }
            // userHasAccessRights = userIsAdmin;
            if (userHasAccessRights === true) {
                // step : 3 updating data into the DB
                index_1.MetadataDB.collection.insert({
                    badge_id: data.badge_id,
                    courses: data.courses,
                    issuers: data.issuers,
                    keywords: data.keywords,
                    levelID: data.levelID,
                    competencyID: data.competencyID,
                    tools: data.tools,
                    creator: data.creator,
                    applicants: data.applicants,
                    earners: data.earners,
                    createdAt: new Date()
                }); //end insert
                response.code = 200;
                response.feedback = "New Badge Creation successful!";
                return response;
            } // end if if(userHasAccessRights === true)
            else {
                // no Access right
                response.code = 999;
                response.feedback = "Access denied";
            }
            return response;
        },
        'updateMetadata'(data) {
            // --------------------------------------------------------------
            // the response object for client with feedback and data
            // codes :
            // 999 = access denied.
            // 404 = Datbase level problem or Unknown error or exceptions
            // 200 = success;
            // ---------------------------------------------------------------
            var response = {
                feedback: "Unknown error while processing. Please try again.",
                code: 404
            };
            // -------------------------------------------------------
            // access rules :
            // admin and creator can add any number of badges
            // other type of users will have no access to this feature
            // --------------------------------------------------------
            // step 1: request validation, basic filtering
            if (!this.userId) {
                response.code = 999;
                response.feedback = "Access denied";
                return response;
            }
            check_1.check(data, Object);
            // step 2 : checking DB access rights
            // a flag to make sure this requesting user has the right access to modify this data
            var userHasAccessRights = false;
            var userIsAdmin = false;
            var userIsCreator = false;
            var dbAccessChecker = new checkdbaccess_ts_1.Checkdbaccess();
            userIsAdmin = dbAccessChecker.isRoleAdmin(this.userId); //returns true if admin
            userIsCreator = dbAccessChecker.isRoleCreator(this.userId); //returns true if creator
            if (userIsAdmin || userIsCreator) {
                userHasAccessRights = true;
            }
            // userHasAccessRights = userIsAdmin;
            if (userHasAccessRights === true) {
                // step : 3 updating data into the DB
                console.log(data);
                var badgeDB = index_1.MetadataDB.findOne({ "badge_id": data.badge_id });
                if (badgeDB != undefined) {
                    index_1.MetadataDB.collection.update(badgeDB._id, {
                        $set: {
                            courses: data.courses,
                            issuers: data.issuers,
                            keywords: data.keywords,
                            levelID: data.levelID,
                            competencyID: data.competencyID,
                            tools: data.tools,
                            creator: data.creator,
                            applicants: data.applicants,
                            earners: data.earners,
                            createdAt: new Date()
                        }
                    }); // end update
                }
                response.code = 200;
                response.feedback = "Badge Update successful!";
                return response;
            } // end if if(userHasAccessRights === true)
            else {
                // no Access right
                response.code = 999;
                response.feedback = "Access denied";
            }
            return response;
        },
        'importNewBadgeFromOBF'(data) {
            // --------------------------------------------------------------
            // the response object for client with feedback and data
            // codes :
            // 999 = access denied.
            // 404 = Datbase level problem or Unknown error or exceptions
            // 200 = success;
            // ---------------------------------------------------------------
            var response = {
                feedback: "Unknown error while processing. Please try again.",
                code: 404
            };
            // -------------------------------------------------------
            // access rules :
            // admin and creator can add any number of badges
            // other type of users will have no access to this feature
            // --------------------------------------------------------
            // step 1: request validation, basic filtering
            if (!this.userId) {
                response.code = 999;
                response.feedback = "Access denied";
                return response;
            }
            check_1.check(data, Object);
            // step 2 : checking DB access rights
            // a flag to make sure this requesting user has the right access to modify this data
            var userHasAccessRights = false;
            var userIsAdmin = false;
            var userIsCreator = false;
            var dbAccessChecker = new checkdbaccess_ts_1.Checkdbaccess();
            userIsAdmin = dbAccessChecker.isRoleAdmin(this.userId); //returns true if admin
            userIsCreator = dbAccessChecker.isRoleCreator(this.userId); //returns true if creator
            if (userIsAdmin || userIsCreator) {
                userHasAccessRights = true;
            }
            if (userHasAccessRights === true) {
                // step : 3 updating data into the DB
                index_1.MetadataDB.collection.insert({
                    badge_id: data.badge_id,
                    courses: data.courses,
                    issuers: data.issuers,
                    keywords: data.keywords,
                    levelID: data.levelID,
                    competencyID: data.competencyID,
                    tools: data.tools,
                    creator: data.creator,
                    applicants: data.applicants,
                    earners: data.earners,
                    createdAt: new Date()
                }); //end insert
                response.code = 200;
                response.feedback = "New Badge Import successful!";
                return response;
            } // end if if(userHasAccessRights === true)
            else {
                // no Access right
                response.code = 999;
                response.feedback = "Access denied";
            }
            return response;
        },
        'getNumberOfBadges'() {
            return index_1.MetadataDB.collection.find().count();
        },
        'missingMetadataCount'() {
            return index_1.MetadataDB.collection.find({ "levelID": "" }).count();
        }
    }); // END of meteor methods
} // END of Meteor.isServer

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"campusManagement.js":function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/dbapi/methods/metadata/campusManagement.js                                                                 //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
// docs for meteor default methods : http://docs.meteor.com/api/passwords.html
const meteor_1 = require('meteor/meteor');
const check_1 = require('meteor/check');
const checkdbaccess_ts_1 = require('/server/dbapi/tools/checkdbaccess.ts');
const index_1 = require("/imports/api/index");
if (meteor_1.Meteor.isServer) {
    meteor_1.Meteor.methods({
        'isCampusExistInDB'(campusName) {
            // --------------------------------------------------------------
            // the response object for client with feedback and data
            // codes :
            // 999 = unknown name.
            // 404 = Datbase level problem or Unknown error or exceptions
            // 200 = campus name already exists;
            // ---------------------------------------------------------------
            var response = {
                feedback: "Unknown error while processing request. Please try again.",
                code: 404
            };
            var campusNameinDB = index_1.CampusDB.findOne({ "name": campusName });
            if (campusNameinDB !== undefined) {
                response.code = 200;
                response.feedback = "This Campus is already registered in the system";
                return response;
            }
            else if (campusNameinDB === undefined) {
                response.code = 999;
                response.feedback = "This Campus is not registered in the system";
                return response;
            }
            else {
                return response;
            }
        },
        'addNewCampus'(data) {
            // --------------------------------------------------------------
            // the response object for client with feedback and data
            // codes :
            // 999 = access denied.
            // 404 = Datbase level problem or Unknown error or exceptions
            // 200 = success;
            // ---------------------------------------------------------------
            var response = {
                feedback: "Unknown error while processing. Please try again.",
                code: 404
            };
            // -------------------------------------------------------
            // access rules :
            // admin can add any number of campus
            // other type of users will have no access to this feature
            // --------------------------------------------------------
            // step 1: request validation, basic filtering
            if (!this.userId) {
                response.code = 999;
                response.feedback = "Access denied";
                return response;
            }
            check_1.check(data, Object);
            // step 2 : checking DB access rights
            // a flag to make sure this requesting user has the right access to modify this data
            var userHasAccessRights = false;
            var userIsAdmin = false;
            var dbAccessChecker = new checkdbaccess_ts_1.Checkdbaccess();
            userIsAdmin = dbAccessChecker.isRoleAdmin(this.userId); //returns true if admin
            userHasAccessRights = userIsAdmin;
            if (userHasAccessRights === true) {
                // step : 3 updating data into the DB
                index_1.CampusDB.collection.insert({
                    name: data.name,
                    description: data.description,
                    createdBy: meteor_1.Meteor.user().emails[0].address,
                    createdAt: new Date(),
                }); //end insert
                response.code = 200;
                response.feedback = "New Campus Creation successfull!";
                return response;
            } // end if if(userHasAccessRights === true)
            else {
                // no Access right
                response.code = 999;
                response.feedback = "Access denied";
            }
            return response;
        },
        'updateCampus'(data) {
            // --------------------------------------------------------------
            // the response object for client with feedback and data
            // codes :
            // 999 = access denied.
            // 404 = Datbase level problem or Unknown error or exceptions
            // 200 = success;
            // ---------------------------------------------------------------
            var response = {
                feedback: "Unknown error while processing. Please try again.",
                code: 404
            };
            // -------------------------------------------------------
            // access rules :
            // admin can edit any number of campus
            // other type of users will have no access to this feature
            // --------------------------------------------------------
            // step 1: request validation, basic filtering
            if (!this.userId) {
                response.code = 999;
                response.feedback = "Access denied";
                return response;
            }
            check_1.check(data, Object);
            // step 2 : checking DB access rights
            // a flag to make sure this requesting user has the right access to modify this data
            var userHasAccessRights = false;
            var userIsAdmin = false;
            var dbAccessChecker = new checkdbaccess_ts_1.Checkdbaccess();
            userIsAdmin = dbAccessChecker.isRoleAdmin(this.userId); //returns true if admin
            userHasAccessRights = userIsAdmin;
            if (userHasAccessRights === true) {
                // step : 3 updating data into the DB
                index_1.CampusDB.collection.update(data._id, {
                    $set: {
                        name: data.name,
                        description: data.description,
                        createdBy: meteor_1.Meteor.user().emails[0].address,
                        createdAt: new Date(),
                    }
                }); // end update
                response.code = 200;
                response.feedback = "Campus Update successfull!";
                return response;
            } // end if if(userHasAccessRights === true)
            else {
                // no Access right
                response.code = 999;
                response.feedback = "Access denied";
            }
            return response;
        },
        'isCampusHasFaculty'(campusID) {
            // --------------------------------------------------------------
            // the response object for client with feedback and data
            // codes :
            // 999 = campus has no faculty.
            // 404 = Datbase level problem or Unknown error or exceptions
            // 200 = campus has faculty
            // ---------------------------------------------------------------
            var response = {
                feedback: "Unknown error while processing request. Please try again.",
                code: 404
            };
            var noOfFaculty = index_1.FacultyDB.collection.find({ "campusID": campusID }).count();
            if (noOfFaculty !== undefined && noOfFaculty > 0) {
                response.code = 999;
                response.feedback = "This Campus has faculty. Delete faculties of this campus first.";
                return response;
            }
            else if (noOfFaculty === undefined || noOfFaculty === 0) {
                response.code = 200;
                response.feedback = "This Campus doesn't have any faculty";
                return response;
            }
            else {
                return response;
            }
        },
        'deleteCampus'(data) {
            // --------------------------------------------------------------
            // the response object for client with feedback and data
            // codes :
            // 999 = access denied.
            // 404 = Datbase level problem or Unknown error or exceptions
            // 200 = success;
            // ---------------------------------------------------------------
            var response = {
                feedback: "Unknown error while processing. Please try again.",
                code: 404
            };
            // -------------------------------------------------------
            // access rules :
            // admin can edit any number of campus
            // other type of users will have no access to this feature
            // --------------------------------------------------------
            // step 1: request validation, basic filtering
            if (!this.userId) {
                response.code = 999;
                response.feedback = "Access denied";
                return response;
            }
            check_1.check(data, Object);
            // step 2 : checking DB access rights
            // a flag to make sure this requesting user has the right access to modify this data
            var userHasAccessRights = false;
            var userIsAdmin = false;
            var dbAccessChecker = new checkdbaccess_ts_1.Checkdbaccess();
            userIsAdmin = dbAccessChecker.isRoleAdmin(this.userId); //returns true if admin
            userHasAccessRights = userIsAdmin;
            if (userHasAccessRights === true) {
                index_1.CampusDB.collection.remove(data._id);
                response.code = 200;
                response.feedback = "Campus delete successfull!";
                return response;
            }
            else {
                // no Access right
                response.code = 999;
                response.feedback = "Access denied";
            }
            return response;
        },
        'getAllCampusName'() {
            return index_1.CampusDB.find({}).fetch();
        }
    }); // END of meteor methods
} // END of Meteor.isServer

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"competencyManagement.js":function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/dbapi/methods/metadata/competencyManagement.js                                                             //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
// docs for meteor default methods : http://docs.meteor.com/api/passwords.html
const meteor_1 = require('meteor/meteor');
const check_1 = require('meteor/check');
const checkdbaccess_ts_1 = require('/server/dbapi/tools/checkdbaccess.ts');
const index_1 = require("/imports/api/index");
if (meteor_1.Meteor.isServer) {
    meteor_1.Meteor.methods({
        'isCompetencyExistInDB'(competencyName) {
            // --------------------------------------------------------------
            // the response object for client with feedback and data
            // codes :
            // 999 = unknown name.
            // 404 = Datbase level problem or Unknown error or exceptions
            // 200 = competency name already exists;
            // ---------------------------------------------------------------
            var response = {
                feedback: "Unknown error while processing request. Please try again.",
                code: 404
            };
            var competencyNameinDB = index_1.CompetencyDB.findOne({ "name": competencyName });
            if (competencyNameinDB !== undefined) {
                response.code = 200;
                response.feedback = "This competency is already registered in the system";
                return response;
            }
            else if (competencyNameinDB === undefined) {
                response.code = 999;
                response.feedback = "This competency is not registered in the system";
                return response;
            }
            else {
                return response;
            }
        },
        'addNewCompetency'(data) {
            // --------------------------------------------------------------
            // the response object for client with feedback and data
            // codes :
            // 999 = access denied.
            // 404 = Datbase level problem or Unknown error or exceptions
            // 200 = success;
            // ---------------------------------------------------------------
            var response = {
                feedback: "Unknown error while processing. Please try again.",
                code: 404
            };
            // -------------------------------------------------------
            // access rules :
            // admin can add any number of competency
            // other type of users will have no access to this feature
            // --------------------------------------------------------
            // step 1: request validation, basic filtering
            if (!this.userId) {
                response.code = 999;
                response.feedback = "Access denied";
                return response;
            }
            check_1.check(data, Object);
            // step 2 : checking DB access rights
            // a flag to make sure this requesting user has the right access to modify this data
            var userHasAccessRights = false;
            var userIsAdmin = false;
            var dbAccessChecker = new checkdbaccess_ts_1.Checkdbaccess();
            userIsAdmin = dbAccessChecker.isRoleAdmin(this.userId); //returns true if admin
            userHasAccessRights = userIsAdmin;
            if (userHasAccessRights === true) {
                // step : 3 updating data into the DB
                index_1.CompetencyDB.collection.insert({
                    name: data.name,
                    description: data.description,
                    createdBy: meteor_1.Meteor.user().emails[0].address,
                    createdAt: new Date(),
                }); //end insert
                response.code = 200;
                response.feedback = "New Competency Creation successfull!";
                return response;
            } // end if if(userHasAccessRights === true)
            else {
                // no Access right
                response.code = 999;
                response.feedback = "Access denied";
            }
            return response;
        },
        'updateCompetency'(data) {
            // --------------------------------------------------------------
            // the response object for client with feedback and data
            // codes :
            // 999 = access denied.
            // 404 = Datbase level problem or Unknown error or exceptions
            // 200 = success;
            // ---------------------------------------------------------------
            var response = {
                feedback: "Unknown error while processing. Please try again.",
                code: 404
            };
            // -------------------------------------------------------
            // access rules :
            // admin can edit any number of level
            // other type of users will have no access to this feature
            // --------------------------------------------------------
            // step 1: request validation, basic filtering
            if (!this.userId) {
                response.code = 999;
                response.feedback = "Access denied";
                return response;
            }
            check_1.check(data, Object);
            // step 2 : checking DB access rights
            // a flag to make sure this requesting user has the right access to modify this data
            var userHasAccessRights = false;
            var userIsAdmin = false;
            var dbAccessChecker = new checkdbaccess_ts_1.Checkdbaccess();
            userIsAdmin = dbAccessChecker.isRoleAdmin(this.userId); //returns true if admin
            userHasAccessRights = userIsAdmin;
            if (userHasAccessRights === true) {
                // step : 3 updating data into the DB
                index_1.CompetencyDB.collection.update(data._id, {
                    $set: {
                        name: data.name,
                        description: data.description,
                        createdBy: meteor_1.Meteor.user().emails[0].address,
                        createdAt: new Date(),
                    }
                }); // end update
                response.code = 200;
                response.feedback = "Level Update successfull!";
                return response;
            } // end if if(userHasAccessRights === true)
            else {
                // no Access right
                response.code = 999;
                response.feedback = "Access denied";
            }
            return response;
        },
        'deleteCompetency'(data) {
            // --------------------------------------------------------------
            // the response object for client with feedback and data
            // codes :
            // 999 = access denied.
            // 404 = Datbase level problem or Unknown error or exceptions
            // 200 = success;
            // ---------------------------------------------------------------
            var response = {
                feedback: "Unknown error while processing. Please try again.",
                code: 404
            };
            // -------------------------------------------------------
            // access rules :
            // admin can edit any number of competency
            // other type of users will have no access to this feature
            // --------------------------------------------------------
            // step 1: request validation, basic filtering
            if (!this.userId) {
                response.code = 999;
                response.feedback = "Access denied";
                return response;
            }
            check_1.check(data, Object);
            // step 2 : checking DB access rights
            // a flag to make sure this requesting user has the right access to modify this data
            var userHasAccessRights = false;
            var userIsAdmin = false;
            var dbAccessChecker = new checkdbaccess_ts_1.Checkdbaccess();
            userIsAdmin = dbAccessChecker.isRoleAdmin(this.userId); //returns true if admin
            userHasAccessRights = userIsAdmin;
            if (userHasAccessRights === true) {
                index_1.CompetencyDB.collection.remove(data._id);
                response.code = 200;
                response.feedback = "Level delete successfull!";
                return response;
            }
            else {
                // no Access right
                response.code = 999;
                response.feedback = "Access denied";
            }
            return response;
        },
        'getAllCompetencyName'() {
            return index_1.CompetencyDB.find({}).fetch();
        }
    }); // END of meteor methods
} // END of Meteor.isServer

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"courseManagement.js":function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/dbapi/methods/metadata/courseManagement.js                                                                 //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
// docs for meteor default methods : http://docs.meteor.com/api/passwords.html
const meteor_1 = require('meteor/meteor');
const check_1 = require('meteor/check');
const checkdbaccess_ts_1 = require('/server/dbapi/tools/checkdbaccess.ts');
const index_1 = require("/imports/api/index");
if (meteor_1.Meteor.isServer) {
    meteor_1.Meteor.methods({
        'isCourseExistInDB'(courseName, campusID, facultyID, instituteID) {
            // --------------------------------------------------------------
            // the response object for client with feedback and data
            // codes :
            // 999 = unknown name.
            // 404 = Datbase level problem or Unknown error or exceptions
            // 200 = faculty name already exists;
            // ---------------------------------------------------------------
            var response = {
                feedback: "Unknown error while processing request. Please try again.",
                code: 404
            };
            var courseNameinDB = index_1.CourseDB.findOne({ "name": courseName, "campusID": campusID, "facultyID": facultyID, "instituteID": instituteID });
            if (courseNameinDB !== undefined) {
                response.code = 200;
                response.feedback = "This Course is already registered in the system";
                return response;
            }
            else if (courseNameinDB === undefined) {
                response.code = 999;
                response.feedback = "This Course is not registered in the system";
                return response;
            }
            else {
                return response;
            }
        },
        'addNewCourse'(data) {
            // --------------------------------------------------------------
            // the response object for client with feedback and data
            // codes :
            // 999 = access denied.
            // 404 = Datbase level problem or Unknown error or exceptions
            // 200 = success;
            // ---------------------------------------------------------------
            var response = {
                feedback: "Unknown error while processing. Please try again.",
                code: 404
            };
            // -------------------------------------------------------
            // access rules :
            // admin can add any number of faculty
            // other type of users will have no access to this feature
            // --------------------------------------------------------
            // step 1: request validation, basic filtering
            if (!this.userId) {
                response.code = 999;
                response.feedback = "Access denied";
                return response;
            }
            check_1.check(data, Object);
            // step 2 : checking DB access rights
            // a flag to make sure this requesting user has the right access to modify this data
            var userHasAccessRights = false;
            var userIsAdmin = false;
            var dbAccessChecker = new checkdbaccess_ts_1.Checkdbaccess();
            userIsAdmin = dbAccessChecker.isRoleAdmin(this.userId); //returns true if admin
            userHasAccessRights = userIsAdmin;
            if (userHasAccessRights === true) {
                // step : 3 updating data into the DB
                index_1.CourseDB.collection.insert({
                    name: data.name,
                    description: data.description,
                    campusID: data.campusID,
                    facultyID: data.facultyID,
                    instituteID: data.instituteID,
                    createdBy: meteor_1.Meteor.user().emails[0].address,
                    createdAt: new Date(),
                }); //end insert
                response.code = 200;
                response.feedback = "New Course Creation successfull!";
                return response;
            } // end if if(userHasAccessRights === true)
            else {
                // no Access right
                response.code = 999;
                response.feedback = "Access denied";
            }
            return response;
        },
        'updateCourse'(data) {
            // --------------------------------------------------------------
            // the response object for client with feedback and data
            // codes :
            // 999 = access denied.
            // 404 = Datbase level problem or Unknown error or exceptions
            // 200 = success;
            // ---------------------------------------------------------------
            var response = {
                feedback: "Unknown error while processing. Please try again.",
                code: 404
            };
            // -------------------------------------------------------
            // access rules :
            // admin can edit any number of campus
            // other type of users will have no access to this feature
            // --------------------------------------------------------
            // step 1: request validation, basic filtering
            if (!this.userId) {
                response.code = 999;
                response.feedback = "Access denied";
                return response;
            }
            check_1.check(data, Object);
            // step 2 : checking DB access rights
            // a flag to make sure this requesting user has the right access to modify this data
            var userHasAccessRights = false;
            var userIsAdmin = false;
            var dbAccessChecker = new checkdbaccess_ts_1.Checkdbaccess();
            userIsAdmin = dbAccessChecker.isRoleAdmin(this.userId); //returns true if admin
            userHasAccessRights = userIsAdmin;
            if (userHasAccessRights === true) {
                // step : 3 updating data into the DB
                index_1.CourseDB.collection.update(data._id, {
                    $set: {
                        name: data.name,
                        description: data.description,
                        campusID: data.campusID,
                        facultyID: data.facultyID,
                        instituteID: data.instituteID,
                        createdBy: meteor_1.Meteor.user().emails[0].address,
                        createdAt: new Date(),
                    }
                }); // end update
                response.code = 200;
                response.feedback = "Course Update successfull!";
                return response;
            } // end if if(userHasAccessRights === true)
            else {
                // no Access right
                response.code = 999;
                response.feedback = "Access denied";
            }
            return response;
        },
        'deleteCourse'(data) {
            // --------------------------------------------------------------
            // the response object for client with feedback and data
            // codes :
            // 999 = access denied.
            // 404 = Datbase level problem or Unknown error or exceptions
            // 200 = success;
            // ---------------------------------------------------------------
            var response = {
                feedback: "Unknown error while processing. Please try again.",
                code: 404
            };
            // -------------------------------------------------------
            // access rules :
            // admin can edit any number of campus
            // other type of users will have no access to this feature
            // --------------------------------------------------------
            // step 1: request validation, basic filtering
            if (!this.userId) {
                response.code = 999;
                response.feedback = "Access denied";
                return response;
            }
            check_1.check(data, Object);
            // step 2 : checking DB access rights
            // a flag to make sure this requesting user has the right access to modify this data
            var userHasAccessRights = false;
            var userIsAdmin = false;
            var dbAccessChecker = new checkdbaccess_ts_1.Checkdbaccess();
            userIsAdmin = dbAccessChecker.isRoleAdmin(this.userId); //returns true if admin
            userHasAccessRights = userIsAdmin;
            if (userHasAccessRights === true) {
                index_1.CourseDB.collection.remove(data._id);
                response.code = 200;
                response.feedback = "Course delete successfull!";
                return response;
            }
            else {
                // no Access right
                response.code = 999;
                response.feedback = "Access denied";
            }
            return response;
        }
    }); // END of meteor methods
} // END of Meteor.isServer

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"facultyManagement.js":function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/dbapi/methods/metadata/facultyManagement.js                                                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
// docs for meteor default methods : http://docs.meteor.com/api/passwords.html
const meteor_1 = require('meteor/meteor');
const check_1 = require('meteor/check');
const checkdbaccess_ts_1 = require('/server/dbapi/tools/checkdbaccess.ts');
const index_1 = require("/imports/api/index");
if (meteor_1.Meteor.isServer) {
    meteor_1.Meteor.methods({
        'isFacultyExistInDB'(facultyName, campusID) {
            // --------------------------------------------------------------
            // the response object for client with feedback and data
            // codes :
            // 999 = unknown name.
            // 404 = Datbase level problem or Unknown error or exceptions
            // 200 = faculty name already exists;
            // ---------------------------------------------------------------
            var response = {
                feedback: "Unknown error while processing request. Please try again.",
                code: 404
            };
            var faclutyNameinDB = index_1.FacultyDB.findOne({ "name": facultyName, "campusID": campusID });
            if (faclutyNameinDB !== undefined) {
                response.code = 200;
                response.feedback = "This Faculty is already registered in the system";
                return response;
            }
            else if (faclutyNameinDB === undefined) {
                response.code = 999;
                response.feedback = "This Faculty is not registered in the system";
                return response;
            }
            else {
                return response;
            }
        },
        'addNewFaculty'(data) {
            // --------------------------------------------------------------
            // the response object for client with feedback and data
            // codes :
            // 999 = access denied.
            // 404 = Datbase level problem or Unknown error or exceptions
            // 200 = success;
            // ---------------------------------------------------------------
            var response = {
                feedback: "Unknown error while processing. Please try again.",
                code: 404
            };
            // -------------------------------------------------------
            // access rules :
            // admin can add any number of faculty
            // other type of users will have no access to this feature
            // --------------------------------------------------------
            // step 1: request validation, basic filtering
            if (!this.userId) {
                response.code = 999;
                response.feedback = "Access denied";
                return response;
            }
            check_1.check(data, Object);
            // step 2 : checking DB access rights
            // a flag to make sure this requesting user has the right access to modify this data
            var userHasAccessRights = false;
            var userIsAdmin = false;
            var dbAccessChecker = new checkdbaccess_ts_1.Checkdbaccess();
            userIsAdmin = dbAccessChecker.isRoleAdmin(this.userId); //returns true if admin
            userHasAccessRights = userIsAdmin;
            if (userHasAccessRights === true) {
                // step : 3 updating data into the DB
                index_1.FacultyDB.collection.insert({
                    name: data.name,
                    description: data.description,
                    campusID: data.campusID,
                    createdBy: meteor_1.Meteor.user().emails[0].address,
                    createdAt: new Date(),
                }); //end insert
                response.code = 200;
                response.feedback = "New Faculty Creation successful!";
                return response;
            } // end if if(userHasAccessRights === true)
            else {
                // no Access right
                response.code = 999;
                response.feedback = "Access denied";
            }
            return response;
        },
        'updateFaculty'(data) {
            // --------------------------------------------------------------
            // the response object for client with feedback and data
            // codes :
            // 999 = access denied.
            // 404 = Datbase level problem or Unknown error or exceptions
            // 200 = success;
            // ---------------------------------------------------------------
            var response = {
                feedback: "Unknown error while processing. Please try again.",
                code: 404
            };
            // -------------------------------------------------------
            // access rules :
            // admin can edit any number of campus
            // other type of users will have no access to this feature
            // --------------------------------------------------------
            // step 1: request validation, basic filtering
            if (!this.userId) {
                response.code = 999;
                response.feedback = "Access denied";
                return response;
            }
            check_1.check(data, Object);
            // step 2 : checking DB access rights
            // a flag to make sure this requesting user has the right access to modify this data
            var userHasAccessRights = false;
            var userIsAdmin = false;
            var dbAccessChecker = new checkdbaccess_ts_1.Checkdbaccess();
            userIsAdmin = dbAccessChecker.isRoleAdmin(this.userId); //returns true if admin
            userHasAccessRights = userIsAdmin;
            if (userHasAccessRights === true) {
                // step : 3 updating data into the DB
                index_1.FacultyDB.collection.update(data._id, {
                    $set: {
                        name: data.name,
                        description: data.description,
                        campusID: data.campusID,
                        createdBy: meteor_1.Meteor.user().emails[0].address,
                        createdAt: new Date(),
                    }
                }); // end update
                response.code = 200;
                response.feedback = "Campus Update successfull!";
                return response;
            } // end if if(userHasAccessRights === true)
            else {
                // no Access right
                response.code = 999;
                response.feedback = "Access denied";
            }
            return response;
        },
        'isFacultyHasInstitute'(facultyID) {
            // --------------------------------------------------------------
            // the response object for client with feedback and data
            // codes :
            // 999 = faculty has institute.
            // 404 = Datbase level problem or Unknown error or exceptions
            // 200 = faculty has no institute
            // ---------------------------------------------------------------
            var response = {
                feedback: "Unknown error while processing request. Please try again.",
                code: 404
            };
            var noOfInstitute = index_1.InstituteDB.collection.find({ "facultyID": facultyID }).count();
            if (noOfInstitute !== undefined && noOfInstitute > 0) {
                response.code = 999;
                response.feedback = "This Faculty has Institute. Delete institutes of this faculty first.";
                return response;
            }
            else if (noOfInstitute === undefined || noOfInstitute === 0) {
                response.code = 200;
                response.feedback = "This Faculty doesn't have any institute";
                return response;
            }
            else {
                return response;
            }
        },
        'deleteFaculty'(data) {
            // --------------------------------------------------------------
            // the response object for client with feedback and data
            // codes :
            // 999 = access denied.
            // 404 = Datbase level problem or Unknown error or exceptions
            // 200 = success;
            // ---------------------------------------------------------------
            var response = {
                feedback: "Unknown error while processing. Please try again.",
                code: 404
            };
            // -------------------------------------------------------
            // access rules :
            // admin can edit any number of campus
            // other type of users will have no access to this feature
            // --------------------------------------------------------
            // step 1: request validation, basic filtering
            if (!this.userId) {
                response.code = 999;
                response.feedback = "Access denied";
                return response;
            }
            check_1.check(data, Object);
            // step 2 : checking DB access rights
            // a flag to make sure this requesting user has the right access to modify this data
            var userHasAccessRights = false;
            var userIsAdmin = false;
            var dbAccessChecker = new checkdbaccess_ts_1.Checkdbaccess();
            userIsAdmin = dbAccessChecker.isRoleAdmin(this.userId); //returns true if admin
            userHasAccessRights = userIsAdmin;
            if (userHasAccessRights === true) {
                index_1.FacultyDB.collection.remove(data._id);
                response.code = 200;
                response.feedback = "Campus delete successfull!";
                return response;
            }
            else {
                // no Access right
                response.code = 999;
                response.feedback = "Access denied";
            }
            return response;
        }
    }); // END of meteor methods
} // END of Meteor.isServer

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"instituteManagement.js":function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/dbapi/methods/metadata/instituteManagement.js                                                              //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
// docs for meteor default methods : http://docs.meteor.com/api/passwords.html
const meteor_1 = require('meteor/meteor');
const check_1 = require('meteor/check');
const checkdbaccess_ts_1 = require('/server/dbapi/tools/checkdbaccess.ts');
const index_1 = require("/imports/api/index");
if (meteor_1.Meteor.isServer) {
    meteor_1.Meteor.methods({
        'isInstituteExistInDB'(instituteName, campusID, facultyID) {
            // --------------------------------------------------------------
            // the response object for client with feedback and data
            // codes :
            // 999 = unknown name.
            // 404 = Datbase level problem or Unknown error or exceptions
            // 200 = faculty name already exists;
            // ---------------------------------------------------------------
            var response = {
                feedback: "Unknown error while processing request. Please try again.",
                code: 404
            };
            var instituteNameinDB = index_1.InstituteDB.findOne({ "name": instituteName, "campusID": campusID, "facultyID": facultyID });
            if (instituteNameinDB !== undefined) {
                response.code = 200;
                response.feedback = "This Institute is already registered in the system";
                return response;
            }
            else if (instituteNameinDB === undefined) {
                response.code = 999;
                response.feedback = "This Institute is not registered in the system";
                return response;
            }
            else {
                return response;
            }
        },
        'addNewInstitute'(data) {
            // --------------------------------------------------------------
            // the response object for client with feedback and data
            // codes :
            // 999 = access denied.
            // 404 = Datbase level problem or Unknown error or exceptions
            // 200 = success;
            // ---------------------------------------------------------------
            var response = {
                feedback: "Unknown error while processing. Please try again.",
                code: 404
            };
            // -------------------------------------------------------
            // access rules :
            // admin can add any number of faculty
            // other type of users will have no access to this feature
            // --------------------------------------------------------
            // step 1: request validation, basic filtering
            if (!this.userId) {
                response.code = 999;
                response.feedback = "Access denied";
                return response;
            }
            check_1.check(data, Object);
            // step 2 : checking DB access rights
            // a flag to make sure this requesting user has the right access to modify this data
            var userHasAccessRights = false;
            var userIsAdmin = false;
            var dbAccessChecker = new checkdbaccess_ts_1.Checkdbaccess();
            userIsAdmin = dbAccessChecker.isRoleAdmin(this.userId); //returns true if admin
            userHasAccessRights = userIsAdmin;
            if (userHasAccessRights === true) {
                // step : 3 updating data into the DB
                index_1.InstituteDB.collection.insert({
                    name: data.name,
                    description: data.description,
                    campusID: data.campusID,
                    facultyID: data.facultyID,
                    createdBy: meteor_1.Meteor.user().emails[0].address,
                    createdAt: new Date(),
                }); //end insert
                response.code = 200;
                response.feedback = "New Institute Creation successfull!";
                return response;
            } // end if if(userHasAccessRights === true)
            else {
                // no Access right
                response.code = 999;
                response.feedback = "Access denied";
            }
            return response;
        },
        'updateInstitute'(data) {
            // --------------------------------------------------------------
            // the response object for client with feedback and data
            // codes :
            // 999 = access denied.
            // 404 = Datbase level problem or Unknown error or exceptions
            // 200 = success;
            // ---------------------------------------------------------------
            var response = {
                feedback: "Unknown error while processing. Please try again.",
                code: 404
            };
            // -------------------------------------------------------
            // access rules :
            // admin can edit any number of campus
            // other type of users will have no access to this feature
            // --------------------------------------------------------
            // step 1: request validation, basic filtering
            if (!this.userId) {
                response.code = 999;
                response.feedback = "Access denied";
                return response;
            }
            check_1.check(data, Object);
            // step 2 : checking DB access rights
            // a flag to make sure this requesting user has the right access to modify this data
            var userHasAccessRights = false;
            var userIsAdmin = false;
            var dbAccessChecker = new checkdbaccess_ts_1.Checkdbaccess();
            userIsAdmin = dbAccessChecker.isRoleAdmin(this.userId); //returns true if admin
            userHasAccessRights = userIsAdmin;
            if (userHasAccessRights === true) {
                // step : 3 updating data into the DB
                index_1.InstituteDB.collection.update(data._id, {
                    $set: {
                        name: data.name,
                        description: data.description,
                        campusID: data.campusID,
                        facultyID: data.facultyID,
                        createdBy: meteor_1.Meteor.user().emails[0].address,
                        createdAt: new Date(),
                    }
                }); // end update
                response.code = 200;
                response.feedback = "Institute Update successfull!";
                return response;
            } // end if if(userHasAccessRights === true)
            else {
                // no Access right
                response.code = 999;
                response.feedback = "Access denied";
            }
            return response;
        },
        'isInstituteHasCourse'(instituteID) {
            // --------------------------------------------------------------
            // the response object for client with feedback and data
            // codes :
            // 999 = institute has course.
            // 404 = Datbase level problem or Unknown error or exceptions
            // 200 = institute has no course
            // ---------------------------------------------------------------
            var response = {
                feedback: "Unknown error while processing request. Please try again.",
                code: 404
            };
            var noOfCourses = index_1.CourseDB.collection.find({ "instituteID": instituteID }).count();
            if (noOfCourses !== undefined && noOfCourses > 0) {
                response.code = 999;
                response.feedback = "This Institute has course. Delete courses of this institute first.";
                return response;
            }
            else if (noOfCourses === undefined || noOfCourses === 0) {
                response.code = 200;
                response.feedback = "This Institute doesn't have any course";
                return response;
            }
            else {
                return response;
            }
        },
        'deleteInstitute'(data) {
            // --------------------------------------------------------------
            // the response object for client with feedback and data
            // codes :
            // 999 = access denied.
            // 404 = Datbase level problem or Unknown error or exceptions
            // 200 = success;
            // ---------------------------------------------------------------
            var response = {
                feedback: "Unknown error while processing. Please try again.",
                code: 404
            };
            // -------------------------------------------------------
            // access rules :
            // admin can edit any number of campus
            // other type of users will have no access to this feature
            // --------------------------------------------------------
            // step 1: request validation, basic filtering
            if (!this.userId) {
                response.code = 999;
                response.feedback = "Access denied";
                return response;
            }
            check_1.check(data, Object);
            // step 2 : checking DB access rights
            // a flag to make sure this requesting user has the right access to modify this data
            var userHasAccessRights = false;
            var userIsAdmin = false;
            var dbAccessChecker = new checkdbaccess_ts_1.Checkdbaccess();
            userIsAdmin = dbAccessChecker.isRoleAdmin(this.userId); //returns true if admin
            userHasAccessRights = userIsAdmin;
            if (userHasAccessRights === true) {
                index_1.InstituteDB.collection.remove(data._id);
                response.code = 200;
                response.feedback = "Institute delete successfull!";
                return response;
            }
            else {
                // no Access right
                response.code = 999;
                response.feedback = "Access denied";
            }
            return response;
        }
    }); // END of meteor methods
} // END of Meteor.isServer

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"levelManagement.js":function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/dbapi/methods/metadata/levelManagement.js                                                                  //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
// docs for meteor default methods : http://docs.meteor.com/api/passwords.html
const meteor_1 = require('meteor/meteor');
const check_1 = require('meteor/check');
const checkdbaccess_ts_1 = require('/server/dbapi/tools/checkdbaccess.ts');
const index_1 = require("/imports/api/index");
if (meteor_1.Meteor.isServer) {
    meteor_1.Meteor.methods({
        'isLevelExistInDB'(levelName) {
            // --------------------------------------------------------------
            // the response object for client with feedback and data
            // codes :
            // 999 = unknown name.
            // 404 = Datbase level problem or Unknown error or exceptions
            // 200 = level name already exists;
            // ---------------------------------------------------------------
            var response = {
                feedback: "Unknown error while processing request. Please try again.",
                code: 404
            };
            var levelNameinDB = index_1.LevelDB.findOne({ "name": levelName });
            if (levelNameinDB !== undefined) {
                response.code = 200;
                response.feedback = "This Level is already registered in the system";
                return response;
            }
            else if (levelNameinDB === undefined) {
                response.code = 999;
                response.feedback = "This Level is not registered in the system";
                return response;
            }
            else {
                return response;
            }
        },
        'addNewLevel'(data) {
            // --------------------------------------------------------------
            // the response object for client with feedback and data
            // codes :
            // 999 = access denied.
            // 404 = Datbase level problem or Unknown error or exceptions
            // 200 = success;
            // ---------------------------------------------------------------
            var response = {
                feedback: "Unknown error while processing. Please try again.",
                code: 404
            };
            // -------------------------------------------------------
            // access rules :
            // admin can add any number of level
            // other type of users will have no access to this feature
            // --------------------------------------------------------
            // step 1: request validation, basic filtering
            if (!this.userId) {
                response.code = 999;
                response.feedback = "Access denied";
                return response;
            }
            check_1.check(data, Object);
            // step 2 : checking DB access rights
            // a flag to make sure this requesting user has the right access to modify this data
            var userHasAccessRights = false;
            var userIsAdmin = false;
            var dbAccessChecker = new checkdbaccess_ts_1.Checkdbaccess();
            userIsAdmin = dbAccessChecker.isRoleAdmin(this.userId); //returns true if admin
            userHasAccessRights = userIsAdmin;
            if (userHasAccessRights === true) {
                // step : 3 updating data into the DB
                index_1.LevelDB.collection.insert({
                    name: data.name,
                    description: data.description,
                    createdBy: meteor_1.Meteor.user().emails[0].address,
                    createdAt: new Date(),
                }); //end insert
                response.code = 200;
                response.feedback = "New Level Creation successfull!";
                return response;
            } // end if if(userHasAccessRights === true)
            else {
                // no Access right
                response.code = 999;
                response.feedback = "Access denied";
            }
            return response;
        },
        'updateLevel'(data) {
            // --------------------------------------------------------------
            // the response object for client with feedback and data
            // codes :
            // 999 = access denied.
            // 404 = Datbase level problem or Unknown error or exceptions
            // 200 = success;
            // ---------------------------------------------------------------
            var response = {
                feedback: "Unknown error while processing. Please try again.",
                code: 404
            };
            // -------------------------------------------------------
            // access rules :
            // admin can edit any number of level
            // other type of users will have no access to this feature
            // --------------------------------------------------------
            // step 1: request validation, basic filtering
            if (!this.userId) {
                response.code = 999;
                response.feedback = "Access denied";
                return response;
            }
            check_1.check(data, Object);
            // step 2 : checking DB access rights
            // a flag to make sure this requesting user has the right access to modify this data
            var userHasAccessRights = false;
            var userIsAdmin = false;
            var dbAccessChecker = new checkdbaccess_ts_1.Checkdbaccess();
            userIsAdmin = dbAccessChecker.isRoleAdmin(this.userId); //returns true if admin
            userHasAccessRights = userIsAdmin;
            if (userHasAccessRights === true) {
                // step : 3 updating data into the DB
                index_1.LevelDB.collection.update(data._id, {
                    $set: {
                        name: data.name,
                        description: data.description,
                        createdBy: meteor_1.Meteor.user().emails[0].address,
                        createdAt: new Date(),
                    }
                }); // end update
                response.code = 200;
                response.feedback = "Level Update successfull!";
                return response;
            } // end if if(userHasAccessRights === true)
            else {
                // no Access right
                response.code = 999;
                response.feedback = "Access denied";
            }
            return response;
        },
        'deleteLevel'(data) {
            // --------------------------------------------------------------
            // the response object for client with feedback and data
            // codes :
            // 999 = access denied.
            // 404 = Datbase level problem or Unknown error or exceptions
            // 200 = success;
            // ---------------------------------------------------------------
            var response = {
                feedback: "Unknown error while processing. Please try again.",
                code: 404
            };
            // -------------------------------------------------------
            // access rules :
            // admin can edit any number of level
            // other type of users will have no access to this feature
            // --------------------------------------------------------
            // step 1: request validation, basic filtering
            if (!this.userId) {
                response.code = 999;
                response.feedback = "Access denied";
                return response;
            }
            check_1.check(data, Object);
            // step 2 : checking DB access rights
            // a flag to make sure this requesting user has the right access to modify this data
            var userHasAccessRights = false;
            var userIsAdmin = false;
            var dbAccessChecker = new checkdbaccess_ts_1.Checkdbaccess();
            userIsAdmin = dbAccessChecker.isRoleAdmin(this.userId); //returns true if admin
            userHasAccessRights = userIsAdmin;
            if (userHasAccessRights === true) {
                index_1.LevelDB.collection.remove(data._id);
                response.code = 200;
                response.feedback = "Level delete successfull!";
                return response;
            }
            else {
                // no Access right
                response.code = 999;
                response.feedback = "Access denied";
            }
            return response;
        },
        'getAllLevelName'() {
            return index_1.LevelDB.find({}).fetch();
        }
    }); // END of meteor methods
} // END of Meteor.isServer

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"toolManagement.js":function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/dbapi/methods/metadata/toolManagement.js                                                                   //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
// docs for meteor default methods : http://docs.meteor.com/api/passwords.html
const meteor_1 = require('meteor/meteor');
const check_1 = require('meteor/check');
const checkdbaccess_ts_1 = require('/server/dbapi/tools/checkdbaccess.ts');
const index_1 = require("/imports/api/index");
if (meteor_1.Meteor.isServer) {
    meteor_1.Meteor.methods({
        'isToolExistInDB'(toolName) {
            // --------------------------------------------------------------
            // the response object for client with feedback and data
            // codes :
            // 999 = unknown name.
            // 404 = Datbase tool problem or Unknown error or exceptions
            // 200 = tool name already exists;
            // ---------------------------------------------------------------
            var response = {
                feedback: "Unknown error while processing request. Please try again.",
                code: 404
            };
            var toolNameinDB = index_1.ToolDB.findOne({ "name": toolName });
            if (toolNameinDB !== undefined) {
                response.code = 200;
                response.feedback = "This Tool is already registered in the system";
                return response;
            }
            else if (toolNameinDB === undefined) {
                response.code = 999;
                response.feedback = "This Tool is not registered in the system";
                return response;
            }
            else {
                return response;
            }
        },
        'addNewTool'(data) {
            // --------------------------------------------------------------
            // the response object for client with feedback and data
            // codes :
            // 999 = access denied.
            // 404 = Datbase tool problem or Unknown error or exceptions
            // 200 = success;
            // ---------------------------------------------------------------
            var response = {
                feedback: "Unknown error while processing. Please try again.",
                code: 404
            };
            // -------------------------------------------------------
            // access rules :
            // admin can add any number of tool
            // other type of users will have no access to this feature
            // --------------------------------------------------------
            // step 1: request validation, basic filtering
            if (!this.userId) {
                response.code = 999;
                response.feedback = "Access denied";
                return response;
            }
            check_1.check(data, Object);
            // step 2 : checking DB access rights
            // a flag to make sure this requesting user has the right access to modify this data
            var userHasAccessRights = false;
            var userIsAdmin = false;
            var dbAccessChecker = new checkdbaccess_ts_1.Checkdbaccess();
            userIsAdmin = dbAccessChecker.isRoleAdmin(this.userId); //returns true if admin
            userHasAccessRights = userIsAdmin;
            if (userHasAccessRights === true) {
                // step : 3 updating data into the DB
                index_1.ToolDB.collection.insert({
                    name: data.name,
                    description: data.description,
                    createdBy: meteor_1.Meteor.user().emails[0].address,
                    createdAt: new Date(),
                }); //end insert
                response.code = 200;
                response.feedback = "New Tool Creation successfull!";
                return response;
            } // end if if(userHasAccessRights === true)
            else {
                // no Access right
                response.code = 999;
                response.feedback = "Access denied";
            }
            return response;
        },
        'updateTool'(data) {
            // --------------------------------------------------------------
            // the response object for client with feedback and data
            // codes :
            // 999 = access denied.
            // 404 = Datbase tool problem or Unknown error or exceptions
            // 200 = success;
            // ---------------------------------------------------------------
            var response = {
                feedback: "Unknown error while processing. Please try again.",
                code: 404
            };
            // -------------------------------------------------------
            // access rules :
            // admin can edit any number of tool
            // other type of users will have no access to this feature
            // --------------------------------------------------------
            // step 1: request validation, basic filtering
            if (!this.userId) {
                response.code = 999;
                response.feedback = "Access denied";
                return response;
            }
            check_1.check(data, Object);
            // step 2 : checking DB access rights
            // a flag to make sure this requesting user has the right access to modify this data
            var userHasAccessRights = false;
            var userIsAdmin = false;
            var dbAccessChecker = new checkdbaccess_ts_1.Checkdbaccess();
            userIsAdmin = dbAccessChecker.isRoleAdmin(this.userId); //returns true if admin
            userHasAccessRights = userIsAdmin;
            if (userHasAccessRights === true) {
                // step : 3 updating data into the DB
                index_1.ToolDB.collection.update(data._id, {
                    $set: {
                        name: data.name,
                        description: data.description,
                        createdBy: meteor_1.Meteor.user().emails[0].address,
                        createdAt: new Date(),
                    }
                }); // end update
                response.code = 200;
                response.feedback = "Tool Update successfull!";
                return response;
            } // end if if(userHasAccessRights === true)
            else {
                // no Access right
                response.code = 999;
                response.feedback = "Access denied";
            }
            return response;
        },
        'deleteTool'(data) {
            // --------------------------------------------------------------
            // the response object for client with feedback and data
            // codes :
            // 999 = access denied.
            // 404 = Datbase tool problem or Unknown error or exceptions
            // 200 = success;
            // ---------------------------------------------------------------
            var response = {
                feedback: "Unknown error while processing. Please try again.",
                code: 404
            };
            // -------------------------------------------------------
            // access rules :
            // admin can edit any number of tool
            // other type of users will have no access to this feature
            // --------------------------------------------------------
            // step 1: request validation, basic filtering
            if (!this.userId) {
                response.code = 999;
                response.feedback = "Access denied";
                return response;
            }
            check_1.check(data, Object);
            // step 2 : checking DB access rights
            // a flag to make sure this requesting user has the right access to modify this data
            var userHasAccessRights = false;
            var userIsAdmin = false;
            var dbAccessChecker = new checkdbaccess_ts_1.Checkdbaccess();
            userIsAdmin = dbAccessChecker.isRoleAdmin(this.userId); //returns true if admin
            userHasAccessRights = userIsAdmin;
            if (userHasAccessRights === true) {
                index_1.ToolDB.collection.remove(data._id);
                response.code = 200;
                response.feedback = "Tool delete successfull!";
                return response;
            }
            else {
                // no Access right
                response.code = 999;
                response.feedback = "Access denied";
            }
            return response;
        },
        'getAllToolName'() {
            return index_1.ToolDB.find({}).fetch();
        }
    }); // END of meteor methods
} // END of Meteor.isServer

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"publications":{"publishCampus.js":function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/dbapi/publications/publishCampus.js                                                                        //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
const meteor_1 = require('meteor/meteor');
const index_ts_1 = require('/imports/api/index.ts');
if (meteor_1.Meteor.isServer) {
    // ===== start of publishAllCategories ======
    meteor_1.Meteor.publish('publishAllCampuses', function () {
        return index_ts_1.CampusDB.find({});
    });
} //end of if (Meteor.isServer)

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publishCompetency.js":function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/dbapi/publications/publishCompetency.js                                                                    //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
const meteor_1 = require('meteor/meteor');
const index_ts_1 = require('/imports/api/index.ts');
if (meteor_1.Meteor.isServer) {
    // ===== start of publishAllCategories ======
    meteor_1.Meteor.publish('publishAllCompetencies', function () {
        return index_ts_1.CompetencyDB.find({});
    });
} //end of if (Meteor.isServer)

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publishCourse.js":function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/dbapi/publications/publishCourse.js                                                                        //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
const meteor_1 = require('meteor/meteor');
const index_ts_1 = require('/imports/api/index.ts');
if (meteor_1.Meteor.isServer) {
    // ===== start of publishAllInstitute ======
    meteor_1.Meteor.publish('publishAllCourses', function () {
        return index_ts_1.CourseDB.find({});
    });
} //end of if (Meteor.isServer)

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publishFaculty.js":function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/dbapi/publications/publishFaculty.js                                                                       //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
const meteor_1 = require('meteor/meteor');
const index_ts_1 = require('/imports/api/index.ts');
if (meteor_1.Meteor.isServer) {
    // ===== start of publishAllFaculty ======
    meteor_1.Meteor.publish('publishAllFaculties', function () {
        return index_ts_1.FacultyDB.find({});
    });
} //end of if (Meteor.isServer)

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publishInstitute.js":function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/dbapi/publications/publishInstitute.js                                                                     //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
const meteor_1 = require('meteor/meteor');
const index_ts_1 = require('/imports/api/index.ts');
if (meteor_1.Meteor.isServer) {
    // ===== start of publishAllInstitute ======
    meteor_1.Meteor.publish('publishAllInstitutes', function () {
        return index_ts_1.InstituteDB.find({});
    });
} //end of if (Meteor.isServer)

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publishLevel.js":function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/dbapi/publications/publishLevel.js                                                                         //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
const meteor_1 = require('meteor/meteor');
const index_ts_1 = require('/imports/api/index.ts');
if (meteor_1.Meteor.isServer) {
    // ===== start of publishAllCategories ======
    meteor_1.Meteor.publish('publishAllLevels', function () {
        return index_ts_1.LevelDB.find({});
    });
} //end of if (Meteor.isServer)

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publishMetadata.js":function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/dbapi/publications/publishMetadata.js                                                                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
const meteor_1 = require('meteor/meteor');
const index_ts_1 = require('/imports/api/index.ts');
if (meteor_1.Meteor.isServer) {
    // ===== start of publishAllMetadata ======
    meteor_1.Meteor.publish('publishAllMetadata', function () {
        return index_ts_1.MetadataDB.find({});
    });
} //end of if (Meteor.isServer)

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publishProfile.js":function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/dbapi/publications/publishProfile.js                                                                       //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
const meteor_1 = require('meteor/meteor');
const index_ts_1 = require('/imports/api/index.ts');
if (meteor_1.Meteor.isServer) {
    // ===== start of myProfileDB ======
    meteor_1.Meteor.publish("myProfileDB", function () {
        // publishing ProfileDB for a single requesting user
        if (this.userId) {
            return index_ts_1.ProfileDB.find({ "userAccountID": this.userId });
        }
        return this.ready();
    });
    // --- End of myProfileDB ---
    meteor_1.Meteor.publish("publishAllUserProfileForAdmin", function () {
        return index_ts_1.ProfileDB.find({});
    });
} //end of if (Meteor.isServer)

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publishTool.js":function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/dbapi/publications/publishTool.js                                                                          //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
const meteor_1 = require('meteor/meteor');
const index_ts_1 = require('/imports/api/index.ts');
if (meteor_1.Meteor.isServer) {
    // ===== start of publishAllTools ======
    meteor_1.Meteor.publish('publishAllTools', function () {
        return index_ts_1.ToolDB.find({});
    });
} //end of if (Meteor.isServer)

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publishUser.js":function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/dbapi/publications/publishUser.js                                                                          //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
const meteor_1 = require('meteor/meteor');
const appconfig_1 = require('../../startup/appconfig');
var badgelorAppConfig = new appconfig_1.AppConfig();
const systemAdminEmail = badgelorAppConfig.adminEmail;
if (meteor_1.Meteor.isServer) {
    meteor_1.Meteor.publish("publishAllUserForAdmin", function () {
        if (this.userId) {
            return meteor_1.Meteor.users.find();
        }
        return this.ready();
    });
    meteor_1.Meteor.publish("publishAllUserForAdminStatistics", function () {
        if (this.userId) {
            return meteor_1.Meteor.users.find({ "emails.address": { $ne: systemAdminEmail } });
        }
        return this.ready();
    });
} //end of if (Meteor.isServer)

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"tools":{"checkdbaccess.ts":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/dbapi/tools/checkdbaccess.ts                                                                               //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.watch(require("./checkdbaccess.js"), {
  "*": module.makeNsSetter()
});

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"checkdbaccess.js":function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/dbapi/tools/checkdbaccess.js                                                                               //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
// this class will have common functions to check db access rights for a user
const meteor_1 = require('meteor/meteor');
class Checkdbaccess {
    //userID : string;
    constructor() {
    }
    // this function check if the passed userId belongs to an admin user (who has the role=admin)
    // return true if the user is an admin
    isRoleAdmin(userID) {
        var userDB;
        try {
            userDB = meteor_1.Meteor.users.findOne({ "_id": userID });
            if (userDB["role"] === "admin") {
                // this user is an admin
                return true;
            }
            else {
                return false;
            }
        }
        catch (err) {
            // console.log(err);
            return false;
        }
    } //end of isRoleAdmin
    isRoleApplicant(userID) {
        var userDB;
        try {
            userDB = meteor_1.Meteor.users.findOne({ "_id": userID });
            if (userDB["role"] === "applicant") {
                // this user is an admin
                return true;
            }
            else {
                return false;
            }
        }
        catch (err) {
            // console.log(err);
            return false;
        }
    } //end of isRoleApplicant
    isRoleCreator(userID) {
        var userDB;
        try {
            userDB = meteor_1.Meteor.users.findOne({ "_id": userID });
            if (userDB["role"] === "creator") {
                // this user is an admin
                return true;
            }
            else {
                return false;
            }
        }
        catch (err) {
            // console.log(err);
            return false;
        }
    }
}
exports.Checkdbaccess = Checkdbaccess; // end of class

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"featureAccessController.js":function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/dbapi/tools/featureAccessController.js                                                                     //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
// this class will have  functions to check feature access rights 
class FeatureAccessController {
    constructor() {
    }
}
exports.FeatureAccessController = FeatureAccessController; // end of class FeatureAccessController

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"rest":{"methods":{"ldapAPI.js":function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/rest/methods/ldapAPI.js                                                                                    //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
const meteor_1 = require('meteor/meteor');
if (meteor_1.Meteor.isServer) {
    meteor_1.Meteor.methods({
        // ///////////////////////////////////////
        //=========== LDAP access Method =========
        // This method is used for search user
        // of University of Koblenz and Landau
        // Files using this method : accountService.ts
        // ///////////////////////////////////////
        'bindAndSearch'(data) {
            // Create our future instance.
            var Future = Npm.require('fibers/future');
            var future = new Future();
            var clientFeedback = {
                error: "no error",
                firstName: "",
                lastName: "",
                eduPersonAffiliation: ""
            };
            var ldap = require('ldapjs');
            var client = ldap.createClient({
                url: 'ldap://ldap.uni-koblenz.de:389'
            });
            var opts = {
                filter: '(objectclass=*)',
                scope: 'base',
                // attributes: ['mail', 'cn', 'eduPersonAffiliation'],
                attributes: [],
                sizeLimit: 0 //0=unlimited
            };
            client.bind('uid=' + data.username + ',ou=' + data.ou1 + ',ou=' + data.ou2 + ',dc=Uni-Koblenz-landau,dc=de', data.password, function callback(err, response) {
                //assert.ifError(err);
                //console.log(response);
                if (err) {
                    console.log('bind unsuccessful, in error block');
                    clientFeedback.error = "Invalid password";
                    future.return(clientFeedback);
                }
                if (!err) {
                    if (response) {
                        // console.log(response);
                        // now bind is done
                        // lets search
                        client.search('uid=' + data.searchUserName + ',ou=' + data.ou3 + ',ou=' + data.ou4 + ',dc=Uni-Koblenz-landau,dc=de', opts, function (err, response) {
                            var assert = require('assert');
                            assert.ifError(err);
                            response.on('searchEntry', function callback(result) {
                                // console.log('entry: ' + JSON.stringify(result.object));
                                // console.log(result.object);
                                console.log("Hello : " + result.object.givenName); // extract First Name
                                console.log(result.object.mail); // extract email address
                                // we use condition here as some dummy accounts might not have name
                                // TODO: cleanup code once we no longer user dummy accounts.
                                if (result.object.givenName && result.object.sn) {
                                    clientFeedback.firstName = result.object.givenName;
                                    clientFeedback.lastName = result.object.sn;
                                }
                                else {
                                    clientFeedback.firstName = "User:";
                                    clientFeedback.lastName = data.searchUserName;
                                }
                                if (result.object.eduPersonAffiliation) {
                                    clientFeedback.eduPersonAffiliation = result.object.eduPersonAffiliation[1];
                                }
                                else {
                                    clientFeedback.eduPersonAffiliation = "Alumni";
                                }
                                future.return(clientFeedback);
                            });
                            response.on('error', function (err) {
                                clientFeedback.error = "User not found in the database!";
                                console.error('error: ' + err.message);
                                future.return(clientFeedback);
                            });
                        });
                    } // end if(response)
                } //end if (!err)
            }); //end client.bind
            return future.wait();
        },
        // we are going to use onlyLogin method for login purpose
        // instead of bind and search method. It performs faster
        // ///////////////////////////////////////
        //=========== LDAP access Method =========
        // This method is used for login user
        // of University of Koblenz and Landau
        // Files using this method : accountService.ts
        // ///////////////////////////////////////
        'onlyLogin'(data) {
            // Create our future instance.
            var Future = Npm.require('fibers/future');
            var future = new Future();
            var clientFeedback = {
                feedback: "error",
                name: "",
                eduPersonAffiliation: ""
            };
            var ldap = require('ldapjs');
            var client = ldap.createClient({
                url: 'ldap://ldap.uni-koblenz.de:389'
            });
            client.bind('uid=' + data.username + ',ou=' + data.ou1 + ',ou=' + data.ou2 + ',dc=Uni-Koblenz-landau,dc=de', data.password, function callback(err, response) {
                // assert.ifError(err);
                // console.log(response);
                if (err) {
                    console.log('bind unsuccessful, in error block');
                    clientFeedback.feedback = "Invalid password";
                    future.return(clientFeedback);
                }
                if (!err) {
                    if (response) {
                        clientFeedback.feedback = "Login successful";
                        future.return(clientFeedback);
                    }
                }
            });
            return future.wait();
        }
    }); // end Meteor.methods
} //end if (Meteor.isServer)

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"obfAPI.js":function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/rest/methods/obfAPI.js                                                                                     //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
const http_1 = require('meteor/http');
const meteor_1 = require('meteor/meteor');
const appconfig_1 = require('/server/startup/appconfig');
const apiUrl = 'https://openbadgefactory.com/v1/badge/NM70OHe7HCeO';
const apiUrlForEarnableBadge = 'https://openbadgefactory.com/v1/earnablebadge/NM70OHe7HCeO?visible=1';
if (meteor_1.Meteor.isServer) {
    meteor_1.Meteor.methods({
        // ******************************************************
        //  ========== create new badge =========================
        // ******************************************************
        'createBadge'(data) {
            this.unblock();
            var badgelorAppConfig = new appconfig_1.AppConfig();
            let apiCall = function (apiUrl, callback) {
                try {
                    let response = http_1.HTTP.call("POST", apiUrl, { npmRequestOptions: {
                            key: badgelorAppConfig.obfKey,
                            cert: badgelorAppConfig.obfCertificate,
                        }, data });
                    callback(null, response);
                }
                catch (error) {
                    let errorCode;
                    let errorMessage;
                    if (error.response) {
                        errorCode = error.response.data.code;
                        errorMessage = error.response.data.message;
                    }
                    else {
                        errorCode = 500;
                        errorMessage = 'Cannot access the API';
                    }
                    let myError = new meteor_1.Meteor.Error(errorCode, errorMessage);
                    callback(myError, null);
                }
            };
            let response = meteor_1.Meteor.wrapAsync(apiCall)(apiUrl);
            return response;
        },
        'updateSingleBadge'(data) {
            this.unblock();
            var badgelorAppConfig = new appconfig_1.AppConfig();
            let apiCall = function (apiUrl, callback) {
                try {
                    let response = http_1.HTTP.call("PUT", apiUrl + '/' + data.badge_id, { npmRequestOptions: {
                            key: badgelorAppConfig.obfKey,
                            cert: badgelorAppConfig.obfCertificate,
                        }, data });
                    callback(null, response);
                }
                catch (error) {
                    let errorCode;
                    let errorMessage;
                    if (error.response) {
                        errorCode = error.response.data.code;
                        errorMessage = error.response.data.message;
                    }
                    else {
                        errorCode = 500;
                        errorMessage = 'Cannot access the API';
                    }
                    let myError = new meteor_1.Meteor.Error(errorCode, errorMessage);
                    callback(myError, null);
                }
            };
            let response = meteor_1.Meteor.wrapAsync(apiCall)(apiUrl);
            return response;
        },
        'getEarnableBadges'() {
            this.unblock();
            var badgelorAppConfig = new appconfig_1.AppConfig();
            let apiCall = function (apiUrlForEarnableBadge, callback) {
                try {
                    let response = http_1.HTTP.call("GET", apiUrlForEarnableBadge, { npmRequestOptions: {
                            key: badgelorAppConfig.obfKey,
                            cert: badgelorAppConfig.obfCertificate,
                        } }).content;
                    callback(null, response);
                }
                catch (error) {
                    let errorCode;
                    let errorMessage;
                    if (error.response) {
                        errorCode = error.response.data.code;
                        errorMessage = error.response.data.message;
                    }
                    else {
                        errorCode = 500;
                        errorMessage = 'Cannot access the API';
                    }
                    let myError = new meteor_1.Meteor.Error(errorCode, errorMessage);
                    callback(myError, null);
                }
            };
            // let apiUrl = 'https://openbadgefactory.com/v1/badge/NM70OHe7HCeO';
            let response = meteor_1.Meteor.wrapAsync(apiCall)(apiUrlForEarnableBadge);
            response = response.trim();
            response = response.split(/\r\n/);
            response = response.join(',');
            response = "[" + response + "]";
            response = JSON.parse(response);
            return response;
            // =================== for earnable badge_id =======
            // var a = [];
            // for (let key in response) {
            //   a.push(response[key].badge_id);
            // }
            // let b = a.join("|");
            // console.log(b);
            // return b;
            // ==================================================
        },
        // **********************************
        //  get a single badge
        // **********************************
        'getSingleBadge'(badge_id) {
            this.unblock();
            let badgelorAppConfig = new appconfig_1.AppConfig();
            let apiUrlForSingleBadge = apiUrl + '/' + badge_id;
            let apiCall = function (apiUrlForSingleBadge, callback) {
                try {
                    let response = http_1.HTTP.call("GET", apiUrlForSingleBadge, { npmRequestOptions: {
                            key: badgelorAppConfig.obfKey,
                            cert: badgelorAppConfig.obfCertificate,
                        } }).content;
                    callback(null, response);
                }
                catch (error) {
                    let errorCode;
                    let errorMessage;
                    if (error.response) {
                        errorCode = error.response.data.code;
                        errorMessage = error.response.data.message;
                    }
                    else {
                        errorCode = 500;
                        errorMessage = 'Cannot access the API';
                    }
                    let myError = new meteor_1.Meteor.Error(errorCode, errorMessage);
                    callback(myError, null);
                }
            };
            let response = meteor_1.Meteor.wrapAsync(apiCall)(apiUrlForSingleBadge);
            response = response.trim();
            response = response.split(/\r\n/);
            response = response.join(',');
            response = JSON.parse(response);
            return response;
        },
        // **********************************
        //  get list of badges by id
        // **********************************
        'getBadgesByID'(listOfBadgeID) {
            this.unblock();
            var badgelorAppConfig = new appconfig_1.AppConfig();
            var apiUrlToGetListOfBadgeData = apiUrl + "/?id=" + listOfBadgeID;
            // console.log(apiUrlToGetListOfBadgeData);
            let apiCall = function (apiUrlToGetListOfBadgeData, callback) {
                try {
                    let response = http_1.HTTP.call("GET", apiUrlToGetListOfBadgeData, { npmRequestOptions: {
                            key: badgelorAppConfig.obfKey,
                            cert: badgelorAppConfig.obfCertificate,
                        } }).content;
                    callback(null, response);
                }
                catch (error) {
                    let errorCode;
                    let errorMessage;
                    if (error.response) {
                        errorCode = error.response.data.code;
                        errorMessage = error.response.data.message;
                    }
                    else {
                        errorCode = 500;
                        errorMessage = 'Cannot access the API';
                    }
                    let myError = new meteor_1.Meteor.Error(errorCode, errorMessage);
                    callback(myError, null);
                }
            };
            // let apiUrl = 'https://openbadgefactory.com/v1/badge/NM70OHe7HCeO';
            let response = meteor_1.Meteor.wrapAsync(apiCall)(apiUrlToGetListOfBadgeData);
            response = response.trim();
            response = response.split(/\r\n/);
            response = response.join(',');
            response = "[" + response + "]";
            response = JSON.parse(response);
            return response;
        },
        // **********************************
        //  get all badges for admin
        // **********************************
        'getAllBadges': function () {
            this.unblock();
            var badgelorAppConfig = new appconfig_1.AppConfig();
            let apiCall = function (apiUrl, callback) {
                try {
                    let response = http_1.HTTP.call("GET", apiUrl, { npmRequestOptions: {
                            key: badgelorAppConfig.obfKey,
                            cert: badgelorAppConfig.obfCertificate,
                        } }).content;
                    callback(null, response);
                }
                catch (error) {
                    let errorCode;
                    let errorMessage;
                    if (error.response) {
                        errorCode = error.response.data.code;
                        errorMessage = error.response.data.message;
                    }
                    else {
                        errorCode = 500;
                        errorMessage = 'Cannot access the API';
                    }
                    let myError = new meteor_1.Meteor.Error(errorCode, errorMessage);
                    callback(myError, null);
                }
            };
            // let apiUrl = 'https://openbadgefactory.com/v1/badge/NM70OHe7HCeO';
            let response = meteor_1.Meteor.wrapAsync(apiCall)(apiUrl);
            response = response.trim();
            response = response.split(/\r\n/);
            response = response.join(',');
            response = "[" + response + "]";
            response = JSON.parse(response);
            return response;
        },
    }); // end Meteor.methods
} //end if (Meteor.isServer)

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"obfAdminAPI.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/rest/methods/obfAdminAPI.js                                                                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"obfApplicantAPI.js":function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/rest/methods/obfApplicantAPI.js                                                                            //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
// All applicant related API call methods are in this file
// This methods are used in the following files
// 1. applicantProfile.ts
// 2.
// 3.
const http_1 = require('meteor/http');
const meteor_1 = require('meteor/meteor');
const appconfig_1 = require('/server/startup/appconfig');
const apiUrl = 'https://openbadgefactory.com/v1/badge/NM70OHe7HCeO';
if (meteor_1.Meteor.isServer) {
    meteor_1.Meteor.methods({
        // ==================================
        // ======= Get all earnable_id ======
        // ==================================
        'getEarnableIdList'() {
            this.unblock();
            var badgelorAppConfig = new appconfig_1.AppConfig();
            const apiUrlForEarnableBadge = 'https://openbadgefactory.com/v1/earnablebadge/NM70OHe7HCeO';
            let apiCall = function (apiUrlForEarnableBadge, callback) {
                try {
                    let response = http_1.HTTP.call("GET", apiUrlForEarnableBadge, { npmRequestOptions: {
                            key: badgelorAppConfig.obfKey,
                            cert: badgelorAppConfig.obfCertificate,
                        } }).content;
                    callback(null, response);
                }
                catch (error) {
                    let errorCode;
                    let errorMessage;
                    if (error.response) {
                        errorCode = error.response.data.code;
                        errorMessage = error.response.data.message;
                    }
                    else {
                        errorCode = 500;
                        errorMessage = 'Cannot access the API';
                    }
                    let myError = new meteor_1.Meteor.Error(errorCode, errorMessage);
                    callback(myError, null);
                }
            };
            let response = meteor_1.Meteor.wrapAsync(apiCall)(apiUrlForEarnableBadge);
            response = response.trim();
            response = response.split(/\r\n/);
            response = response.join(',');
            response = "[" + response + "]";
            response = JSON.parse(response);
            // ================ for earnable_id =================
            let obj = [];
            for (let key in response) {
                obj.push({
                    badge_id: response[key].badge_id,
                    earnable_id: response[key].id,
                    name: response[key].name
                });
            }
            return obj;
        },
        // =========================================
        // ======== Get all badge applications =====
        // =========================================
        // we get all application of an applicant
        // filtered by their email address
        'getAllBadgeApplication'(earnableID, userEmail) {
            console.log(userEmail);
            this.unblock();
            var badgelorAppConfig = new appconfig_1.AppConfig();
            var apiUrlforBadgeApplication = "https://openbadgefactory.com/v1/earnablebadge/NM70OHe7HCeO" + "/" + earnableID + "/application";
            // console.log(apiUrlToGetListOfBadgeData);
            let apiCall = function (apiUrlforBadgeApplication, callback) {
                try {
                    let response = http_1.HTTP.call("GET", apiUrlforBadgeApplication, { npmRequestOptions: {
                            key: badgelorAppConfig.obfKey,
                            cert: badgelorAppConfig.obfCertificate,
                        } }).content;
                    callback(null, response);
                }
                catch (error) {
                    let errorCode;
                    let errorMessage;
                    if (error.response) {
                        errorCode = error.response.data.code;
                        errorMessage = error.response.data.message;
                    }
                    else {
                        errorCode = 500;
                        errorMessage = 'Cannot access the API';
                    }
                    let myError = new meteor_1.Meteor.Error(errorCode, errorMessage);
                    callback(myError, null);
                }
            };
            let response = meteor_1.Meteor.wrapAsync(apiCall)(apiUrlforBadgeApplication);
            response = response.trim();
            response = response.split(/\r\n/);
            response = response.join(',');
            response = "[" + response + "]";
            response = JSON.parse(response);
            response = response.filter(function (el) {
                return (el.email === userEmail);
            });
            return response;
        },
    }); // end Meteor.methods
} //end if (Meteor.isServer)

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"obfCreatorAPI.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/rest/methods/obfCreatorAPI.js                                                                              //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"obfIssuerAPI.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/rest/methods/obfIssuerAPI.js                                                                               //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"startup":{"appconfig.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/startup/appconfig.js                                                                                       //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
// this module can be imported to any other server side module
// to use config data such as (api url, token etc).
// for production server, all the secret values will be imported from settings.json file (production version) during deployment process.
const meteor_1 = require('meteor/meteor');
const data = require('../../seedData.json');
class AppConfig {
    constructor() {
        this.adminPassword = meteor_1.Meteor["settings"]["private"]["adminLogin"];
        this.adminEmail = meteor_1.Meteor["settings"]["private"]["adminEmail"];
        this.obfCertificate = meteor_1.Meteor["settings"]["private"]["obfCertificate"].join('\n');
        this.obfKey = meteor_1.Meteor["settings"]["private"]["obfKey"].join('\n');
        this.campusArray = data.campuses;
        this.koblenzFaculties = data.koblenzFaculties;
        this.landauFaculties = data.landauFaculties;
        this.levels = data.levels;
        this.competencies = data.competencies;
        this.tools = data.tools;
    }
}
exports.AppConfig = AppConfig; // end of class

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"startup.js":function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/startup/startup.js                                                                                         //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
// startup codes for server - e.g : api init for remote services
// --- adding some seed data if the db is empty - just for bootstrapping ---
const meteor_1 = require("meteor/meteor");
const appconfig_1 = require("/server/startup/appconfig");
const api_1 = require("../../imports/api");
meteor_1.Meteor.startup(function () { }); //end Meteor.startup
// ---------------------------------------------------------------------------------------------
// ------------------------ Creating admin account on startup ----------------------------------
// ---------------------------------------------------------------------------------------------
var badgelorAppConfig = new appconfig_1.AppConfig();
// creating an admin account if none exists.
if (meteor_1.Meteor.users.find({ username: "admin" }).count() != 1) {
    //
    //   // creating admin user for the first time
    //
    try {
        Accounts.createUser({
            email: badgelorAppConfig.adminEmail,
            password: badgelorAppConfig.adminPassword,
            username: "admin"
        });
        // now admin account is created. so setting this user role as admin
        let adminDB = meteor_1.Meteor.users.findOne({ username: "admin" });
        meteor_1.Meteor.users.update(adminDB._id, {
            $set: {
                role: "admin",
                obfID: ""
            }
        });
    }
    catch (e) {
        //end try
        console.log("error : " + e);
    }
} //end if admin doesn't exist
// if there is no campus in the server
// ---------------------------------------------------------------------------------------------
// ------------------------------- create campuses on startup ----------------------------------
// ---------------------------------------------------------------------------------------------
if (api_1.CampusDB.collection.find({}).count() == 0) {
    try {
        for (let key in badgelorAppConfig.campusArray) {
            api_1.CampusDB.collection.insert({
                name: badgelorAppConfig.campusArray[key],
                description: "",
                createdBy: badgelorAppConfig.adminEmail,
                createdAt: new Date()
            }); //end insert
        } // end of for loop
    }
    catch (e) {
        console.log("error : " + e);
    }
}
// -------------------------------------------------------------------------------------------------------------
// ------------------------------- create Faculties and institutes on startup ----------------------------------
// -------------------------------------------------------------------------------------------------------------
// now we load the faculties for campuses [Koblenz, Landau]
let koblenzCampusDB = api_1.CampusDB.collection.findOne({ name: "koblenz" });
// console.log(koblenzCampusDB["_id"]);
let landauCampusDB = api_1.CampusDB.collection.findOne({ name: "landau" });
// console.log(landauCampusDB["_id"]);
if (api_1.FacultyDB.collection.find({}).count() == 0) {
    try {
        // =============================================
        // first enter koblenz faculties and institutes
        // =============================================
        for (let key in badgelorAppConfig.koblenzFaculties) {
            api_1.FacultyDB.collection.insert({
                name: badgelorAppConfig.koblenzFaculties[key]["name"],
                description: "",
                campusID: koblenzCampusDB["_id"],
                createdBy: badgelorAppConfig.adminEmail,
                createdAt: new Date()
            }); //end insert
            let thisFaculty = api_1.FacultyDB.collection.findOne({
                name: badgelorAppConfig.koblenzFaculties[key]["name"]
            });
            if (badgelorAppConfig.koblenzFaculties[key].institutes.length > 0) {
                for (let i in badgelorAppConfig.koblenzFaculties[key].institutes) {
                    api_1.InstituteDB.collection.insert({
                        name: badgelorAppConfig.koblenzFaculties[key].institutes[i],
                        description: "",
                        campusID: koblenzCampusDB["_id"],
                        facultyID: thisFaculty["_id"],
                        createdBy: badgelorAppConfig.adminEmail,
                        createdAt: new Date()
                    });
                }
            }
        }
        // =============================================
        // Then landau faculties and institutes ========
        // =============================================
        for (let key in badgelorAppConfig.landauFaculties) {
            api_1.FacultyDB.collection.insert({
                name: badgelorAppConfig.landauFaculties[key]["name"],
                description: "",
                campusID: landauCampusDB["_id"],
                createdBy: badgelorAppConfig.adminEmail,
                createdAt: new Date()
            }); //end insert
            let thisFaculty = api_1.FacultyDB.collection.findOne({
                name: badgelorAppConfig.landauFaculties[key]["name"]
            });
            if (badgelorAppConfig.landauFaculties[key].institutes.length > 0) {
                for (let i in badgelorAppConfig.landauFaculties[key].institutes) {
                    api_1.InstituteDB.collection.insert({
                        name: badgelorAppConfig.landauFaculties[key].institutes[i],
                        description: "",
                        campusID: landauCampusDB["_id"],
                        facultyID: thisFaculty["_id"],
                        createdBy: badgelorAppConfig.adminEmail,
                        createdAt: new Date()
                    });
                }
            }
        }
    }
    catch (e) {
        console.log("error :" + e);
    }
}
if (api_1.LevelDB.collection.find({}).count() == 0) {
    try {
        for (let key in badgelorAppConfig.levels) {
            api_1.LevelDB.collection.insert({
                name: badgelorAppConfig.levels[key],
                description: '',
                createdBy: badgelorAppConfig.adminEmail,
                createdAt: new Date()
            });
        }
    }
    catch (e) {
        console.log("error :" + e);
    }
}
if (api_1.CompetencyDB.collection.find({}).count() == 0) {
    try {
        for (let key in badgelorAppConfig.competencies) {
            api_1.CompetencyDB.collection.insert({
                name: badgelorAppConfig.competencies[key],
                description: '',
                createdBy: badgelorAppConfig.adminEmail,
                createdAt: new Date()
            });
        }
    }
    catch (e) {
        console.log("error :" + e);
    }
}
if (api_1.ToolDB.collection.find({}).count() == 0) {
    try {
        for (let key in badgelorAppConfig.tools) {
            api_1.ToolDB.collection.insert({
                name: badgelorAppConfig.tools[key],
                description: '',
                createdBy: badgelorAppConfig.adminEmail,
                createdAt: new Date()
            });
        }
    }
    catch (e) {
        console.log("error :" + e);
    }
}
// TODO : reset password and email from the settings file on each startup - so that admin password is
// always up to date as per the latest settings.json file.
// --------------------------------------------
// ----- END of database seed on startup ------
// --------------------------------------------

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"main.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/main.js                                                                                                    //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
// import '../imports/api/collections.js';

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"imports":{"api":{"collections.js":function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/collections.js                                                                                        //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
// This file contains all the declarations for mongo database/collections
// modules of this file will need to be imported in both server and client scripts - whenever a DB access is needed.
const meteor_1 = require('meteor/meteor');
const meteor_rxjs_1 = require('meteor-rxjs');
//here campus is the name of mongo collection in the database and CampusDB points to that collection.
exports.CampusDB = new meteor_rxjs_1.MongoObservable.Collection('campus');
exports.FacultyDB = new meteor_rxjs_1.MongoObservable.Collection('faculty');
exports.InstituteDB = new meteor_rxjs_1.MongoObservable.Collection('institute');
exports.CourseDB = new meteor_rxjs_1.MongoObservable.Collection('course');
exports.LevelDB = new meteor_rxjs_1.MongoObservable.Collection('level');
exports.CompetencyDB = new meteor_rxjs_1.MongoObservable.Collection('competency');
exports.ToolDB = new meteor_rxjs_1.MongoObservable.Collection('tool');
exports.MetadataDB = new meteor_rxjs_1.MongoObservable.Collection('metadata');
exports.ProfileDB = new meteor_rxjs_1.MongoObservable.Collection('profile');
if (meteor_1.Meteor.isServer) {
} // end if (Meteor.isServer)

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.ts":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/index.ts                                                                                              //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.watch(require("./index.js"), {
  "*": module.makeNsSetter()
});

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/index.js                                                                                              //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
__export(require('./collections'));

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"seedData.json":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// seedData.json                                                                                                     //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.exports = {
  "campuses": [
    "koblenz",
    "landau"
  ],
  "koblenzFaculties": [
    {
      "name": "Fb 1 - Bildungswissenschaften",
      "institutes": [
        "Institut für Grundschulpädagogik",
        "Institut für Pädagogik",
        "Institut für Psychologie",
        "Institut für Soziologie"
      ]
    },
    {
      "name": "Fb 2 - Philologie / Kulturwissenschaften",
      "institutes": [
        "Anglistik",
        "Evangelische Theologie",
        "Germanistik",
        "Geschichte",
        "Institut für Philosophie",
        "Katholische Theologie",
        "Kulturwissenschaft",
        "Kunstwissenschaft",
        "Musikwissenschaft und Musikpädagogik",
        "Spachlernzentrum"
      ]
    },
    {
      "name": "Fb 3 - Mathematik / Naturwissenschaften",
      "institutes": [
        "Institut für integrierte Naturwissenschaften",
        "Institut für Sportwissenschaft"
      ]
    },
    {
      "name": "Fb 4 - Informatik",
      "institutes": [
        "Institute for Web Science and Technologies",
        "Institut für Computervisualistik",
        "Institut für Informatik",
        "Institut für Management",
        "Institut für Softwaretechnik",
        "Institut für Wirtschafts- und Verwaltungsinformatik"
      ]
    },
    {
      "name": "Ada Lovelace Project",
      "institutes": []
    },
    {
      "name": "Ahs - Allgemeiner Hochschulsport",
      "institutes": []
    },
    {
      "name": "Anubis - Auszubildenden Netzwerk Und Bildungs Service",
      "institutes": []
    },
    {
      "name": "Ghrko - Rechenzentrum",
      "institutes": []
    },
    {
      "name": "Iwm - Institut Für Wissensmedien",
      "institutes": []
    },
    {
      "name": "Ksb - Kompetenzzentrum Für Studium Und Beruf",
      "institutes": [
        "SmP - Studieren mit Profil"
      ]
    },
    {
      "name": "MTI MITTELRHEIN - Institut für Medizintechnik und Informationsverarbeitung",
      "institutes": []
    },
    {
      "name": "Studentische Selbstverwaltung",
      "institutes": [
        "Studierendenparlament (StuPa)",
        "Allgemeiner Studierenden-Ausschuss (AStA)",
        "Fachschaft Informatik & Computer-Visualistik",
        "Bildungsforum Koblenz"
      ]
    },
    {
      "name": "Universitätsbibliothek Koblenz",
      "institutes": []
    },
    {
      "name": "Zentrum für Lehrerbildung",
      "institutes": []
    },
    {
      "name": "ZFUW - Zentrum für Fernstudien und universitäre Weiterbildung",
      "institutes": []
    },
    {
      "name": "Andere Einrichtungen",
      "institutes": []
    }
  ],
  "landauFaculties": [
    {
      "name": "Fb 5 - Erziehungswissenschaften",
      "institutes": [
        "Institut für Bildung im Kindes- und Jugendalter",
        "Institut für Erziehungswissenschaft",
        "Institut für Philosophie",
        "Institut für Sonderpädagogik"
      ]
    },
    {
      "name": "Fb 6 - Kultur- Und Sozialwissenschaften",
      "institutes": [
        "Historisches Seminar",
        "Institut für Evangelische Theologie",
        "Institut für fremdsprachliche Philologien",
        "Institut für Germanistik",
        "Institut für Katholische Theologie",
        "Institut für Kunstwissenschaft und Bildende Kunst",
        "Institut für Musikwissenschaft und Musik",
        "Institut für Sozialwissenschaften",
        "Sprachlernzentrum"
      ]
    },
    {
      "name": "Fb 7 - Natur- Und Umweltwissenschaften",
      "institutes": [
        "Institut für Mathematik",
        "Institut für Sportwissenschaft",
        "Institut für Umweltwissenschaften",
        "Institut für naturwissenschaftliche Bildung"
      ]
    },
    {
      "name": "Fb 8 - Psychologie",
      "institutes": [
        "Biopsychologie",
        "Diagnostik, Differentielle und Persönlichkeitspsychologie, Methodik & Evaluation",
        "Entwicklungspsychologie und Pädagogische Psychologie",
        "IKM - Institut für Kommunikationspsychologie und Medienpädagogik",
        "Klinische Psychologie und Psychotherapie",
        "Kognitive Psychologie",
        "Multimedia",
        "Sozial-, Umwelt- und Wirtschaftspsychologie",
        "Weiterbildungsstudiengang in Psychologischer Psychotherapeut / Universitätsambulanz"
      ]
    },
    {
      "name": "Allgemeiner Hochschulsport",
      "institutes": []
    },
    {
      "name": "Alumni-Netzwerk",
      "institutes": []
    },
    {
      "name": "Arbeitsstelle Multimedia",
      "institutes": []
    },
    {
      "name": "Frauenbüro",
      "institutes": []
    },
    {
      "name": "Friedensakademie",
      "institutes": []
    },
    {
      "name": "Hochschuldidaktische Arbeitsstelle",
      "institutes": []
    },
    {
      "name": "Ifu - Institut Für Regionale Umweltforschung Und Umweltbildung",
      "institutes": []
    },
    {
      "name": "Ksb - Kompetenzzentrum Für Studium Und Beruf",
      "institutes": []
    },
    {
      "name": "Medienzentrum",
      "institutes": []
    },
    {
      "name": "Methodenzentrum",
      "institutes": []
    },
    {
      "name": "Universitätsbibliothek",
      "institutes": []
    },
    {
      "name": "Universitätsrechenzentrum In Landau",
      "institutes": []
    },
    {
      "name": "Upgrade - Graduiertenschule Unterrichtsprozesse",
      "institutes": []
    },
    {
      "name": "Zepf - Zentrum Für Empirische Pädagogische Forschung",
      "institutes": []
    },
    {
      "name": "Zfuw - Zentrum Für Fernstudien Und Universitäre Weiterbildung",
      "institutes": []
    },
    {
      "name": "Zkw - Zentrum Für Kultur- Und Wissensdialog",
      "institutes": []
    },
    {
      "name": "Zentrum Für Lehrerbildung",
      "institutes": []
    }
  ],
  "levels": [
    "Anfanger",
    "Fortgeschrittene",
    "Experten"
  ],
  "competencies": [
    "Bedienen / Anwenden",
    "Informieren / Kooperieren",
    "Kommunizieren / Kooperieren",
    "Produzieren / Prasentieren",
    "Analysieren / Reflektieren"
  ],
  "tools": [
    "Latex",
    "Matlab"
  ]
};

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},{
  "extensions": [
    ".js",
    ".json",
    ".html",
    ".ts",
    ".scss",
    ".less",
    ".sass"
  ]
});
require("./server/dbapi/methods/accounts/accountManagement.js");
require("./server/dbapi/methods/metadata/badgeManagement.js");
require("./server/dbapi/methods/metadata/campusManagement.js");
require("./server/dbapi/methods/metadata/competencyManagement.js");
require("./server/dbapi/methods/metadata/courseManagement.js");
require("./server/dbapi/methods/metadata/facultyManagement.js");
require("./server/dbapi/methods/metadata/instituteManagement.js");
require("./server/dbapi/methods/metadata/levelManagement.js");
require("./server/dbapi/methods/metadata/toolManagement.js");
require("./server/dbapi/publications/publishCampus.js");
require("./server/dbapi/publications/publishCompetency.js");
require("./server/dbapi/publications/publishCourse.js");
require("./server/dbapi/publications/publishFaculty.js");
require("./server/dbapi/publications/publishInstitute.js");
require("./server/dbapi/publications/publishLevel.js");
require("./server/dbapi/publications/publishMetadata.js");
require("./server/dbapi/publications/publishProfile.js");
require("./server/dbapi/publications/publishTool.js");
require("./server/dbapi/publications/publishUser.js");
require("./server/dbapi/tools/checkdbaccess.js");
require("./server/dbapi/tools/featureAccessController.js");
require("./server/rest/methods/ldapAPI.js");
require("./server/rest/methods/obfAPI.js");
require("./server/rest/methods/obfAdminAPI.js");
require("./server/rest/methods/obfApplicantAPI.js");
require("./server/rest/methods/obfCreatorAPI.js");
require("./server/rest/methods/obfIssuerAPI.js");
require("./server/startup/appconfig.js");
require("./server/startup/startup.js");
require("./server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2RiYXBpL21ldGhvZHMvYWNjb3VudHMvYWNjb3VudE1hbmFnZW1lbnQudHMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9kYmFwaS9tZXRob2RzL21ldGFkYXRhL2JhZGdlTWFuYWdlbWVudC50cyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2RiYXBpL21ldGhvZHMvbWV0YWRhdGEvY2FtcHVzTWFuYWdlbWVudC50cyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2RiYXBpL21ldGhvZHMvbWV0YWRhdGEvY29tcGV0ZW5jeU1hbmFnZW1lbnQudHMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9kYmFwaS9tZXRob2RzL21ldGFkYXRhL2NvdXJzZU1hbmFnZW1lbnQudHMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9kYmFwaS9tZXRob2RzL21ldGFkYXRhL2ZhY3VsdHlNYW5hZ2VtZW50LnRzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvZGJhcGkvbWV0aG9kcy9tZXRhZGF0YS9pbnN0aXR1dGVNYW5hZ2VtZW50LnRzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvZGJhcGkvbWV0aG9kcy9tZXRhZGF0YS9sZXZlbE1hbmFnZW1lbnQudHMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9kYmFwaS9tZXRob2RzL21ldGFkYXRhL3Rvb2xNYW5hZ2VtZW50LnRzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvZGJhcGkvcHVibGljYXRpb25zL3B1Ymxpc2hDYW1wdXMudHMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9kYmFwaS9wdWJsaWNhdGlvbnMvcHVibGlzaENvbXBldGVuY3kudHMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9kYmFwaS9wdWJsaWNhdGlvbnMvcHVibGlzaENvdXJzZS50cyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2RiYXBpL3B1YmxpY2F0aW9ucy9wdWJsaXNoRmFjdWx0eS50cyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2RiYXBpL3B1YmxpY2F0aW9ucy9wdWJsaXNoSW5zdGl0dXRlLnRzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvZGJhcGkvcHVibGljYXRpb25zL3B1Ymxpc2hMZXZlbC50cyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2RiYXBpL3B1YmxpY2F0aW9ucy9wdWJsaXNoTWV0YWRhdGEudHMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9kYmFwaS9wdWJsaWNhdGlvbnMvcHVibGlzaFByb2ZpbGUudHMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9kYmFwaS9wdWJsaWNhdGlvbnMvcHVibGlzaFRvb2wudHMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9kYmFwaS9wdWJsaWNhdGlvbnMvcHVibGlzaFVzZXIudHMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9kYmFwaS90b29scy9jaGVja2RiYWNjZXNzLnRzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvZGJhcGkvdG9vbHMvZmVhdHVyZUFjY2Vzc0NvbnRyb2xsZXIudHMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9yZXN0L21ldGhvZHMvbGRhcEFQSS50cyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3Jlc3QvbWV0aG9kcy9vYmZBUEkudHMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9yZXN0L21ldGhvZHMvb2JmQXBwbGljYW50QVBJLnRzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvc3RhcnR1cC9hcHBjb25maWcudHMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9zdGFydHVwL3N0YXJ0dXAudHMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLnRzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9jb2xsZWN0aW9ucy50cyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQSw4RUFBOEU7QUFDOUUseUJBQXVCLGVBQWUsQ0FBQztBQUN2QyxnQ0FBeUIsc0JBQ3pCLENBQUMsQ0FEOEM7QUFHL0Msd0JBQXNCLGNBQWMsQ0FBQztBQUNyQyxtQ0FBOEIsc0NBQXNDLENBQUM7QUFDckUsd0JBQTBCLG9CQUFvQixDQUFDO0FBRS9DLEVBQUUsQ0FBQyxDQUFDLGVBQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0lBRXBCLGVBQU0sQ0FBQyxPQUFPLENBQUM7UUFFYixpQkFBaUIsQ0FBQyxLQUFLO1lBQ3JCLGlFQUFpRTtZQUNqRSx3REFBd0Q7WUFDeEQsVUFBVTtZQUNWLCtCQUErQjtZQUMvQiw2REFBNkQ7WUFDN0QsNkJBQTZCO1lBQzdCLGtFQUFrRTtZQUNsRSxJQUFJLFFBQVEsR0FBUTtnQkFDbEIsUUFBUSxFQUFFLDJEQUEyRDtnQkFDckUsSUFBSSxFQUFFLEdBQUc7YUFDVjtZQUNELElBQUksSUFBSSxHQUFHLGVBQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEVBQUUsZ0JBQWdCLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQztZQUU3RCxFQUFFLENBQUMsQ0FBQyxJQUFJLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQztnQkFDdkIsNkJBQTZCO2dCQUM3QixZQUFZO2dCQUNaLFFBQVEsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDO2dCQUNwQixRQUFRLENBQUMsUUFBUSxHQUFHLDZDQUE2QyxDQUFDO2dCQUNsRSxNQUFNLENBQUMsUUFBUSxDQUFDO1lBQ2xCLENBQUM7WUFDRCxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUM7Z0JBQzNCLGlDQUFpQztnQkFDakMsZ0JBQWdCO2dCQUNoQixRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyxnQ0FBZ0MsQ0FBQztnQkFDckQsTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNsQixDQUFDO1lBQ0QsSUFBSSxDQUFDLENBQUM7Z0JBQ0osTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNsQixDQUFDO1FBQ0gsQ0FBQztRQUVELHFCQUFxQixDQUFDLEtBQUs7WUFDekIsaUVBQWlFO1lBQ2pFLHdEQUF3RDtZQUN4RCxVQUFVO1lBQ1YsK0JBQStCO1lBQy9CLDZEQUE2RDtZQUM3RCw2QkFBNkI7WUFDN0Isa0VBQWtFO1lBQ2xFLElBQUksUUFBUSxHQUFRO2dCQUNsQixRQUFRLEVBQUUsMkRBQTJEO2dCQUNyRSxJQUFJLEVBQUUsR0FBRztnQkFDVCxRQUFRLEVBQUUsU0FBUzthQUNwQjtZQUNELElBQUksSUFBSSxHQUFHLGVBQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEVBQUUsZ0JBQWdCLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQztZQUU3RCxFQUFFLENBQUMsQ0FBQyxJQUFJLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQztnQkFDdkIsNkJBQTZCO2dCQUM3QixnREFBZ0Q7Z0JBQ2hELElBQUksUUFBUSxHQUFHLGlCQUFTLENBQUMsT0FBTyxDQUFDLEVBQUMsZUFBZSxFQUFFLElBQUksQ0FBQyxHQUFHLEVBQUMsQ0FBQyxDQUFDO2dCQUU5RCxRQUFRLENBQUMsUUFBUSxHQUFHO29CQUNsQixTQUFTLEVBQUUsUUFBUSxDQUFDLFNBQVM7b0JBQzdCLFFBQVEsRUFBRSxRQUFRLENBQUMsUUFBUTtvQkFDM0IsVUFBVSxFQUFFLFFBQVEsQ0FBQyxVQUFVO29CQUMvQixNQUFNLEVBQUUsUUFBUSxDQUFDLE1BQU07b0JBQ3ZCLElBQUksRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDO29CQUNsQixLQUFLLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQztvQkFDcEIsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxXQUFXLENBQUM7b0JBQ3ZDLGFBQWEsRUFBRSxJQUFJLENBQUMsR0FBRztvQkFDdkIsU0FBUyxFQUFFLFFBQVEsQ0FBQyxHQUFHO2lCQUN4QjtnQkFDRCxRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyx3QkFBd0IsQ0FBQztnQkFDN0MsTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNsQixDQUFDO1lBQ0QsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDO2dCQUMzQixpQ0FBaUM7Z0JBQ2pDLGdCQUFnQjtnQkFDaEIsUUFBUSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7Z0JBQ3BCLFFBQVEsQ0FBQyxRQUFRLEdBQUcsZ0NBQWdDLENBQUM7Z0JBQ3JELE1BQU0sQ0FBQyxRQUFRLENBQUM7WUFDbEIsQ0FBQztZQUNELElBQUksQ0FBQyxDQUFDO2dCQUNKLE1BQU0sQ0FBQyxRQUFRLENBQUM7WUFDbEIsQ0FBQztRQUNILENBQUM7UUFFRCxpQkFBaUI7WUFDZiwwRUFBMEU7WUFDMUUsK0NBQStDO1lBQy9DLFVBQVU7WUFDVix5QkFBeUI7WUFDekIsa0JBQWtCO1lBQ2xCLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7Z0JBQ2pCLE1BQU0sQ0FBQyxHQUFHLENBQUM7WUFDYixDQUFDO1lBQ0QsSUFBSSxlQUFlLEdBQUcsSUFBSSxnQ0FBYSxFQUFFLENBQUM7WUFDMUMsRUFBRSxDQUFDLENBQUMsZUFBZSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQztnQkFDdEQsTUFBTSxDQUFDLEdBQUcsQ0FBQztZQUNiLENBQUM7WUFDRCxJQUFJLENBQUMsQ0FBQztnQkFDSixNQUFNLENBQUMsR0FBRyxDQUFDO1lBQ2IsQ0FBQztRQUNILENBQUM7UUFFRCxxQkFBcUI7WUFDbkIsOEVBQThFO1lBQzlFLCtDQUErQztZQUMvQyxVQUFVO1lBQ1YsNkJBQTZCO1lBQzdCLHNCQUFzQjtZQUN0QixFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO2dCQUNqQixNQUFNLENBQUMsR0FBRyxDQUFDO1lBQ2IsQ0FBQztZQUNELElBQUksZUFBZSxHQUFHLElBQUksZ0NBQWEsRUFBRSxDQUFDO1lBQzFDLEVBQUUsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBQzFELE1BQU0sQ0FBQyxHQUFHLENBQUM7WUFDYixDQUFDO1lBQ0QsSUFBSSxDQUFDLENBQUM7Z0JBQ0osTUFBTSxDQUFDLEdBQUcsQ0FBQztZQUNiLENBQUM7UUFDSCxDQUFDO1FBR0QsaUJBQWlCLENBQUMsSUFBSTtZQUNwQiwyREFBMkQ7WUFFM0QsNkdBQTZHO1lBQzdHLGdGQUFnRjtZQUNoRix3REFBd0Q7WUFFeEQsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztnQkFDakIsTUFBTSxDQUFDLElBQUksQ0FBQztZQUNkLENBQUM7WUFFRCxvREFBb0Q7WUFDcEQsSUFBSSxXQUFXLEdBQUcsaUJBQVMsQ0FBQyxPQUFPLENBQUMsRUFBRSxlQUFlLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUM7WUFDdEUsMkJBQTJCO1lBRTNCLEVBQUUsQ0FBQyxDQUFDLFdBQVcsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDO2dCQUM5Qiw2RUFBNkU7Z0JBQzdFLElBQUksU0FBUyxHQUFHLGlCQUFTLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQztvQkFDMUMsYUFBYSxFQUFFLElBQUksQ0FBQyxNQUFNO2lCQUMzQixDQUFDLENBQUM7Z0JBQ0gsaUVBQWlFO2dCQUNqRSxhQUFhLENBQUMsSUFBSSxFQUFFLFNBQVMsQ0FBQyxDQUFDO2dCQUMvQixNQUFNLENBQUMsSUFBSSxDQUFDO1lBRWQsQ0FBQztZQUVELElBQUksQ0FBQyxDQUFDO2dCQUNKLGtEQUFrRDtnQkFDbEQsYUFBYSxDQUFDLElBQUksRUFBRSxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDdkMsQ0FBQztZQUNELHVDQUF1QztZQUN2Qyx1QkFBdUIsSUFBSSxFQUFFLFNBQVM7Z0JBRXBDLGlCQUFTLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FFekIsU0FBUyxFQUNUO29CQUNFLElBQUksRUFBRTt3QkFDSixTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7d0JBQ3pCLFFBQVEsRUFBRSxJQUFJLENBQUMsUUFBUTt3QkFDdkIsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNO3dCQUNuQixVQUFVLEVBQUUsSUFBSSxDQUFDLFVBQVU7d0JBQzNCLFFBQVEsRUFBRSxJQUFJLENBQUMsUUFBUTtxQkFDeEI7aUJBQ0YsQ0FFRixDQUFDO1lBQ0osQ0FBQyxDQUFDLGlDQUFpQztRQUVyQyxDQUFDO1FBSUQsbUJBQW1CLENBQUMsWUFBWSxFQUFFLFdBQVc7WUFHM0MsaUVBQWlFO1lBQ2pFLHdEQUF3RDtZQUN4RCxVQUFVO1lBQ1YsdUJBQXVCO1lBQ3ZCLDZEQUE2RDtZQUM3RCxpQkFBaUI7WUFDakIsa0VBQWtFO1lBRWxFLElBQUksUUFBUSxHQUFRO2dCQUNsQixRQUFRLEVBQUUsbURBQW1EO2dCQUM3RCxJQUFJLEVBQUUsR0FBRzthQUNWO1lBRUQsMERBQTBEO1lBQzFELGlCQUFpQjtZQUNqQixtQ0FBbUM7WUFDbkMsMERBQTBEO1lBQzFELDJEQUEyRDtZQUMzRCw4Q0FBOEM7WUFDOUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztnQkFDakIsUUFBUSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7Z0JBQ3BCLFFBQVEsQ0FBQyxRQUFRLEdBQUcsZUFBZSxDQUFDO2dCQUNwQyxNQUFNLENBQUMsUUFBUSxDQUFDO1lBQ2xCLENBQUM7WUFDRCxhQUFLLENBQUMsWUFBWSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBRTVCLHFDQUFxQztZQUVyQyxvRkFBb0Y7WUFDcEYsSUFBSSxtQkFBbUIsR0FBRyxLQUFLLENBQUM7WUFFaEMsSUFBSSxXQUFXLEdBQUcsS0FBSyxDQUFDO1lBRXhCLElBQUksZUFBZSxHQUFHLElBQUksZ0NBQWEsRUFBRSxDQUFDO1lBRTFDLFdBQVcsR0FBRyxlQUFlLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLHVCQUF1QjtZQUMvRSxtQkFBbUIsR0FBRyxXQUFXLENBQUM7WUFJbEMsRUFBRSxDQUFDLENBQUMsbUJBQW1CLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQztnQkFDakMsSUFBSSxDQUFDO29CQUVILElBQUksTUFBTSxHQUFHLHdCQUFRLENBQUMsVUFBVSxDQUFDO3dCQUMvQixLQUFLLEVBQUUsWUFBWSxDQUFDLEtBQUs7d0JBQ3pCLFFBQVEsRUFBRSxZQUFZLENBQUMsUUFBUTt3QkFDL0IsT0FBTyxFQUFFOzRCQUNQLFNBQVMsRUFBRSxPQUFPO3lCQUNuQjtxQkFDRixDQUFDLENBQUM7b0JBQ0gsMkJBQTJCO29CQUMzQixXQUFXLENBQUMsWUFBWSxDQUFDLEtBQUssRUFBRSxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQ25ELHlDQUF5QztvQkFDekMsSUFBSSxTQUFTLEdBQUcsaUJBQVMsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDO3dCQUMxQyxhQUFhLEVBQUUsTUFBTTt3QkFDckIsU0FBUyxFQUFFLFdBQVcsQ0FBQyxTQUFTO3dCQUNoQyxRQUFRLEVBQUUsV0FBVyxDQUFDLFFBQVE7d0JBQzlCLE1BQU0sRUFBRSxXQUFXLENBQUMsTUFBTTt3QkFDMUIsVUFBVSxFQUFFLFdBQVcsQ0FBQyxVQUFVO3dCQUNsQyxRQUFRLEVBQUUsV0FBVyxDQUFDLFFBQVE7cUJBQy9CLENBQUMsQ0FBQztvQkFFSCxRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztvQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyxxQkFBcUIsQ0FBQztvQkFDMUMsTUFBTSxDQUFDLFFBQVEsQ0FBQztnQkFDbEIsQ0FDQTtnQkFBQSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUNULFFBQVEsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDO29CQUNwQixRQUFRLENBQUMsUUFBUSxHQUFHLFNBQVMsR0FBRyxDQUFDLENBQUM7b0JBQ2xDLE1BQU0sQ0FBQyxRQUFRLENBQUM7Z0JBQ2xCLENBQUM7WUFFSCxDQUFDLENBQUMsMENBQTBDO1lBQzVDLElBQUksQ0FBQyxDQUFDO2dCQUNKLGtCQUFrQjtnQkFDbEIsUUFBUSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7Z0JBQ3BCLFFBQVEsQ0FBQyxRQUFRLEdBQUcsZUFBZSxDQUFDO1lBQ3RDLENBQUM7WUFHRCxxQkFBcUIsS0FBSyxFQUFFLElBQUk7Z0JBQzlCLElBQUksTUFBTSxHQUFHLGVBQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEVBQUUsZ0JBQWdCLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQztnQkFFL0QsZUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQ2pCLE1BQU0sQ0FBQyxHQUFHLEVBQ1Y7b0JBQ0UsSUFBSSxFQUFFO3dCQUNKLE1BQU0sRUFBRSxJQUFJO3dCQUNaLE9BQU8sRUFBRSxFQUFFO3FCQUNaO2lCQUNGLENBQ0Y7WUFDSCxDQUFDO1lBR0QsTUFBTSxDQUFDLFFBQVEsQ0FBQztRQUdsQixDQUFDO1FBRUQsbUJBQW1CLENBQUMsT0FBTztZQUV6QixpRUFBaUU7WUFDakUsd0RBQXdEO1lBQ3hELFVBQVU7WUFDVix1QkFBdUI7WUFDdkIsNkRBQTZEO1lBQzdELGlCQUFpQjtZQUNqQixrRUFBa0U7WUFFbEUsSUFBSSxRQUFRLEdBQVE7Z0JBQ2xCLFFBQVEsRUFBRSxtREFBbUQ7Z0JBQzdELElBQUksRUFBRSxHQUFHO2FBQ1Y7WUFFRCwwREFBMEQ7WUFDMUQsaUJBQWlCO1lBQ2pCLG1DQUFtQztZQUNuQywwREFBMEQ7WUFDMUQsMkRBQTJEO1lBQzNELDhDQUE4QztZQUM5QyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO2dCQUNqQixRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyxlQUFlLENBQUM7Z0JBQ3BDLE1BQU0sQ0FBQyxRQUFRLENBQUM7WUFDbEIsQ0FBQztZQUVELGFBQUssQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFFdkIscUNBQXFDO1lBRXJDLG9GQUFvRjtZQUNwRixJQUFJLG1CQUFtQixHQUFHLEtBQUssQ0FBQztZQUVoQyxJQUFJLFdBQVcsR0FBRyxLQUFLLENBQUM7WUFFeEIsSUFBSSxlQUFlLEdBQUcsSUFBSSxnQ0FBYSxFQUFFLENBQUM7WUFFMUMsV0FBVyxHQUFHLGVBQWUsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsdUJBQXVCO1lBQy9FLG1CQUFtQixHQUFHLFdBQVcsQ0FBQztZQUlsQyxFQUFFLENBQUMsQ0FBQyxtQkFBbUIsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUNqQyxJQUFJLENBQUM7b0JBRUgsZUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDO29CQUUzQyxpQkFBUyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7b0JBRTlCLFFBQVEsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDO29CQUNwQixRQUFRLENBQUMsUUFBUSxHQUFHLGNBQWMsQ0FBQztvQkFDbkMsTUFBTSxDQUFDLFFBQVEsQ0FBQztnQkFDbEIsQ0FDQTtnQkFBQSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUNULFFBQVEsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDO29CQUNwQixRQUFRLENBQUMsUUFBUSxHQUFHLFNBQVMsR0FBRyxDQUFDLENBQUM7b0JBQ2xDLE1BQU0sQ0FBQyxRQUFRLENBQUM7Z0JBQ2xCLENBQUM7WUFDSCxDQUFDO1lBQ0QsSUFBSSxDQUFDLENBQUM7Z0JBQ0osa0JBQWtCO2dCQUNsQixRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyxlQUFlLENBQUM7WUFDdEMsQ0FBQztZQUVELE1BQU0sQ0FBQyxRQUFRLENBQUM7UUFFbEIsQ0FBQztRQUlELGFBQWEsQ0FBQyxLQUFLLEVBQUUsSUFBSTtZQUN2QixJQUFJLFFBQVEsR0FBUTtnQkFDbEIsUUFBUSxFQUFFLHlEQUF5RDtnQkFDbkUsSUFBSSxFQUFFLEdBQUc7YUFDVjtZQUNELElBQUksTUFBTSxHQUFHLGVBQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEVBQUUsZ0JBQWdCLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQztZQUUvRCxFQUFFLENBQUMsQ0FBQyxNQUFNLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQztnQkFDeEIsZUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQ2pCLE1BQU0sQ0FBQyxHQUFHLEVBQ1Y7b0JBQ0UsSUFBSSxFQUFFO3dCQUNKLE1BQU0sRUFBRSxJQUFJO3dCQUNaLE9BQU8sRUFBRSxFQUFFO3FCQUNaO2lCQUNGLENBQ0Y7Z0JBQ0QsUUFBUSxDQUFDLFFBQVEsR0FBRyxJQUFJLEdBQUcsZ0JBQWdCLENBQUM7Z0JBQzVDLFFBQVEsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDO2dCQUNwQixNQUFNLENBQUMsUUFBUSxDQUFDO1lBQ2xCLENBQUM7WUFFRCxNQUFNLENBQUMsUUFBUSxDQUFDO1FBQ2xCLENBQUM7UUFFRCx1QkFBdUI7WUFFckIsSUFBSSxRQUFRLEdBQVE7Z0JBQ2xCLFFBQVEsRUFBRSxtREFBbUQ7Z0JBQzdELElBQUksRUFBRSxHQUFHO2FBQ1Y7WUFFRCxJQUFJLENBQUM7Z0JBQ0gsZUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQ2pCLEVBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUMsRUFDbEI7b0JBQ0UsSUFBSSxFQUNKO3dCQUNFLG1CQUFtQixFQUFFLElBQUksSUFBSSxFQUFFO3FCQUNoQztpQkFDRixDQUNGLENBQUM7Z0JBQ0YsUUFBUSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7Z0JBQ3BCLFFBQVEsQ0FBQyxRQUFRLEdBQUcseUJBQXlCLENBQUM7Z0JBQzlDLE1BQU0sQ0FBQyxRQUFRLENBQUM7WUFFbEIsQ0FDQTtZQUFBLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ1QsUUFBUSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7Z0JBQ3BCLFFBQVEsQ0FBQyxRQUFRLEdBQUcsU0FBUyxHQUFHLENBQUMsQ0FBQztnQkFDbEMsTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNsQixDQUFDO1lBQ0Qsc0NBQXNDO1FBQ3hDLENBQUM7UUFFRCxpQkFBaUIsQ0FBRSxZQUFZLEVBQUUsWUFBWTtZQUMzQyxPQUFPLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBQzFCLElBQUksUUFBUSxHQUFRO2dCQUNsQixRQUFRLEVBQUUseURBQXlEO2dCQUNuRSxJQUFJLEVBQUUsR0FBRzthQUNWO1lBQ0QsSUFBSSxNQUFNLEdBQUcsZUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsRUFBRSxnQkFBZ0IsRUFBRSxZQUFZLEVBQUUsQ0FBQyxDQUFDO1lBRXRFLEVBQUUsQ0FBQyxDQUFDLE1BQU0sSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDO2dCQUN4QixlQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FDakIsTUFBTSxDQUFDLEdBQUcsRUFDVjtvQkFDRSxJQUFJLEVBQUU7d0JBQ0osT0FBTyxFQUFFLFlBQVk7cUJBQ3RCO2lCQUNGLENBQ0Y7Z0JBQ0QsUUFBUSxDQUFDLFFBQVEsR0FBRyxvREFBb0QsQ0FBQztnQkFDekUsUUFBUSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7Z0JBQ3BCLE1BQU0sQ0FBQyxRQUFRLENBQUM7WUFDbEIsQ0FBQztZQUFDLElBQUksQ0FBQyxDQUFDO2dCQUNOLFFBQVEsQ0FBQyxRQUFRLEdBQUcsMkNBQTJDLENBQUM7Z0JBQ2hFLFFBQVEsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDO1lBQ3RCLENBQUM7WUFFRCxNQUFNLENBQUMsUUFBUSxDQUFDO1FBQ2xCLENBQUM7S0FPRixDQUFDLENBQUMsQ0FBQyx3QkFBd0I7QUFFOUIsQ0FBQyxDQUFDLHlCQUF5Qjs7Ozs7Ozs7Ozs7O0FDaGMzQix5QkFBdUIsZUFBZSxDQUFDO0FBSXZDLHdCQUFzQixjQUFjLENBQUM7QUFDckMsbUNBQThCLHNDQUFzQyxDQUFDO0FBQ3JFLHdCQUEyQixvQkFBb0IsQ0FBQztBQUdoRCxFQUFFLENBQUMsQ0FBQyxlQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztJQUVwQixlQUFNLENBQUMsT0FBTyxDQUFDO1FBQ2IseUJBQXlCLENBQUMsSUFBSTtZQUM1QixpRUFBaUU7WUFDakUsd0RBQXdEO1lBQ3hELFVBQVU7WUFDVix1QkFBdUI7WUFDdkIsNkRBQTZEO1lBQzdELGlCQUFpQjtZQUNqQixrRUFBa0U7WUFFbEUsSUFBSSxRQUFRLEdBQVE7Z0JBQ2xCLFFBQVEsRUFBRSxtREFBbUQ7Z0JBQzdELElBQUksRUFBRSxHQUFHO2FBQ1Y7WUFFRCwwREFBMEQ7WUFDMUQsaUJBQWlCO1lBQ2pCLGlEQUFpRDtZQUNqRCwwREFBMEQ7WUFDMUQsMkRBQTJEO1lBQzNELDhDQUE4QztZQUM5QyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO2dCQUNqQixRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyxlQUFlLENBQUM7Z0JBQ3BDLE1BQU0sQ0FBQyxRQUFRLENBQUM7WUFDbEIsQ0FBQztZQUNELGFBQUssQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFFcEIscUNBQXFDO1lBRXJDLG9GQUFvRjtZQUNwRixJQUFJLG1CQUFtQixHQUFHLEtBQUssQ0FBQztZQUVoQyxJQUFJLFdBQVcsR0FBRyxLQUFLLENBQUM7WUFDeEIsSUFBSSxhQUFhLEdBQUcsS0FBSyxDQUFDO1lBRTFCLElBQUksZUFBZSxHQUFHLElBQUksZ0NBQWEsRUFBRSxDQUFDO1lBRTFDLFdBQVcsR0FBRyxlQUFlLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLHVCQUF1QjtZQUMvRSxhQUFhLEdBQUcsZUFBZSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyx5QkFBeUI7WUFFckYsRUFBRSxDQUFDLENBQUMsV0FBVyxJQUFJLGFBQWEsQ0FBQyxDQUFDLENBQUM7Z0JBQ2pDLG1CQUFtQixHQUFHLElBQUksQ0FBQztZQUM3QixDQUFDO1lBQ0QscUNBQXFDO1lBRXJDLEVBQUUsQ0FBQyxDQUFDLG1CQUFtQixLQUFLLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBRWpDLHFDQUFxQztnQkFDckMsa0JBQVUsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDO29CQUUzQixRQUFRLEVBQUUsSUFBSSxDQUFDLFFBQVE7b0JBQ3ZCLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTztvQkFDckIsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPO29CQUNyQixRQUFRLEVBQUUsSUFBSSxDQUFDLFFBQVE7b0JBQ3ZCLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTztvQkFDckIsWUFBWSxFQUFFLElBQUksQ0FBQyxZQUFZO29CQUMvQixLQUFLLEVBQUUsSUFBSSxDQUFDLEtBQUs7b0JBQ2pCLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTztvQkFDckIsVUFBVSxFQUFFLElBQUksQ0FBQyxVQUFVO29CQUMzQixPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU87b0JBQ3JCLFNBQVMsRUFBRSxJQUFJLElBQUksRUFBRTtpQkFFdEIsQ0FBQyxDQUFDLENBQUMsWUFBWTtnQkFDaEIsUUFBUSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7Z0JBQ3BCLFFBQVEsQ0FBQyxRQUFRLEdBQUcsZ0NBQWdDLENBQUM7Z0JBQ3JELE1BQU0sQ0FBQyxRQUFRLENBQUM7WUFDbEIsQ0FBQyxDQUFDLDBDQUEwQztZQUM1QyxJQUFJLENBQUMsQ0FBQztnQkFDSixrQkFBa0I7Z0JBQ2xCLFFBQVEsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDO2dCQUNwQixRQUFRLENBQUMsUUFBUSxHQUFHLGVBQWUsQ0FBQztZQUN0QyxDQUFDO1lBQ0QsTUFBTSxDQUFDLFFBQVEsQ0FBQztRQUVsQixDQUFDO1FBRUQsZ0JBQWdCLENBQUMsSUFBSTtZQUNuQixpRUFBaUU7WUFDakUsd0RBQXdEO1lBQ3hELFVBQVU7WUFDVix1QkFBdUI7WUFDdkIsNkRBQTZEO1lBQzdELGlCQUFpQjtZQUNqQixrRUFBa0U7WUFFbEUsSUFBSSxRQUFRLEdBQVE7Z0JBQ2xCLFFBQVEsRUFBRSxtREFBbUQ7Z0JBQzdELElBQUksRUFBRSxHQUFHO2FBQ1Y7WUFFRCwwREFBMEQ7WUFDMUQsaUJBQWlCO1lBQ2pCLGlEQUFpRDtZQUNqRCwwREFBMEQ7WUFDMUQsMkRBQTJEO1lBQzNELDhDQUE4QztZQUM5QyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO2dCQUNqQixRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyxlQUFlLENBQUM7Z0JBQ3BDLE1BQU0sQ0FBQyxRQUFRLENBQUM7WUFDbEIsQ0FBQztZQUNELGFBQUssQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFFcEIscUNBQXFDO1lBRXJDLG9GQUFvRjtZQUNwRixJQUFJLG1CQUFtQixHQUFHLEtBQUssQ0FBQztZQUVoQyxJQUFJLFdBQVcsR0FBRyxLQUFLLENBQUM7WUFDeEIsSUFBSSxhQUFhLEdBQUcsS0FBSyxDQUFDO1lBRTFCLElBQUksZUFBZSxHQUFHLElBQUksZ0NBQWEsRUFBRSxDQUFDO1lBRTFDLFdBQVcsR0FBRyxlQUFlLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLHVCQUF1QjtZQUMvRSxhQUFhLEdBQUcsZUFBZSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyx5QkFBeUI7WUFFckYsRUFBRSxDQUFDLENBQUMsV0FBVyxJQUFJLGFBQWEsQ0FBQyxDQUFDLENBQUM7Z0JBQ2pDLG1CQUFtQixHQUFHLElBQUksQ0FBQztZQUM3QixDQUFDO1lBQ0QscUNBQXFDO1lBRXJDLEVBQUUsQ0FBQyxDQUFDLG1CQUFtQixLQUFLLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBQ2pDLHFDQUFxQztnQkFDckMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDbEIsSUFBSSxPQUFPLEdBQUcsa0JBQVUsQ0FBQyxPQUFPLENBQUMsRUFBQyxVQUFVLEVBQUMsSUFBSSxDQUFDLFFBQVEsRUFBQyxDQUFDLENBQUM7Z0JBQzdELEVBQUUsQ0FBQyxDQUFDLE9BQU8sSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDO29CQUN6QixrQkFBVSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQzFCLE9BQU8sQ0FBQyxHQUFHLEVBQ1g7d0JBQ0UsSUFBSSxFQUNGOzRCQUNFLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTzs0QkFDckIsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPOzRCQUNyQixRQUFRLEVBQUUsSUFBSSxDQUFDLFFBQVE7NEJBQ3ZCLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTzs0QkFDckIsWUFBWSxFQUFFLElBQUksQ0FBQyxZQUFZOzRCQUMvQixLQUFLLEVBQUUsSUFBSSxDQUFDLEtBQUs7NEJBQ2pCLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTzs0QkFDckIsVUFBVSxFQUFFLElBQUksQ0FBQyxVQUFVOzRCQUMzQixPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU87NEJBQ3JCLFNBQVMsRUFBRSxJQUFJLElBQUksRUFBRTt5QkFDdEI7cUJBQ0osQ0FBQyxDQUFDLENBQUMsYUFBYTtnQkFDckIsQ0FBQztnQkFLRCxRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRywwQkFBMEIsQ0FBQztnQkFDL0MsTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUdsQixDQUFDLENBQUMsMENBQTBDO1lBQzVDLElBQUksQ0FBQyxDQUFDO2dCQUNKLGtCQUFrQjtnQkFDbEIsUUFBUSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7Z0JBQ3BCLFFBQVEsQ0FBQyxRQUFRLEdBQUcsZUFBZSxDQUFDO1lBQ3RDLENBQUM7WUFDRCxNQUFNLENBQUMsUUFBUSxDQUFDO1FBQ2xCLENBQUM7UUFFRCx1QkFBdUIsQ0FBQyxJQUFJO1lBQzFCLGlFQUFpRTtZQUNqRSx3REFBd0Q7WUFDeEQsVUFBVTtZQUNWLHVCQUF1QjtZQUN2Qiw2REFBNkQ7WUFDN0QsaUJBQWlCO1lBQ2pCLGtFQUFrRTtZQUVsRSxJQUFJLFFBQVEsR0FBUTtnQkFDbEIsUUFBUSxFQUFFLG1EQUFtRDtnQkFDN0QsSUFBSSxFQUFFLEdBQUc7YUFDVjtZQUVELDBEQUEwRDtZQUMxRCxpQkFBaUI7WUFDakIsaURBQWlEO1lBQ2pELDBEQUEwRDtZQUMxRCwyREFBMkQ7WUFDM0QsOENBQThDO1lBQzlDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7Z0JBQ2pCLFFBQVEsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDO2dCQUNwQixRQUFRLENBQUMsUUFBUSxHQUFHLGVBQWUsQ0FBQztnQkFDcEMsTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNsQixDQUFDO1lBQ0QsYUFBSyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQztZQUVwQixxQ0FBcUM7WUFFckMsb0ZBQW9GO1lBQ3BGLElBQUksbUJBQW1CLEdBQUcsS0FBSyxDQUFDO1lBRWhDLElBQUksV0FBVyxHQUFHLEtBQUssQ0FBQztZQUN4QixJQUFJLGFBQWEsR0FBRyxLQUFLLENBQUM7WUFFMUIsSUFBSSxlQUFlLEdBQUcsSUFBSSxnQ0FBYSxFQUFFLENBQUM7WUFFMUMsV0FBVyxHQUFHLGVBQWUsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsdUJBQXVCO1lBQy9FLGFBQWEsR0FBRyxlQUFlLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLHlCQUF5QjtZQUVyRixFQUFFLENBQUMsQ0FBQyxXQUFXLElBQUksYUFBYSxDQUFDLENBQUMsQ0FBQztnQkFDakMsbUJBQW1CLEdBQUcsSUFBSSxDQUFDO1lBQzdCLENBQUM7WUFFRCxFQUFFLENBQUMsQ0FBQyxtQkFBbUIsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUVqQyxxQ0FBcUM7Z0JBQ3JDLGtCQUFVLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQztvQkFFM0IsUUFBUSxFQUFFLElBQUksQ0FBQyxRQUFRO29CQUN2QixPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU87b0JBQ3JCLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTztvQkFDckIsUUFBUSxFQUFFLElBQUksQ0FBQyxRQUFRO29CQUN2QixPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU87b0JBQ3JCLFlBQVksRUFBRSxJQUFJLENBQUMsWUFBWTtvQkFDL0IsS0FBSyxFQUFFLElBQUksQ0FBQyxLQUFLO29CQUNqQixPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU87b0JBQ3JCLFVBQVUsRUFBRSxJQUFJLENBQUMsVUFBVTtvQkFDM0IsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPO29CQUNyQixTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUU7aUJBRXRCLENBQUMsQ0FBQyxDQUFDLFlBQVk7Z0JBQ2hCLFFBQVEsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDO2dCQUNwQixRQUFRLENBQUMsUUFBUSxHQUFHLDhCQUE4QixDQUFDO2dCQUNuRCxNQUFNLENBQUMsUUFBUSxDQUFDO1lBQ2xCLENBQUMsQ0FBQywwQ0FBMEM7WUFDNUMsSUFBSSxDQUFDLENBQUM7Z0JBQ0osa0JBQWtCO2dCQUNsQixRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyxlQUFlLENBQUM7WUFDdEMsQ0FBQztZQUNELE1BQU0sQ0FBQyxRQUFRLENBQUM7UUFDbEIsQ0FBQztRQUVELG1CQUFtQjtZQUNqQixNQUFNLENBQUMsa0JBQVUsQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDOUMsQ0FBQztRQUVELHNCQUFzQjtZQUNsQixNQUFNLENBQUMsa0JBQVUsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLEVBQUMsU0FBUyxFQUFDLEVBQUUsRUFBQyxDQUFDLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDOUQsQ0FBQztLQUdGLENBQUMsQ0FBQyxDQUFDLHdCQUF3QjtBQUU5QixDQUFDLENBQUMseUJBQXlCOzs7Ozs7Ozs7Ozs7QUNuUTNCLDhFQUE4RTtBQUM5RSx5QkFBdUIsZUFBZSxDQUFDO0FBSXZDLHdCQUFzQixjQUFjLENBQUM7QUFDckMsbUNBQThCLHNDQUFzQyxDQUFDO0FBQ3JFLHdCQUErQyxvQkFBb0IsQ0FBQztBQUdwRSxFQUFFLENBQUMsQ0FBQyxlQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztJQUVwQixlQUFNLENBQUMsT0FBTyxDQUFDO1FBR2IsbUJBQW1CLENBQUMsVUFBVTtZQUM1QixpRUFBaUU7WUFDakUsd0RBQXdEO1lBQ3hELFVBQVU7WUFDVixzQkFBc0I7WUFDdEIsNkRBQTZEO1lBQzdELG9DQUFvQztZQUNwQyxrRUFBa0U7WUFDbEUsSUFBSSxRQUFRLEdBQVE7Z0JBQ2xCLFFBQVEsRUFBRSwyREFBMkQ7Z0JBQ3JFLElBQUksRUFBRSxHQUFHO2FBQ1Y7WUFFRCxJQUFJLGNBQWMsR0FBRyxnQkFBUSxDQUFDLE9BQU8sQ0FBQyxFQUFFLE1BQU0sRUFBRSxVQUFVLEVBQUUsQ0FBQyxDQUFDO1lBRzlELEVBQUUsQ0FBQyxDQUFDLGNBQWMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDO2dCQUNqQyxRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyxpREFBaUQsQ0FBQztnQkFDdEUsTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNsQixDQUFDO1lBQ0QsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLGNBQWMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDO2dCQUN0QyxRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyw2Q0FBNkMsQ0FBQztnQkFDbEUsTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNsQixDQUFDO1lBQ0QsSUFBSSxDQUFDLENBQUM7Z0JBQ0osTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNsQixDQUFDO1FBQ0gsQ0FBQztRQUVELGNBQWMsQ0FBQyxJQUFJO1lBQ2pCLGlFQUFpRTtZQUNqRSx3REFBd0Q7WUFDeEQsVUFBVTtZQUNWLHVCQUF1QjtZQUN2Qiw2REFBNkQ7WUFDN0QsaUJBQWlCO1lBQ2pCLGtFQUFrRTtZQUVsRSxJQUFJLFFBQVEsR0FBUTtnQkFDbEIsUUFBUSxFQUFFLG1EQUFtRDtnQkFDN0QsSUFBSSxFQUFFLEdBQUc7YUFDVjtZQUVELDBEQUEwRDtZQUMxRCxpQkFBaUI7WUFDakIscUNBQXFDO1lBQ3JDLDBEQUEwRDtZQUMxRCwyREFBMkQ7WUFDM0QsOENBQThDO1lBQzlDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7Z0JBQ2pCLFFBQVEsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDO2dCQUNwQixRQUFRLENBQUMsUUFBUSxHQUFHLGVBQWUsQ0FBQztnQkFDcEMsTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNsQixDQUFDO1lBQ0QsYUFBSyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQztZQUVwQixxQ0FBcUM7WUFFckMsb0ZBQW9GO1lBQ3BGLElBQUksbUJBQW1CLEdBQUcsS0FBSyxDQUFDO1lBRWhDLElBQUksV0FBVyxHQUFHLEtBQUssQ0FBQztZQUV4QixJQUFJLGVBQWUsR0FBRyxJQUFJLGdDQUFhLEVBQUUsQ0FBQztZQUUxQyxXQUFXLEdBQUcsZUFBZSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyx1QkFBdUI7WUFDL0UsbUJBQW1CLEdBQUcsV0FBVyxDQUFDO1lBRWxDLEVBQUUsQ0FBQyxDQUFDLG1CQUFtQixLQUFLLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBRWpDLHFDQUFxQztnQkFDckMsZ0JBQVEsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDO29CQUV6QixJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUk7b0JBQ2YsV0FBVyxFQUFFLElBQUksQ0FBQyxXQUFXO29CQUM3QixTQUFTLEVBQUUsZUFBTSxDQUFDLElBQUksRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPO29CQUMxQyxTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUU7aUJBRXRCLENBQUMsQ0FBQyxDQUFDLFlBQVk7Z0JBQ2hCLFFBQVEsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDO2dCQUNwQixRQUFRLENBQUMsUUFBUSxHQUFHLGtDQUFrQyxDQUFDO2dCQUN2RCxNQUFNLENBQUMsUUFBUSxDQUFDO1lBQ2xCLENBQUMsQ0FBQywwQ0FBMEM7WUFDNUMsSUFBSSxDQUFDLENBQUM7Z0JBQ0osa0JBQWtCO2dCQUNsQixRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyxlQUFlLENBQUM7WUFDdEMsQ0FBQztZQUNELE1BQU0sQ0FBQyxRQUFRLENBQUM7UUFJbEIsQ0FBQztRQUVELGNBQWMsQ0FBQyxJQUFJO1lBQ2pCLGlFQUFpRTtZQUNqRSx3REFBd0Q7WUFDeEQsVUFBVTtZQUNWLHVCQUF1QjtZQUN2Qiw2REFBNkQ7WUFDN0QsaUJBQWlCO1lBQ2pCLGtFQUFrRTtZQUVsRSxJQUFJLFFBQVEsR0FBUTtnQkFDbEIsUUFBUSxFQUFFLG1EQUFtRDtnQkFDN0QsSUFBSSxFQUFFLEdBQUc7YUFDVjtZQUVELDBEQUEwRDtZQUMxRCxpQkFBaUI7WUFDakIsc0NBQXNDO1lBQ3RDLDBEQUEwRDtZQUMxRCwyREFBMkQ7WUFDM0QsOENBQThDO1lBQzlDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7Z0JBQ2pCLFFBQVEsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDO2dCQUNwQixRQUFRLENBQUMsUUFBUSxHQUFHLGVBQWUsQ0FBQztnQkFDcEMsTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNsQixDQUFDO1lBQ0QsYUFBSyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQztZQUVwQixxQ0FBcUM7WUFFckMsb0ZBQW9GO1lBQ3BGLElBQUksbUJBQW1CLEdBQUcsS0FBSyxDQUFDO1lBRWhDLElBQUksV0FBVyxHQUFHLEtBQUssQ0FBQztZQUV4QixJQUFJLGVBQWUsR0FBRyxJQUFJLGdDQUFhLEVBQUUsQ0FBQztZQUUxQyxXQUFXLEdBQUcsZUFBZSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyx1QkFBdUI7WUFDL0UsbUJBQW1CLEdBQUcsV0FBVyxDQUFDO1lBRWxDLEVBQUUsQ0FBQyxDQUFDLG1CQUFtQixLQUFLLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBRWpDLHFDQUFxQztnQkFDckMsZ0JBQVEsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUN4QixJQUFJLENBQUMsR0FBRyxFQUNSO29CQUNFLElBQUksRUFDRjt3QkFDRSxJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUk7d0JBQ2YsV0FBVyxFQUFFLElBQUksQ0FBQyxXQUFXO3dCQUM3QixTQUFTLEVBQUUsZUFBTSxDQUFDLElBQUksRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPO3dCQUMxQyxTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUU7cUJBQ3RCO2lCQUNKLENBQUMsQ0FBQyxDQUFDLGFBQWE7Z0JBR25CLFFBQVEsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDO2dCQUNwQixRQUFRLENBQUMsUUFBUSxHQUFHLDRCQUE0QixDQUFDO2dCQUNqRCxNQUFNLENBQUMsUUFBUSxDQUFDO1lBQ2xCLENBQUMsQ0FBQywwQ0FBMEM7WUFDNUMsSUFBSSxDQUFDLENBQUM7Z0JBQ0osa0JBQWtCO2dCQUNsQixRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyxlQUFlLENBQUM7WUFDdEMsQ0FBQztZQUNELE1BQU0sQ0FBQyxRQUFRLENBQUM7UUFDbEIsQ0FBQztRQUVELG9CQUFvQixDQUFDLFFBQVE7WUFDM0IsaUVBQWlFO1lBQ2pFLHdEQUF3RDtZQUN4RCxVQUFVO1lBQ1YsK0JBQStCO1lBQy9CLDZEQUE2RDtZQUM3RCwyQkFBMkI7WUFDM0Isa0VBQWtFO1lBRWxFLElBQUksUUFBUSxHQUFRO2dCQUNsQixRQUFRLEVBQUUsMkRBQTJEO2dCQUNyRSxJQUFJLEVBQUUsR0FBRzthQUNWO1lBRUQsSUFBSSxXQUFXLEdBQUcsaUJBQVMsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLEVBQUUsVUFBVSxFQUFFLFFBQVEsRUFBRSxDQUFDLENBQUMsS0FBSyxFQUFFLENBQUM7WUFFOUUsRUFBRSxDQUFDLENBQUMsV0FBVyxLQUFLLFNBQVMsSUFBSSxXQUFXLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDakQsUUFBUSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7Z0JBQ3BCLFFBQVEsQ0FBQyxRQUFRLEdBQUcsaUVBQWlFLENBQUM7Z0JBQ3RGLE1BQU0sQ0FBQyxRQUFRLENBQUM7WUFDbEIsQ0FBQztZQUNELElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxXQUFXLEtBQUssU0FBUyxJQUFJLFdBQVcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUN4RCxRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyxzQ0FBc0MsQ0FBQztnQkFDM0QsTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNsQixDQUFDO1lBQ0QsSUFBSSxDQUFDLENBQUM7Z0JBQ0osTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNsQixDQUFDO1FBQ0gsQ0FBQztRQUVELGNBQWMsQ0FBQyxJQUFJO1lBQ2pCLGlFQUFpRTtZQUNqRSx3REFBd0Q7WUFDeEQsVUFBVTtZQUNWLHVCQUF1QjtZQUN2Qiw2REFBNkQ7WUFDN0QsaUJBQWlCO1lBQ2pCLGtFQUFrRTtZQUVsRSxJQUFJLFFBQVEsR0FBUTtnQkFDbEIsUUFBUSxFQUFFLG1EQUFtRDtnQkFDN0QsSUFBSSxFQUFFLEdBQUc7YUFDVjtZQUVELDBEQUEwRDtZQUMxRCxpQkFBaUI7WUFDakIsc0NBQXNDO1lBQ3RDLDBEQUEwRDtZQUMxRCwyREFBMkQ7WUFDM0QsOENBQThDO1lBQzlDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7Z0JBQ2pCLFFBQVEsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDO2dCQUNwQixRQUFRLENBQUMsUUFBUSxHQUFHLGVBQWUsQ0FBQztnQkFDcEMsTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNsQixDQUFDO1lBQ0QsYUFBSyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQztZQUVwQixxQ0FBcUM7WUFFckMsb0ZBQW9GO1lBQ3BGLElBQUksbUJBQW1CLEdBQUcsS0FBSyxDQUFDO1lBRWhDLElBQUksV0FBVyxHQUFHLEtBQUssQ0FBQztZQUV4QixJQUFJLGVBQWUsR0FBRyxJQUFJLGdDQUFhLEVBQUUsQ0FBQztZQUUxQyxXQUFXLEdBQUcsZUFBZSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyx1QkFBdUI7WUFDL0UsbUJBQW1CLEdBQUcsV0FBVyxDQUFDO1lBRWxDLEVBQUUsQ0FBQyxDQUFDLG1CQUFtQixLQUFLLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBQ2pDLGdCQUFRLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBRXJDLFFBQVEsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDO2dCQUNwQixRQUFRLENBQUMsUUFBUSxHQUFHLDRCQUE0QixDQUFDO2dCQUNqRCxNQUFNLENBQUMsUUFBUSxDQUFDO1lBQ2xCLENBQUM7WUFDRCxJQUFJLENBQUMsQ0FBQztnQkFDSixrQkFBa0I7Z0JBQ2xCLFFBQVEsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDO2dCQUNwQixRQUFRLENBQUMsUUFBUSxHQUFHLGVBQWUsQ0FBQztZQUN0QyxDQUFDO1lBQ0QsTUFBTSxDQUFDLFFBQVEsQ0FBQztRQUNsQixDQUFDO1FBRUQsa0JBQWtCO1lBQ2hCLE1BQU0sQ0FBQyxnQkFBUSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUNuQyxDQUFDO0tBR0YsQ0FBQyxDQUFDLENBQUMsd0JBQXdCO0FBRTlCLENBQUMsQ0FBQyx5QkFBeUI7Ozs7Ozs7Ozs7OztBQzlRM0IsOEVBQThFO0FBQzlFLHlCQUF1QixlQUFlLENBQUM7QUFJdkMsd0JBQXNCLGNBQWMsQ0FBQztBQUNyQyxtQ0FBOEIsc0NBQXNDLENBQUM7QUFDckUsd0JBQW1ELG9CQUFvQixDQUFDO0FBR3hFLEVBQUUsQ0FBQyxDQUFDLGVBQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0lBRXBCLGVBQU0sQ0FBQyxPQUFPLENBQUM7UUFHYix1QkFBdUIsQ0FBQyxjQUFjO1lBQ3BDLGlFQUFpRTtZQUNqRSx3REFBd0Q7WUFDeEQsVUFBVTtZQUNWLHNCQUFzQjtZQUN0Qiw2REFBNkQ7WUFDN0Qsd0NBQXdDO1lBQ3hDLGtFQUFrRTtZQUNsRSxJQUFJLFFBQVEsR0FBUTtnQkFDbEIsUUFBUSxFQUFFLDJEQUEyRDtnQkFDckUsSUFBSSxFQUFFLEdBQUc7YUFDVjtZQUVELElBQUksa0JBQWtCLEdBQUcsb0JBQVksQ0FBQyxPQUFPLENBQUMsRUFBRSxNQUFNLEVBQUUsY0FBYyxFQUFFLENBQUMsQ0FBQztZQUcxRSxFQUFFLENBQUMsQ0FBQyxrQkFBa0IsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDO2dCQUNyQyxRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyxxREFBcUQsQ0FBQztnQkFDMUUsTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNsQixDQUFDO1lBQ0QsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLGtCQUFrQixLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUM7Z0JBQzFDLFFBQVEsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDO2dCQUNwQixRQUFRLENBQUMsUUFBUSxHQUFHLGlEQUFpRCxDQUFDO2dCQUN0RSxNQUFNLENBQUMsUUFBUSxDQUFDO1lBQ2xCLENBQUM7WUFDRCxJQUFJLENBQUMsQ0FBQztnQkFDSixNQUFNLENBQUMsUUFBUSxDQUFDO1lBQ2xCLENBQUM7UUFDSCxDQUFDO1FBRUQsa0JBQWtCLENBQUMsSUFBSTtZQUNyQixpRUFBaUU7WUFDakUsd0RBQXdEO1lBQ3hELFVBQVU7WUFDVix1QkFBdUI7WUFDdkIsNkRBQTZEO1lBQzdELGlCQUFpQjtZQUNqQixrRUFBa0U7WUFFbEUsSUFBSSxRQUFRLEdBQVE7Z0JBQ2xCLFFBQVEsRUFBRSxtREFBbUQ7Z0JBQzdELElBQUksRUFBRSxHQUFHO2FBQ1Y7WUFFRCwwREFBMEQ7WUFDMUQsaUJBQWlCO1lBQ2pCLHlDQUF5QztZQUN6QywwREFBMEQ7WUFDMUQsMkRBQTJEO1lBQzNELDhDQUE4QztZQUM5QyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO2dCQUNqQixRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyxlQUFlLENBQUM7Z0JBQ3BDLE1BQU0sQ0FBQyxRQUFRLENBQUM7WUFDbEIsQ0FBQztZQUNELGFBQUssQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFFcEIscUNBQXFDO1lBRXJDLG9GQUFvRjtZQUNwRixJQUFJLG1CQUFtQixHQUFHLEtBQUssQ0FBQztZQUVoQyxJQUFJLFdBQVcsR0FBRyxLQUFLLENBQUM7WUFFeEIsSUFBSSxlQUFlLEdBQUcsSUFBSSxnQ0FBYSxFQUFFLENBQUM7WUFFMUMsV0FBVyxHQUFHLGVBQWUsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsdUJBQXVCO1lBQy9FLG1CQUFtQixHQUFHLFdBQVcsQ0FBQztZQUVsQyxFQUFFLENBQUMsQ0FBQyxtQkFBbUIsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUVqQyxxQ0FBcUM7Z0JBQ3JDLG9CQUFZLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQztvQkFFN0IsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJO29CQUNmLFdBQVcsRUFBRSxJQUFJLENBQUMsV0FBVztvQkFDN0IsU0FBUyxFQUFFLGVBQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTztvQkFDMUMsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFO2lCQUV0QixDQUFDLENBQUMsQ0FBQyxZQUFZO2dCQUNoQixRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyxzQ0FBc0MsQ0FBQztnQkFDM0QsTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNsQixDQUFDLENBQUMsMENBQTBDO1lBQzVDLElBQUksQ0FBQyxDQUFDO2dCQUNKLGtCQUFrQjtnQkFDbEIsUUFBUSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7Z0JBQ3BCLFFBQVEsQ0FBQyxRQUFRLEdBQUcsZUFBZSxDQUFDO1lBQ3RDLENBQUM7WUFDRCxNQUFNLENBQUMsUUFBUSxDQUFDO1FBSWxCLENBQUM7UUFFRCxrQkFBa0IsQ0FBQyxJQUFJO1lBQ3JCLGlFQUFpRTtZQUNqRSx3REFBd0Q7WUFDeEQsVUFBVTtZQUNWLHVCQUF1QjtZQUN2Qiw2REFBNkQ7WUFDN0QsaUJBQWlCO1lBQ2pCLGtFQUFrRTtZQUVsRSxJQUFJLFFBQVEsR0FBUTtnQkFDbEIsUUFBUSxFQUFFLG1EQUFtRDtnQkFDN0QsSUFBSSxFQUFFLEdBQUc7YUFDVjtZQUVELDBEQUEwRDtZQUMxRCxpQkFBaUI7WUFDakIscUNBQXFDO1lBQ3JDLDBEQUEwRDtZQUMxRCwyREFBMkQ7WUFDM0QsOENBQThDO1lBQzlDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7Z0JBQ2pCLFFBQVEsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDO2dCQUNwQixRQUFRLENBQUMsUUFBUSxHQUFHLGVBQWUsQ0FBQztnQkFDcEMsTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNsQixDQUFDO1lBQ0QsYUFBSyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQztZQUVwQixxQ0FBcUM7WUFFckMsb0ZBQW9GO1lBQ3BGLElBQUksbUJBQW1CLEdBQUcsS0FBSyxDQUFDO1lBRWhDLElBQUksV0FBVyxHQUFHLEtBQUssQ0FBQztZQUV4QixJQUFJLGVBQWUsR0FBRyxJQUFJLGdDQUFhLEVBQUUsQ0FBQztZQUUxQyxXQUFXLEdBQUcsZUFBZSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyx1QkFBdUI7WUFDL0UsbUJBQW1CLEdBQUcsV0FBVyxDQUFDO1lBRWxDLEVBQUUsQ0FBQyxDQUFDLG1CQUFtQixLQUFLLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBRWpDLHFDQUFxQztnQkFDckMsb0JBQVksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUM1QixJQUFJLENBQUMsR0FBRyxFQUNSO29CQUNFLElBQUksRUFDRjt3QkFDRSxJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUk7d0JBQ2YsV0FBVyxFQUFFLElBQUksQ0FBQyxXQUFXO3dCQUM3QixTQUFTLEVBQUUsZUFBTSxDQUFDLElBQUksRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPO3dCQUMxQyxTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUU7cUJBQ3RCO2lCQUNKLENBQUMsQ0FBQyxDQUFDLGFBQWE7Z0JBR25CLFFBQVEsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDO2dCQUNwQixRQUFRLENBQUMsUUFBUSxHQUFHLDJCQUEyQixDQUFDO2dCQUNoRCxNQUFNLENBQUMsUUFBUSxDQUFDO1lBQ2xCLENBQUMsQ0FBQywwQ0FBMEM7WUFDNUMsSUFBSSxDQUFDLENBQUM7Z0JBQ0osa0JBQWtCO2dCQUNsQixRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyxlQUFlLENBQUM7WUFDdEMsQ0FBQztZQUNELE1BQU0sQ0FBQyxRQUFRLENBQUM7UUFDbEIsQ0FBQztRQUVELGtCQUFrQixDQUFDLElBQUk7WUFDckIsaUVBQWlFO1lBQ2pFLHdEQUF3RDtZQUN4RCxVQUFVO1lBQ1YsdUJBQXVCO1lBQ3ZCLDZEQUE2RDtZQUM3RCxpQkFBaUI7WUFDakIsa0VBQWtFO1lBRWxFLElBQUksUUFBUSxHQUFRO2dCQUNsQixRQUFRLEVBQUUsbURBQW1EO2dCQUM3RCxJQUFJLEVBQUUsR0FBRzthQUNWO1lBRUQsMERBQTBEO1lBQzFELGlCQUFpQjtZQUNqQiwwQ0FBMEM7WUFDMUMsMERBQTBEO1lBQzFELDJEQUEyRDtZQUMzRCw4Q0FBOEM7WUFDOUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztnQkFDakIsUUFBUSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7Z0JBQ3BCLFFBQVEsQ0FBQyxRQUFRLEdBQUcsZUFBZSxDQUFDO2dCQUNwQyxNQUFNLENBQUMsUUFBUSxDQUFDO1lBQ2xCLENBQUM7WUFDRCxhQUFLLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBRXBCLHFDQUFxQztZQUVyQyxvRkFBb0Y7WUFDcEYsSUFBSSxtQkFBbUIsR0FBRyxLQUFLLENBQUM7WUFFaEMsSUFBSSxXQUFXLEdBQUcsS0FBSyxDQUFDO1lBRXhCLElBQUksZUFBZSxHQUFHLElBQUksZ0NBQWEsRUFBRSxDQUFDO1lBRTFDLFdBQVcsR0FBRyxlQUFlLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLHVCQUF1QjtZQUMvRSxtQkFBbUIsR0FBRyxXQUFXLENBQUM7WUFFbEMsRUFBRSxDQUFDLENBQUMsbUJBQW1CLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQztnQkFDakMsb0JBQVksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFFekMsUUFBUSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7Z0JBQ3BCLFFBQVEsQ0FBQyxRQUFRLEdBQUcsMkJBQTJCLENBQUM7Z0JBQ2hELE1BQU0sQ0FBQyxRQUFRLENBQUM7WUFDbEIsQ0FBQztZQUNELElBQUksQ0FBQyxDQUFDO2dCQUNKLGtCQUFrQjtnQkFDbEIsUUFBUSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7Z0JBQ3BCLFFBQVEsQ0FBQyxRQUFRLEdBQUcsZUFBZSxDQUFDO1lBQ3RDLENBQUM7WUFDRCxNQUFNLENBQUMsUUFBUSxDQUFDO1FBQ2xCLENBQUM7UUFFRCxzQkFBc0I7WUFDcEIsTUFBTSxDQUFDLG9CQUFZLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ3ZDLENBQUM7S0FHRixDQUFDLENBQUMsQ0FBQyx3QkFBd0I7QUFFOUIsQ0FBQyxDQUFDLHlCQUF5Qjs7Ozs7Ozs7Ozs7O0FDL08zQiw4RUFBOEU7QUFDOUUseUJBQXVCLGVBQWUsQ0FBQztBQUl2Qyx3QkFBc0IsY0FBYyxDQUFDO0FBQ3JDLG1DQUE4QixzQ0FBc0MsQ0FBQztBQUNyRSx3QkFBNEQsb0JBQW9CLENBQUM7QUFHakYsRUFBRSxDQUFDLENBQUMsZUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7SUFFcEIsZUFBTSxDQUFDLE9BQU8sQ0FBQztRQUdiLG1CQUFtQixDQUFDLFVBQVUsRUFBRSxRQUFRLEVBQUUsU0FBUyxFQUFFLFdBQVc7WUFDOUQsaUVBQWlFO1lBQ2pFLHdEQUF3RDtZQUN4RCxVQUFVO1lBQ1Ysc0JBQXNCO1lBQ3RCLDZEQUE2RDtZQUM3RCxxQ0FBcUM7WUFDckMsa0VBQWtFO1lBQ2xFLElBQUksUUFBUSxHQUFRO2dCQUNsQixRQUFRLEVBQUUsMkRBQTJEO2dCQUNyRSxJQUFJLEVBQUUsR0FBRzthQUNWO1lBRUQsSUFBSSxjQUFjLEdBQUcsZ0JBQVEsQ0FBQyxPQUFPLENBQUMsRUFBRSxNQUFNLEVBQUUsVUFBVSxFQUFFLFVBQVUsRUFBRSxRQUFRLEVBQUUsV0FBVyxFQUFFLFNBQVMsRUFBRSxhQUFhLEVBQUUsV0FBVyxFQUFFLENBQUMsQ0FBQztZQUd4SSxFQUFFLENBQUMsQ0FBQyxjQUFjLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQztnQkFDakMsUUFBUSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7Z0JBQ3BCLFFBQVEsQ0FBQyxRQUFRLEdBQUcsaURBQWlELENBQUM7Z0JBQ3RFLE1BQU0sQ0FBQyxRQUFRLENBQUM7WUFDbEIsQ0FBQztZQUNELElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxjQUFjLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQztnQkFDdEMsUUFBUSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7Z0JBQ3BCLFFBQVEsQ0FBQyxRQUFRLEdBQUcsNkNBQTZDLENBQUM7Z0JBQ2xFLE1BQU0sQ0FBQyxRQUFRLENBQUM7WUFDbEIsQ0FBQztZQUNELElBQUksQ0FBQyxDQUFDO2dCQUNKLE1BQU0sQ0FBQyxRQUFRLENBQUM7WUFDbEIsQ0FBQztRQUNILENBQUM7UUFFRCxjQUFjLENBQUMsSUFBSTtZQUNqQixpRUFBaUU7WUFDakUsd0RBQXdEO1lBQ3hELFVBQVU7WUFDVix1QkFBdUI7WUFDdkIsNkRBQTZEO1lBQzdELGlCQUFpQjtZQUNqQixrRUFBa0U7WUFFbEUsSUFBSSxRQUFRLEdBQVE7Z0JBQ2xCLFFBQVEsRUFBRSxtREFBbUQ7Z0JBQzdELElBQUksRUFBRSxHQUFHO2FBQ1Y7WUFFRCwwREFBMEQ7WUFDMUQsaUJBQWlCO1lBQ2pCLHNDQUFzQztZQUN0QywwREFBMEQ7WUFDMUQsMkRBQTJEO1lBQzNELDhDQUE4QztZQUM5QyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO2dCQUNqQixRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyxlQUFlLENBQUM7Z0JBQ3BDLE1BQU0sQ0FBQyxRQUFRLENBQUM7WUFDbEIsQ0FBQztZQUNELGFBQUssQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFFcEIscUNBQXFDO1lBRXJDLG9GQUFvRjtZQUNwRixJQUFJLG1CQUFtQixHQUFHLEtBQUssQ0FBQztZQUVoQyxJQUFJLFdBQVcsR0FBRyxLQUFLLENBQUM7WUFFeEIsSUFBSSxlQUFlLEdBQUcsSUFBSSxnQ0FBYSxFQUFFLENBQUM7WUFFMUMsV0FBVyxHQUFHLGVBQWUsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsdUJBQXVCO1lBQy9FLG1CQUFtQixHQUFHLFdBQVcsQ0FBQztZQUVsQyxFQUFFLENBQUMsQ0FBQyxtQkFBbUIsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUVqQyxxQ0FBcUM7Z0JBQ3JDLGdCQUFRLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQztvQkFFekIsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJO29CQUNmLFdBQVcsRUFBRSxJQUFJLENBQUMsV0FBVztvQkFDN0IsUUFBUSxFQUFFLElBQUksQ0FBQyxRQUFRO29CQUN2QixTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7b0JBQ3pCLFdBQVcsRUFBRSxJQUFJLENBQUMsV0FBVztvQkFDN0IsU0FBUyxFQUFFLGVBQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTztvQkFDMUMsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFO2lCQUV0QixDQUFDLENBQUMsQ0FBQyxZQUFZO2dCQUNoQixRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyxrQ0FBa0MsQ0FBQztnQkFDdkQsTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNsQixDQUFDLENBQUMsMENBQTBDO1lBQzVDLElBQUksQ0FBQyxDQUFDO2dCQUNKLGtCQUFrQjtnQkFDbEIsUUFBUSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7Z0JBQ3BCLFFBQVEsQ0FBQyxRQUFRLEdBQUcsZUFBZSxDQUFDO1lBQ3RDLENBQUM7WUFDRCxNQUFNLENBQUMsUUFBUSxDQUFDO1FBSWxCLENBQUM7UUFFRCxjQUFjLENBQUMsSUFBSTtZQUNqQixpRUFBaUU7WUFDakUsd0RBQXdEO1lBQ3hELFVBQVU7WUFDVix1QkFBdUI7WUFDdkIsNkRBQTZEO1lBQzdELGlCQUFpQjtZQUNqQixrRUFBa0U7WUFFbEUsSUFBSSxRQUFRLEdBQVE7Z0JBQ2xCLFFBQVEsRUFBRSxtREFBbUQ7Z0JBQzdELElBQUksRUFBRSxHQUFHO2FBQ1Y7WUFFRCwwREFBMEQ7WUFDMUQsaUJBQWlCO1lBQ2pCLHNDQUFzQztZQUN0QywwREFBMEQ7WUFDMUQsMkRBQTJEO1lBQzNELDhDQUE4QztZQUM5QyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO2dCQUNqQixRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyxlQUFlLENBQUM7Z0JBQ3BDLE1BQU0sQ0FBQyxRQUFRLENBQUM7WUFDbEIsQ0FBQztZQUNELGFBQUssQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFFcEIscUNBQXFDO1lBRXJDLG9GQUFvRjtZQUNwRixJQUFJLG1CQUFtQixHQUFHLEtBQUssQ0FBQztZQUVoQyxJQUFJLFdBQVcsR0FBRyxLQUFLLENBQUM7WUFFeEIsSUFBSSxlQUFlLEdBQUcsSUFBSSxnQ0FBYSxFQUFFLENBQUM7WUFFMUMsV0FBVyxHQUFHLGVBQWUsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsdUJBQXVCO1lBQy9FLG1CQUFtQixHQUFHLFdBQVcsQ0FBQztZQUVsQyxFQUFFLENBQUMsQ0FBQyxtQkFBbUIsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUVqQyxxQ0FBcUM7Z0JBQ3JDLGdCQUFRLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FDeEIsSUFBSSxDQUFDLEdBQUcsRUFDUjtvQkFDRSxJQUFJLEVBQ0Y7d0JBQ0UsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJO3dCQUNmLFdBQVcsRUFBRSxJQUFJLENBQUMsV0FBVzt3QkFDN0IsUUFBUSxFQUFFLElBQUksQ0FBQyxRQUFRO3dCQUN2QixTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7d0JBQ3pCLFdBQVcsRUFBRSxJQUFJLENBQUMsV0FBVzt3QkFDN0IsU0FBUyxFQUFFLGVBQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTzt3QkFDMUMsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFO3FCQUN0QjtpQkFDSixDQUFDLENBQUMsQ0FBQyxhQUFhO2dCQUduQixRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyw0QkFBNEIsQ0FBQztnQkFDakQsTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNsQixDQUFDLENBQUMsMENBQTBDO1lBQzVDLElBQUksQ0FBQyxDQUFDO2dCQUNKLGtCQUFrQjtnQkFDbEIsUUFBUSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7Z0JBQ3BCLFFBQVEsQ0FBQyxRQUFRLEdBQUcsZUFBZSxDQUFDO1lBQ3RDLENBQUM7WUFDRCxNQUFNLENBQUMsUUFBUSxDQUFDO1FBQ2xCLENBQUM7UUFFRCxjQUFjLENBQUMsSUFBSTtZQUNqQixpRUFBaUU7WUFDakUsd0RBQXdEO1lBQ3hELFVBQVU7WUFDVix1QkFBdUI7WUFDdkIsNkRBQTZEO1lBQzdELGlCQUFpQjtZQUNqQixrRUFBa0U7WUFFbEUsSUFBSSxRQUFRLEdBQVE7Z0JBQ2xCLFFBQVEsRUFBRSxtREFBbUQ7Z0JBQzdELElBQUksRUFBRSxHQUFHO2FBQ1Y7WUFFRCwwREFBMEQ7WUFDMUQsaUJBQWlCO1lBQ2pCLHNDQUFzQztZQUN0QywwREFBMEQ7WUFDMUQsMkRBQTJEO1lBQzNELDhDQUE4QztZQUM5QyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO2dCQUNqQixRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyxlQUFlLENBQUM7Z0JBQ3BDLE1BQU0sQ0FBQyxRQUFRLENBQUM7WUFDbEIsQ0FBQztZQUNELGFBQUssQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFFcEIscUNBQXFDO1lBRXJDLG9GQUFvRjtZQUNwRixJQUFJLG1CQUFtQixHQUFHLEtBQUssQ0FBQztZQUVoQyxJQUFJLFdBQVcsR0FBRyxLQUFLLENBQUM7WUFFeEIsSUFBSSxlQUFlLEdBQUcsSUFBSSxnQ0FBYSxFQUFFLENBQUM7WUFFMUMsV0FBVyxHQUFHLGVBQWUsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsdUJBQXVCO1lBQy9FLG1CQUFtQixHQUFHLFdBQVcsQ0FBQztZQUVsQyxFQUFFLENBQUMsQ0FBQyxtQkFBbUIsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUNqQyxnQkFBUSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUVyQyxRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyw0QkFBNEIsQ0FBQztnQkFDakQsTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNsQixDQUFDO1lBQ0QsSUFBSSxDQUFDLENBQUM7Z0JBQ0osa0JBQWtCO2dCQUNsQixRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyxlQUFlLENBQUM7WUFDdEMsQ0FBQztZQUNELE1BQU0sQ0FBQyxRQUFRLENBQUM7UUFDbEIsQ0FBQztLQUVGLENBQUMsQ0FBQyxDQUFDLHdCQUF3QjtBQUU5QixDQUFDLENBQUMseUJBQXlCOzs7Ozs7Ozs7Ozs7QUNoUDNCLDhFQUE4RTtBQUM5RSx5QkFBdUIsZUFBZSxDQUFDO0FBSXZDLHdCQUFzQixjQUFjLENBQUM7QUFDckMsbUNBQThCLHNDQUFzQyxDQUFDO0FBQ3JFLHdCQUFrRCxvQkFBb0IsQ0FBQztBQUd2RSxFQUFFLENBQUMsQ0FBQyxlQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztJQUVwQixlQUFNLENBQUMsT0FBTyxDQUFDO1FBR2Isb0JBQW9CLENBQUMsV0FBVyxFQUFFLFFBQVE7WUFDeEMsaUVBQWlFO1lBQ2pFLHdEQUF3RDtZQUN4RCxVQUFVO1lBQ1Ysc0JBQXNCO1lBQ3RCLDZEQUE2RDtZQUM3RCxxQ0FBcUM7WUFDckMsa0VBQWtFO1lBQ2xFLElBQUksUUFBUSxHQUFRO2dCQUNsQixRQUFRLEVBQUUsMkRBQTJEO2dCQUNyRSxJQUFJLEVBQUUsR0FBRzthQUNWO1lBRUQsSUFBSSxlQUFlLEdBQUcsaUJBQVMsQ0FBQyxPQUFPLENBQUMsRUFBRSxNQUFNLEVBQUUsV0FBVyxFQUFFLFVBQVUsRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFDO1lBR3ZGLEVBQUUsQ0FBQyxDQUFDLGVBQWUsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDO2dCQUNsQyxRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyxrREFBa0QsQ0FBQztnQkFDdkUsTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNsQixDQUFDO1lBQ0QsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLGVBQWUsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDO2dCQUN2QyxRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyw4Q0FBOEMsQ0FBQztnQkFDbkUsTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNsQixDQUFDO1lBQ0QsSUFBSSxDQUFDLENBQUM7Z0JBQ0osTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNsQixDQUFDO1FBQ0gsQ0FBQztRQUVELGVBQWUsQ0FBQyxJQUFJO1lBQ2xCLGlFQUFpRTtZQUNqRSx3REFBd0Q7WUFDeEQsVUFBVTtZQUNWLHVCQUF1QjtZQUN2Qiw2REFBNkQ7WUFDN0QsaUJBQWlCO1lBQ2pCLGtFQUFrRTtZQUVsRSxJQUFJLFFBQVEsR0FBUTtnQkFDbEIsUUFBUSxFQUFFLG1EQUFtRDtnQkFDN0QsSUFBSSxFQUFFLEdBQUc7YUFDVjtZQUVELDBEQUEwRDtZQUMxRCxpQkFBaUI7WUFDakIsc0NBQXNDO1lBQ3RDLDBEQUEwRDtZQUMxRCwyREFBMkQ7WUFDM0QsOENBQThDO1lBQzlDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7Z0JBQ2pCLFFBQVEsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDO2dCQUNwQixRQUFRLENBQUMsUUFBUSxHQUFHLGVBQWUsQ0FBQztnQkFDcEMsTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNsQixDQUFDO1lBQ0QsYUFBSyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQztZQUVwQixxQ0FBcUM7WUFFckMsb0ZBQW9GO1lBQ3BGLElBQUksbUJBQW1CLEdBQUcsS0FBSyxDQUFDO1lBRWhDLElBQUksV0FBVyxHQUFHLEtBQUssQ0FBQztZQUV4QixJQUFJLGVBQWUsR0FBRyxJQUFJLGdDQUFhLEVBQUUsQ0FBQztZQUUxQyxXQUFXLEdBQUcsZUFBZSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyx1QkFBdUI7WUFDL0UsbUJBQW1CLEdBQUcsV0FBVyxDQUFDO1lBRWxDLEVBQUUsQ0FBQyxDQUFDLG1CQUFtQixLQUFLLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBRWpDLHFDQUFxQztnQkFDckMsaUJBQVMsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDO29CQUUxQixJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUk7b0JBQ2YsV0FBVyxFQUFFLElBQUksQ0FBQyxXQUFXO29CQUM3QixRQUFRLEVBQUUsSUFBSSxDQUFDLFFBQVE7b0JBQ3ZCLFNBQVMsRUFBRSxlQUFNLENBQUMsSUFBSSxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU87b0JBQzFDLFNBQVMsRUFBRSxJQUFJLElBQUksRUFBRTtpQkFFdEIsQ0FBQyxDQUFDLENBQUMsWUFBWTtnQkFDaEIsUUFBUSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7Z0JBQ3BCLFFBQVEsQ0FBQyxRQUFRLEdBQUcsa0NBQWtDLENBQUM7Z0JBQ3ZELE1BQU0sQ0FBQyxRQUFRLENBQUM7WUFDbEIsQ0FBQyxDQUFDLDBDQUEwQztZQUM1QyxJQUFJLENBQUMsQ0FBQztnQkFDSixrQkFBa0I7Z0JBQ2xCLFFBQVEsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDO2dCQUNwQixRQUFRLENBQUMsUUFBUSxHQUFHLGVBQWUsQ0FBQztZQUN0QyxDQUFDO1lBQ0QsTUFBTSxDQUFDLFFBQVEsQ0FBQztRQUlsQixDQUFDO1FBRUQsZUFBZSxDQUFDLElBQUk7WUFDbEIsaUVBQWlFO1lBQ2pFLHdEQUF3RDtZQUN4RCxVQUFVO1lBQ1YsdUJBQXVCO1lBQ3ZCLDZEQUE2RDtZQUM3RCxpQkFBaUI7WUFDakIsa0VBQWtFO1lBRWxFLElBQUksUUFBUSxHQUFRO2dCQUNsQixRQUFRLEVBQUUsbURBQW1EO2dCQUM3RCxJQUFJLEVBQUUsR0FBRzthQUNWO1lBRUQsMERBQTBEO1lBQzFELGlCQUFpQjtZQUNqQixzQ0FBc0M7WUFDdEMsMERBQTBEO1lBQzFELDJEQUEyRDtZQUMzRCw4Q0FBOEM7WUFDOUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztnQkFDakIsUUFBUSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7Z0JBQ3BCLFFBQVEsQ0FBQyxRQUFRLEdBQUcsZUFBZSxDQUFDO2dCQUNwQyxNQUFNLENBQUMsUUFBUSxDQUFDO1lBQ2xCLENBQUM7WUFDRCxhQUFLLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBRXBCLHFDQUFxQztZQUVyQyxvRkFBb0Y7WUFDcEYsSUFBSSxtQkFBbUIsR0FBRyxLQUFLLENBQUM7WUFFaEMsSUFBSSxXQUFXLEdBQUcsS0FBSyxDQUFDO1lBRXhCLElBQUksZUFBZSxHQUFHLElBQUksZ0NBQWEsRUFBRSxDQUFDO1lBRTFDLFdBQVcsR0FBRyxlQUFlLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLHVCQUF1QjtZQUMvRSxtQkFBbUIsR0FBRyxXQUFXLENBQUM7WUFFbEMsRUFBRSxDQUFDLENBQUMsbUJBQW1CLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQztnQkFFakMscUNBQXFDO2dCQUNyQyxpQkFBUyxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQ3pCLElBQUksQ0FBQyxHQUFHLEVBQ1I7b0JBQ0UsSUFBSSxFQUNGO3dCQUNFLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSTt3QkFDZixXQUFXLEVBQUUsSUFBSSxDQUFDLFdBQVc7d0JBQzdCLFFBQVEsRUFBRSxJQUFJLENBQUMsUUFBUTt3QkFDdkIsU0FBUyxFQUFFLGVBQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTzt3QkFDMUMsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFO3FCQUN0QjtpQkFDSixDQUFDLENBQUMsQ0FBQyxhQUFhO2dCQUduQixRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyw0QkFBNEIsQ0FBQztnQkFDakQsTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNsQixDQUFDLENBQUMsMENBQTBDO1lBQzVDLElBQUksQ0FBQyxDQUFDO2dCQUNKLGtCQUFrQjtnQkFDbEIsUUFBUSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7Z0JBQ3BCLFFBQVEsQ0FBQyxRQUFRLEdBQUcsZUFBZSxDQUFDO1lBQ3RDLENBQUM7WUFDRCxNQUFNLENBQUMsUUFBUSxDQUFDO1FBQ2xCLENBQUM7UUFFRCx1QkFBdUIsQ0FBQyxTQUFTO1lBQy9CLGlFQUFpRTtZQUNqRSx3REFBd0Q7WUFDeEQsVUFBVTtZQUNWLCtCQUErQjtZQUMvQiw2REFBNkQ7WUFDN0QsaUNBQWlDO1lBQ2pDLGtFQUFrRTtZQUVsRSxJQUFJLFFBQVEsR0FBUTtnQkFDbEIsUUFBUSxFQUFFLDJEQUEyRDtnQkFDckUsSUFBSSxFQUFFLEdBQUc7YUFDVjtZQUVELElBQUksYUFBYSxHQUFHLG1CQUFXLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxFQUFFLFdBQVcsRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDO1lBRXBGLEVBQUUsQ0FBQyxDQUFDLGFBQWEsS0FBSyxTQUFTLElBQUksYUFBYSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3JELFFBQVEsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDO2dCQUNwQixRQUFRLENBQUMsUUFBUSxHQUFHLHNFQUFzRSxDQUFDO2dCQUMzRixNQUFNLENBQUMsUUFBUSxDQUFDO1lBQ2xCLENBQUM7WUFDRCxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsYUFBYSxLQUFLLFNBQVMsSUFBSSxhQUFhLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDNUQsUUFBUSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7Z0JBQ3BCLFFBQVEsQ0FBQyxRQUFRLEdBQUcseUNBQXlDLENBQUM7Z0JBQzlELE1BQU0sQ0FBQyxRQUFRLENBQUM7WUFDbEIsQ0FBQztZQUNELElBQUksQ0FBQyxDQUFDO2dCQUNKLE1BQU0sQ0FBQyxRQUFRLENBQUM7WUFDbEIsQ0FBQztRQUNILENBQUM7UUFFRCxlQUFlLENBQUMsSUFBSTtZQUNsQixpRUFBaUU7WUFDakUsd0RBQXdEO1lBQ3hELFVBQVU7WUFDVix1QkFBdUI7WUFDdkIsNkRBQTZEO1lBQzdELGlCQUFpQjtZQUNqQixrRUFBa0U7WUFFbEUsSUFBSSxRQUFRLEdBQVE7Z0JBQ2xCLFFBQVEsRUFBRSxtREFBbUQ7Z0JBQzdELElBQUksRUFBRSxHQUFHO2FBQ1Y7WUFFRCwwREFBMEQ7WUFDMUQsaUJBQWlCO1lBQ2pCLHNDQUFzQztZQUN0QywwREFBMEQ7WUFDMUQsMkRBQTJEO1lBQzNELDhDQUE4QztZQUM5QyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO2dCQUNqQixRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyxlQUFlLENBQUM7Z0JBQ3BDLE1BQU0sQ0FBQyxRQUFRLENBQUM7WUFDbEIsQ0FBQztZQUNELGFBQUssQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFFcEIscUNBQXFDO1lBRXJDLG9GQUFvRjtZQUNwRixJQUFJLG1CQUFtQixHQUFHLEtBQUssQ0FBQztZQUVoQyxJQUFJLFdBQVcsR0FBRyxLQUFLLENBQUM7WUFFeEIsSUFBSSxlQUFlLEdBQUcsSUFBSSxnQ0FBYSxFQUFFLENBQUM7WUFFMUMsV0FBVyxHQUFHLGVBQWUsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsdUJBQXVCO1lBQy9FLG1CQUFtQixHQUFHLFdBQVcsQ0FBQztZQUVsQyxFQUFFLENBQUMsQ0FBQyxtQkFBbUIsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUNqQyxpQkFBUyxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUV0QyxRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyw0QkFBNEIsQ0FBQztnQkFDakQsTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNsQixDQUFDO1lBQ0QsSUFBSSxDQUFDLENBQUM7Z0JBQ0osa0JBQWtCO2dCQUNsQixRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyxlQUFlLENBQUM7WUFDdEMsQ0FBQztZQUNELE1BQU0sQ0FBQyxRQUFRLENBQUM7UUFDbEIsQ0FBQztLQUVGLENBQUMsQ0FBQyxDQUFDLHdCQUF3QjtBQUU5QixDQUFDLENBQUMseUJBQXlCOzs7Ozs7Ozs7Ozs7QUMzUTNCLDhFQUE4RTtBQUM5RSx5QkFBdUIsZUFBZSxDQUFDO0FBSXZDLHdCQUFzQixjQUFjLENBQUM7QUFDckMsbUNBQThCLHNDQUFzQyxDQUFDO0FBQ3JFLHdCQUE0RCxvQkFBb0IsQ0FBQztBQUdqRixFQUFFLENBQUMsQ0FBQyxlQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztJQUVwQixlQUFNLENBQUMsT0FBTyxDQUFDO1FBR2Isc0JBQXNCLENBQUMsYUFBYSxFQUFFLFFBQVEsRUFBRSxTQUFTO1lBQ3ZELGlFQUFpRTtZQUNqRSx3REFBd0Q7WUFDeEQsVUFBVTtZQUNWLHNCQUFzQjtZQUN0Qiw2REFBNkQ7WUFDN0QscUNBQXFDO1lBQ3JDLGtFQUFrRTtZQUNsRSxJQUFJLFFBQVEsR0FBUTtnQkFDbEIsUUFBUSxFQUFFLDJEQUEyRDtnQkFDckUsSUFBSSxFQUFFLEdBQUc7YUFDVjtZQUVELElBQUksaUJBQWlCLEdBQUcsbUJBQVcsQ0FBQyxPQUFPLENBQUMsRUFBRSxNQUFNLEVBQUUsYUFBYSxFQUFFLFVBQVUsRUFBRSxRQUFRLEVBQUUsV0FBVyxFQUFFLFNBQVMsRUFBRSxDQUFDLENBQUM7WUFHckgsRUFBRSxDQUFDLENBQUMsaUJBQWlCLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQztnQkFDcEMsUUFBUSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7Z0JBQ3BCLFFBQVEsQ0FBQyxRQUFRLEdBQUcsb0RBQW9ELENBQUM7Z0JBQ3pFLE1BQU0sQ0FBQyxRQUFRLENBQUM7WUFDbEIsQ0FBQztZQUNELElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxpQkFBaUIsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDO2dCQUN6QyxRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyxnREFBZ0QsQ0FBQztnQkFDckUsTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNsQixDQUFDO1lBQ0QsSUFBSSxDQUFDLENBQUM7Z0JBQ0osTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNsQixDQUFDO1FBQ0gsQ0FBQztRQUVELGlCQUFpQixDQUFDLElBQUk7WUFDcEIsaUVBQWlFO1lBQ2pFLHdEQUF3RDtZQUN4RCxVQUFVO1lBQ1YsdUJBQXVCO1lBQ3ZCLDZEQUE2RDtZQUM3RCxpQkFBaUI7WUFDakIsa0VBQWtFO1lBRWxFLElBQUksUUFBUSxHQUFRO2dCQUNsQixRQUFRLEVBQUUsbURBQW1EO2dCQUM3RCxJQUFJLEVBQUUsR0FBRzthQUNWO1lBRUQsMERBQTBEO1lBQzFELGlCQUFpQjtZQUNqQixzQ0FBc0M7WUFDdEMsMERBQTBEO1lBQzFELDJEQUEyRDtZQUMzRCw4Q0FBOEM7WUFDOUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztnQkFDakIsUUFBUSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7Z0JBQ3BCLFFBQVEsQ0FBQyxRQUFRLEdBQUcsZUFBZSxDQUFDO2dCQUNwQyxNQUFNLENBQUMsUUFBUSxDQUFDO1lBQ2xCLENBQUM7WUFDRCxhQUFLLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBRXBCLHFDQUFxQztZQUVyQyxvRkFBb0Y7WUFDcEYsSUFBSSxtQkFBbUIsR0FBRyxLQUFLLENBQUM7WUFFaEMsSUFBSSxXQUFXLEdBQUcsS0FBSyxDQUFDO1lBRXhCLElBQUksZUFBZSxHQUFHLElBQUksZ0NBQWEsRUFBRSxDQUFDO1lBRTFDLFdBQVcsR0FBRyxlQUFlLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLHVCQUF1QjtZQUMvRSxtQkFBbUIsR0FBRyxXQUFXLENBQUM7WUFFbEMsRUFBRSxDQUFDLENBQUMsbUJBQW1CLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQztnQkFFakMscUNBQXFDO2dCQUNyQyxtQkFBVyxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUM7b0JBRTVCLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSTtvQkFDZixXQUFXLEVBQUUsSUFBSSxDQUFDLFdBQVc7b0JBQzdCLFFBQVEsRUFBRSxJQUFJLENBQUMsUUFBUTtvQkFDdkIsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO29CQUN6QixTQUFTLEVBQUUsZUFBTSxDQUFDLElBQUksRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPO29CQUMxQyxTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUU7aUJBRXRCLENBQUMsQ0FBQyxDQUFDLFlBQVk7Z0JBQ2hCLFFBQVEsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDO2dCQUNwQixRQUFRLENBQUMsUUFBUSxHQUFHLHFDQUFxQyxDQUFDO2dCQUMxRCxNQUFNLENBQUMsUUFBUSxDQUFDO1lBQ2xCLENBQUMsQ0FBQywwQ0FBMEM7WUFDNUMsSUFBSSxDQUFDLENBQUM7Z0JBQ0osa0JBQWtCO2dCQUNsQixRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyxlQUFlLENBQUM7WUFDdEMsQ0FBQztZQUNELE1BQU0sQ0FBQyxRQUFRLENBQUM7UUFJbEIsQ0FBQztRQUVELGlCQUFpQixDQUFDLElBQUk7WUFDcEIsaUVBQWlFO1lBQ2pFLHdEQUF3RDtZQUN4RCxVQUFVO1lBQ1YsdUJBQXVCO1lBQ3ZCLDZEQUE2RDtZQUM3RCxpQkFBaUI7WUFDakIsa0VBQWtFO1lBRWxFLElBQUksUUFBUSxHQUFRO2dCQUNsQixRQUFRLEVBQUUsbURBQW1EO2dCQUM3RCxJQUFJLEVBQUUsR0FBRzthQUNWO1lBRUQsMERBQTBEO1lBQzFELGlCQUFpQjtZQUNqQixzQ0FBc0M7WUFDdEMsMERBQTBEO1lBQzFELDJEQUEyRDtZQUMzRCw4Q0FBOEM7WUFDOUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztnQkFDakIsUUFBUSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7Z0JBQ3BCLFFBQVEsQ0FBQyxRQUFRLEdBQUcsZUFBZSxDQUFDO2dCQUNwQyxNQUFNLENBQUMsUUFBUSxDQUFDO1lBQ2xCLENBQUM7WUFDRCxhQUFLLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBRXBCLHFDQUFxQztZQUVyQyxvRkFBb0Y7WUFDcEYsSUFBSSxtQkFBbUIsR0FBRyxLQUFLLENBQUM7WUFFaEMsSUFBSSxXQUFXLEdBQUcsS0FBSyxDQUFDO1lBRXhCLElBQUksZUFBZSxHQUFHLElBQUksZ0NBQWEsRUFBRSxDQUFDO1lBRTFDLFdBQVcsR0FBRyxlQUFlLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLHVCQUF1QjtZQUMvRSxtQkFBbUIsR0FBRyxXQUFXLENBQUM7WUFFbEMsRUFBRSxDQUFDLENBQUMsbUJBQW1CLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQztnQkFFakMscUNBQXFDO2dCQUNyQyxtQkFBVyxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQzNCLElBQUksQ0FBQyxHQUFHLEVBQ1I7b0JBQ0UsSUFBSSxFQUNGO3dCQUNFLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSTt3QkFDZixXQUFXLEVBQUUsSUFBSSxDQUFDLFdBQVc7d0JBQzdCLFFBQVEsRUFBRSxJQUFJLENBQUMsUUFBUTt3QkFDdkIsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO3dCQUN6QixTQUFTLEVBQUUsZUFBTSxDQUFDLElBQUksRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPO3dCQUMxQyxTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUU7cUJBQ3RCO2lCQUNKLENBQUMsQ0FBQyxDQUFDLGFBQWE7Z0JBR25CLFFBQVEsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDO2dCQUNwQixRQUFRLENBQUMsUUFBUSxHQUFHLCtCQUErQixDQUFDO2dCQUNwRCxNQUFNLENBQUMsUUFBUSxDQUFDO1lBQ2xCLENBQUMsQ0FBQywwQ0FBMEM7WUFDNUMsSUFBSSxDQUFDLENBQUM7Z0JBQ0osa0JBQWtCO2dCQUNsQixRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyxlQUFlLENBQUM7WUFDdEMsQ0FBQztZQUNELE1BQU0sQ0FBQyxRQUFRLENBQUM7UUFDbEIsQ0FBQztRQUVELHNCQUFzQixDQUFDLFdBQVc7WUFDaEMsaUVBQWlFO1lBQ2pFLHdEQUF3RDtZQUN4RCxVQUFVO1lBQ1YsOEJBQThCO1lBQzlCLDZEQUE2RDtZQUM3RCxnQ0FBZ0M7WUFDaEMsa0VBQWtFO1lBRWxFLElBQUksUUFBUSxHQUFRO2dCQUNsQixRQUFRLEVBQUUsMkRBQTJEO2dCQUNyRSxJQUFJLEVBQUUsR0FBRzthQUNWO1lBRUQsSUFBSSxXQUFXLEdBQUcsZ0JBQVEsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLEVBQUUsYUFBYSxFQUFFLFdBQVcsRUFBRSxDQUFDLENBQUMsS0FBSyxFQUFFLENBQUM7WUFFbkYsRUFBRSxDQUFDLENBQUMsV0FBVyxLQUFLLFNBQVMsSUFBSSxXQUFXLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDakQsUUFBUSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7Z0JBQ3BCLFFBQVEsQ0FBQyxRQUFRLEdBQUcsb0VBQW9FLENBQUM7Z0JBQ3pGLE1BQU0sQ0FBQyxRQUFRLENBQUM7WUFDbEIsQ0FBQztZQUNELElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxXQUFXLEtBQUssU0FBUyxJQUFJLFdBQVcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUN4RCxRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyx3Q0FBd0MsQ0FBQztnQkFDN0QsTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNsQixDQUFDO1lBQ0QsSUFBSSxDQUFDLENBQUM7Z0JBQ0osTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNsQixDQUFDO1FBQ0gsQ0FBQztRQUdELGlCQUFpQixDQUFDLElBQUk7WUFDcEIsaUVBQWlFO1lBQ2pFLHdEQUF3RDtZQUN4RCxVQUFVO1lBQ1YsdUJBQXVCO1lBQ3ZCLDZEQUE2RDtZQUM3RCxpQkFBaUI7WUFDakIsa0VBQWtFO1lBRWxFLElBQUksUUFBUSxHQUFRO2dCQUNsQixRQUFRLEVBQUUsbURBQW1EO2dCQUM3RCxJQUFJLEVBQUUsR0FBRzthQUNWO1lBRUQsMERBQTBEO1lBQzFELGlCQUFpQjtZQUNqQixzQ0FBc0M7WUFDdEMsMERBQTBEO1lBQzFELDJEQUEyRDtZQUMzRCw4Q0FBOEM7WUFDOUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztnQkFDakIsUUFBUSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7Z0JBQ3BCLFFBQVEsQ0FBQyxRQUFRLEdBQUcsZUFBZSxDQUFDO2dCQUNwQyxNQUFNLENBQUMsUUFBUSxDQUFDO1lBQ2xCLENBQUM7WUFDRCxhQUFLLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBRXBCLHFDQUFxQztZQUVyQyxvRkFBb0Y7WUFDcEYsSUFBSSxtQkFBbUIsR0FBRyxLQUFLLENBQUM7WUFFaEMsSUFBSSxXQUFXLEdBQUcsS0FBSyxDQUFDO1lBRXhCLElBQUksZUFBZSxHQUFHLElBQUksZ0NBQWEsRUFBRSxDQUFDO1lBRTFDLFdBQVcsR0FBRyxlQUFlLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLHVCQUF1QjtZQUMvRSxtQkFBbUIsR0FBRyxXQUFXLENBQUM7WUFFbEMsRUFBRSxDQUFDLENBQUMsbUJBQW1CLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQztnQkFDakMsbUJBQVcsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFFeEMsUUFBUSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7Z0JBQ3BCLFFBQVEsQ0FBQyxRQUFRLEdBQUcsK0JBQStCLENBQUM7Z0JBQ3BELE1BQU0sQ0FBQyxRQUFRLENBQUM7WUFDbEIsQ0FBQztZQUNELElBQUksQ0FBQyxDQUFDO2dCQUNKLGtCQUFrQjtnQkFDbEIsUUFBUSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7Z0JBQ3BCLFFBQVEsQ0FBQyxRQUFRLEdBQUcsZUFBZSxDQUFDO1lBQ3RDLENBQUM7WUFDRCxNQUFNLENBQUMsUUFBUSxDQUFDO1FBQ2xCLENBQUM7S0FFRixDQUFDLENBQUMsQ0FBQyx3QkFBd0I7QUFFOUIsQ0FBQyxDQUFDLHlCQUF5Qjs7Ozs7Ozs7Ozs7O0FDOVEzQiw4RUFBOEU7QUFDOUUseUJBQXVCLGVBQWUsQ0FBQztBQUl2Qyx3QkFBc0IsY0FBYyxDQUFDO0FBQ3JDLG1DQUE4QixzQ0FBc0MsQ0FBQztBQUNyRSx3QkFBOEMsb0JBQW9CLENBQUM7QUFHbkUsRUFBRSxDQUFDLENBQUMsZUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7SUFFcEIsZUFBTSxDQUFDLE9BQU8sQ0FBQztRQUdiLGtCQUFrQixDQUFDLFNBQVM7WUFDMUIsaUVBQWlFO1lBQ2pFLHdEQUF3RDtZQUN4RCxVQUFVO1lBQ1Ysc0JBQXNCO1lBQ3RCLDZEQUE2RDtZQUM3RCxtQ0FBbUM7WUFDbkMsa0VBQWtFO1lBQ2xFLElBQUksUUFBUSxHQUFRO2dCQUNsQixRQUFRLEVBQUUsMkRBQTJEO2dCQUNyRSxJQUFJLEVBQUUsR0FBRzthQUNWO1lBRUQsSUFBSSxhQUFhLEdBQUcsZUFBTyxDQUFDLE9BQU8sQ0FBQyxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFDO1lBRzNELEVBQUUsQ0FBQyxDQUFDLGFBQWEsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDO2dCQUNoQyxRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyxnREFBZ0QsQ0FBQztnQkFDckUsTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNsQixDQUFDO1lBQ0QsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLGFBQWEsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDO2dCQUNyQyxRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyw0Q0FBNEMsQ0FBQztnQkFDakUsTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNsQixDQUFDO1lBQ0QsSUFBSSxDQUFDLENBQUM7Z0JBQ0osTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNsQixDQUFDO1FBQ0gsQ0FBQztRQUVELGFBQWEsQ0FBQyxJQUFJO1lBQ2hCLGlFQUFpRTtZQUNqRSx3REFBd0Q7WUFDeEQsVUFBVTtZQUNWLHVCQUF1QjtZQUN2Qiw2REFBNkQ7WUFDN0QsaUJBQWlCO1lBQ2pCLGtFQUFrRTtZQUVsRSxJQUFJLFFBQVEsR0FBUTtnQkFDbEIsUUFBUSxFQUFFLG1EQUFtRDtnQkFDN0QsSUFBSSxFQUFFLEdBQUc7YUFDVjtZQUVELDBEQUEwRDtZQUMxRCxpQkFBaUI7WUFDakIsb0NBQW9DO1lBQ3BDLDBEQUEwRDtZQUMxRCwyREFBMkQ7WUFDM0QsOENBQThDO1lBQzlDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7Z0JBQ2pCLFFBQVEsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDO2dCQUNwQixRQUFRLENBQUMsUUFBUSxHQUFHLGVBQWUsQ0FBQztnQkFDcEMsTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNsQixDQUFDO1lBQ0QsYUFBSyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQztZQUVwQixxQ0FBcUM7WUFFckMsb0ZBQW9GO1lBQ3BGLElBQUksbUJBQW1CLEdBQUcsS0FBSyxDQUFDO1lBRWhDLElBQUksV0FBVyxHQUFHLEtBQUssQ0FBQztZQUV4QixJQUFJLGVBQWUsR0FBRyxJQUFJLGdDQUFhLEVBQUUsQ0FBQztZQUUxQyxXQUFXLEdBQUcsZUFBZSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyx1QkFBdUI7WUFDL0UsbUJBQW1CLEdBQUcsV0FBVyxDQUFDO1lBRWxDLEVBQUUsQ0FBQyxDQUFDLG1CQUFtQixLQUFLLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBRWpDLHFDQUFxQztnQkFDckMsZUFBTyxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUM7b0JBRXhCLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSTtvQkFDZixXQUFXLEVBQUUsSUFBSSxDQUFDLFdBQVc7b0JBQzdCLFNBQVMsRUFBRSxlQUFNLENBQUMsSUFBSSxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU87b0JBQzFDLFNBQVMsRUFBRSxJQUFJLElBQUksRUFBRTtpQkFFdEIsQ0FBQyxDQUFDLENBQUMsWUFBWTtnQkFDaEIsUUFBUSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7Z0JBQ3BCLFFBQVEsQ0FBQyxRQUFRLEdBQUcsaUNBQWlDLENBQUM7Z0JBQ3RELE1BQU0sQ0FBQyxRQUFRLENBQUM7WUFDbEIsQ0FBQyxDQUFDLDBDQUEwQztZQUM1QyxJQUFJLENBQUMsQ0FBQztnQkFDSixrQkFBa0I7Z0JBQ2xCLFFBQVEsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDO2dCQUNwQixRQUFRLENBQUMsUUFBUSxHQUFHLGVBQWUsQ0FBQztZQUN0QyxDQUFDO1lBQ0QsTUFBTSxDQUFDLFFBQVEsQ0FBQztRQUlsQixDQUFDO1FBRUQsYUFBYSxDQUFDLElBQUk7WUFDaEIsaUVBQWlFO1lBQ2pFLHdEQUF3RDtZQUN4RCxVQUFVO1lBQ1YsdUJBQXVCO1lBQ3ZCLDZEQUE2RDtZQUM3RCxpQkFBaUI7WUFDakIsa0VBQWtFO1lBRWxFLElBQUksUUFBUSxHQUFRO2dCQUNsQixRQUFRLEVBQUUsbURBQW1EO2dCQUM3RCxJQUFJLEVBQUUsR0FBRzthQUNWO1lBRUQsMERBQTBEO1lBQzFELGlCQUFpQjtZQUNqQixxQ0FBcUM7WUFDckMsMERBQTBEO1lBQzFELDJEQUEyRDtZQUMzRCw4Q0FBOEM7WUFDOUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztnQkFDakIsUUFBUSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7Z0JBQ3BCLFFBQVEsQ0FBQyxRQUFRLEdBQUcsZUFBZSxDQUFDO2dCQUNwQyxNQUFNLENBQUMsUUFBUSxDQUFDO1lBQ2xCLENBQUM7WUFDRCxhQUFLLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBRXBCLHFDQUFxQztZQUVyQyxvRkFBb0Y7WUFDcEYsSUFBSSxtQkFBbUIsR0FBRyxLQUFLLENBQUM7WUFFaEMsSUFBSSxXQUFXLEdBQUcsS0FBSyxDQUFDO1lBRXhCLElBQUksZUFBZSxHQUFHLElBQUksZ0NBQWEsRUFBRSxDQUFDO1lBRTFDLFdBQVcsR0FBRyxlQUFlLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLHVCQUF1QjtZQUMvRSxtQkFBbUIsR0FBRyxXQUFXLENBQUM7WUFFbEMsRUFBRSxDQUFDLENBQUMsbUJBQW1CLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQztnQkFFakMscUNBQXFDO2dCQUNyQyxlQUFPLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FDdkIsSUFBSSxDQUFDLEdBQUcsRUFDUjtvQkFDRSxJQUFJLEVBQ0Y7d0JBQ0UsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJO3dCQUNmLFdBQVcsRUFBRSxJQUFJLENBQUMsV0FBVzt3QkFDN0IsU0FBUyxFQUFFLGVBQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTzt3QkFDMUMsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFO3FCQUN0QjtpQkFDSixDQUFDLENBQUMsQ0FBQyxhQUFhO2dCQUduQixRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRywyQkFBMkIsQ0FBQztnQkFDaEQsTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNsQixDQUFDLENBQUMsMENBQTBDO1lBQzVDLElBQUksQ0FBQyxDQUFDO2dCQUNKLGtCQUFrQjtnQkFDbEIsUUFBUSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7Z0JBQ3BCLFFBQVEsQ0FBQyxRQUFRLEdBQUcsZUFBZSxDQUFDO1lBQ3RDLENBQUM7WUFDRCxNQUFNLENBQUMsUUFBUSxDQUFDO1FBQ2xCLENBQUM7UUFFRCxhQUFhLENBQUMsSUFBSTtZQUNoQixpRUFBaUU7WUFDakUsd0RBQXdEO1lBQ3hELFVBQVU7WUFDVix1QkFBdUI7WUFDdkIsNkRBQTZEO1lBQzdELGlCQUFpQjtZQUNqQixrRUFBa0U7WUFFbEUsSUFBSSxRQUFRLEdBQVE7Z0JBQ2xCLFFBQVEsRUFBRSxtREFBbUQ7Z0JBQzdELElBQUksRUFBRSxHQUFHO2FBQ1Y7WUFFRCwwREFBMEQ7WUFDMUQsaUJBQWlCO1lBQ2pCLHFDQUFxQztZQUNyQywwREFBMEQ7WUFDMUQsMkRBQTJEO1lBQzNELDhDQUE4QztZQUM5QyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO2dCQUNqQixRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyxlQUFlLENBQUM7Z0JBQ3BDLE1BQU0sQ0FBQyxRQUFRLENBQUM7WUFDbEIsQ0FBQztZQUNELGFBQUssQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFFcEIscUNBQXFDO1lBRXJDLG9GQUFvRjtZQUNwRixJQUFJLG1CQUFtQixHQUFHLEtBQUssQ0FBQztZQUVoQyxJQUFJLFdBQVcsR0FBRyxLQUFLLENBQUM7WUFFeEIsSUFBSSxlQUFlLEdBQUcsSUFBSSxnQ0FBYSxFQUFFLENBQUM7WUFFMUMsV0FBVyxHQUFHLGVBQWUsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsdUJBQXVCO1lBQy9FLG1CQUFtQixHQUFHLFdBQVcsQ0FBQztZQUVsQyxFQUFFLENBQUMsQ0FBQyxtQkFBbUIsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUNqQyxlQUFPLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBRXBDLFFBQVEsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDO2dCQUNwQixRQUFRLENBQUMsUUFBUSxHQUFHLDJCQUEyQixDQUFDO2dCQUNoRCxNQUFNLENBQUMsUUFBUSxDQUFDO1lBQ2xCLENBQUM7WUFDRCxJQUFJLENBQUMsQ0FBQztnQkFDSixrQkFBa0I7Z0JBQ2xCLFFBQVEsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDO2dCQUNwQixRQUFRLENBQUMsUUFBUSxHQUFHLGVBQWUsQ0FBQztZQUN0QyxDQUFDO1lBQ0QsTUFBTSxDQUFDLFFBQVEsQ0FBQztRQUNsQixDQUFDO1FBRUQsaUJBQWlCO1lBQ2YsTUFBTSxDQUFDLGVBQU8sQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDbEMsQ0FBQztLQUdGLENBQUMsQ0FBQyxDQUFDLHdCQUF3QjtBQUU5QixDQUFDLENBQUMseUJBQXlCOzs7Ozs7Ozs7Ozs7QUMvTzNCLDhFQUE4RTtBQUM5RSx5QkFBdUIsZUFBZSxDQUFDO0FBSXZDLHdCQUFzQixjQUFjLENBQUM7QUFDckMsbUNBQThCLHNDQUFzQyxDQUFDO0FBQ3JFLHdCQUF1QixvQkFBb0IsQ0FBQztBQUc1QyxFQUFFLENBQUMsQ0FBQyxlQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztJQUVwQixlQUFNLENBQUMsT0FBTyxDQUFDO1FBR2IsaUJBQWlCLENBQUMsUUFBUTtZQUN4QixpRUFBaUU7WUFDakUsd0RBQXdEO1lBQ3hELFVBQVU7WUFDVixzQkFBc0I7WUFDdEIsNERBQTREO1lBQzVELGtDQUFrQztZQUNsQyxrRUFBa0U7WUFDbEUsSUFBSSxRQUFRLEdBQVE7Z0JBQ2xCLFFBQVEsRUFBRSwyREFBMkQ7Z0JBQ3JFLElBQUksRUFBRSxHQUFHO2FBQ1Y7WUFFRCxJQUFJLFlBQVksR0FBRyxjQUFNLENBQUMsT0FBTyxDQUFDLEVBQUUsTUFBTSxFQUFFLFFBQVEsRUFBRSxDQUFDLENBQUM7WUFHeEQsRUFBRSxDQUFDLENBQUMsWUFBWSxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUM7Z0JBQy9CLFFBQVEsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDO2dCQUNwQixRQUFRLENBQUMsUUFBUSxHQUFHLCtDQUErQyxDQUFDO2dCQUNwRSxNQUFNLENBQUMsUUFBUSxDQUFDO1lBQ2xCLENBQUM7WUFDRCxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsWUFBWSxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3BDLFFBQVEsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDO2dCQUNwQixRQUFRLENBQUMsUUFBUSxHQUFHLDJDQUEyQyxDQUFDO2dCQUNoRSxNQUFNLENBQUMsUUFBUSxDQUFDO1lBQ2xCLENBQUM7WUFDRCxJQUFJLENBQUMsQ0FBQztnQkFDSixNQUFNLENBQUMsUUFBUSxDQUFDO1lBQ2xCLENBQUM7UUFDSCxDQUFDO1FBRUQsWUFBWSxDQUFDLElBQUk7WUFDZixpRUFBaUU7WUFDakUsd0RBQXdEO1lBQ3hELFVBQVU7WUFDVix1QkFBdUI7WUFDdkIsNERBQTREO1lBQzVELGlCQUFpQjtZQUNqQixrRUFBa0U7WUFFbEUsSUFBSSxRQUFRLEdBQVE7Z0JBQ2xCLFFBQVEsRUFBRSxtREFBbUQ7Z0JBQzdELElBQUksRUFBRSxHQUFHO2FBQ1Y7WUFFRCwwREFBMEQ7WUFDMUQsaUJBQWlCO1lBQ2pCLG1DQUFtQztZQUNuQywwREFBMEQ7WUFDMUQsMkRBQTJEO1lBQzNELDhDQUE4QztZQUM5QyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO2dCQUNqQixRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyxlQUFlLENBQUM7Z0JBQ3BDLE1BQU0sQ0FBQyxRQUFRLENBQUM7WUFDbEIsQ0FBQztZQUNELGFBQUssQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFFcEIscUNBQXFDO1lBRXJDLG9GQUFvRjtZQUNwRixJQUFJLG1CQUFtQixHQUFHLEtBQUssQ0FBQztZQUVoQyxJQUFJLFdBQVcsR0FBRyxLQUFLLENBQUM7WUFFeEIsSUFBSSxlQUFlLEdBQUcsSUFBSSxnQ0FBYSxFQUFFLENBQUM7WUFFMUMsV0FBVyxHQUFHLGVBQWUsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsdUJBQXVCO1lBQy9FLG1CQUFtQixHQUFHLFdBQVcsQ0FBQztZQUVsQyxFQUFFLENBQUMsQ0FBQyxtQkFBbUIsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUVqQyxxQ0FBcUM7Z0JBQ3JDLGNBQU0sQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDO29CQUV2QixJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUk7b0JBQ2YsV0FBVyxFQUFFLElBQUksQ0FBQyxXQUFXO29CQUM3QixTQUFTLEVBQUUsZUFBTSxDQUFDLElBQUksRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPO29CQUMxQyxTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUU7aUJBRXRCLENBQUMsQ0FBQyxDQUFDLFlBQVk7Z0JBQ2hCLFFBQVEsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDO2dCQUNwQixRQUFRLENBQUMsUUFBUSxHQUFHLGdDQUFnQyxDQUFDO2dCQUNyRCxNQUFNLENBQUMsUUFBUSxDQUFDO1lBQ2xCLENBQUMsQ0FBQywwQ0FBMEM7WUFDNUMsSUFBSSxDQUFDLENBQUM7Z0JBQ0osa0JBQWtCO2dCQUNsQixRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRyxlQUFlLENBQUM7WUFDdEMsQ0FBQztZQUNELE1BQU0sQ0FBQyxRQUFRLENBQUM7UUFJbEIsQ0FBQztRQUVELFlBQVksQ0FBQyxJQUFJO1lBQ2YsaUVBQWlFO1lBQ2pFLHdEQUF3RDtZQUN4RCxVQUFVO1lBQ1YsdUJBQXVCO1lBQ3ZCLDREQUE0RDtZQUM1RCxpQkFBaUI7WUFDakIsa0VBQWtFO1lBRWxFLElBQUksUUFBUSxHQUFRO2dCQUNsQixRQUFRLEVBQUUsbURBQW1EO2dCQUM3RCxJQUFJLEVBQUUsR0FBRzthQUNWO1lBRUQsMERBQTBEO1lBQzFELGlCQUFpQjtZQUNqQixvQ0FBb0M7WUFDcEMsMERBQTBEO1lBQzFELDJEQUEyRDtZQUMzRCw4Q0FBOEM7WUFDOUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztnQkFDakIsUUFBUSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7Z0JBQ3BCLFFBQVEsQ0FBQyxRQUFRLEdBQUcsZUFBZSxDQUFDO2dCQUNwQyxNQUFNLENBQUMsUUFBUSxDQUFDO1lBQ2xCLENBQUM7WUFDRCxhQUFLLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBRXBCLHFDQUFxQztZQUVyQyxvRkFBb0Y7WUFDcEYsSUFBSSxtQkFBbUIsR0FBRyxLQUFLLENBQUM7WUFFaEMsSUFBSSxXQUFXLEdBQUcsS0FBSyxDQUFDO1lBRXhCLElBQUksZUFBZSxHQUFHLElBQUksZ0NBQWEsRUFBRSxDQUFDO1lBRTFDLFdBQVcsR0FBRyxlQUFlLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLHVCQUF1QjtZQUMvRSxtQkFBbUIsR0FBRyxXQUFXLENBQUM7WUFFbEMsRUFBRSxDQUFDLENBQUMsbUJBQW1CLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQztnQkFFakMscUNBQXFDO2dCQUNyQyxjQUFNLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FDdEIsSUFBSSxDQUFDLEdBQUcsRUFDUjtvQkFDRSxJQUFJLEVBQ0Y7d0JBQ0UsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJO3dCQUNmLFdBQVcsRUFBRSxJQUFJLENBQUMsV0FBVzt3QkFDN0IsU0FBUyxFQUFFLGVBQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTzt3QkFDMUMsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFO3FCQUN0QjtpQkFDSixDQUFDLENBQUMsQ0FBQyxhQUFhO2dCQUduQixRQUFRLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLFFBQVEsR0FBRywwQkFBMEIsQ0FBQztnQkFDL0MsTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNsQixDQUFDLENBQUMsMENBQTBDO1lBQzVDLElBQUksQ0FBQyxDQUFDO2dCQUNKLGtCQUFrQjtnQkFDbEIsUUFBUSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7Z0JBQ3BCLFFBQVEsQ0FBQyxRQUFRLEdBQUcsZUFBZSxDQUFDO1lBQ3RDLENBQUM7WUFDRCxNQUFNLENBQUMsUUFBUSxDQUFDO1FBQ2xCLENBQUM7UUFFRCxZQUFZLENBQUMsSUFBSTtZQUNmLGlFQUFpRTtZQUNqRSx3REFBd0Q7WUFDeEQsVUFBVTtZQUNWLHVCQUF1QjtZQUN2Qiw0REFBNEQ7WUFDNUQsaUJBQWlCO1lBQ2pCLGtFQUFrRTtZQUVsRSxJQUFJLFFBQVEsR0FBUTtnQkFDbEIsUUFBUSxFQUFFLG1EQUFtRDtnQkFDN0QsSUFBSSxFQUFFLEdBQUc7YUFDVjtZQUVELDBEQUEwRDtZQUMxRCxpQkFBaUI7WUFDakIsb0NBQW9DO1lBQ3BDLDBEQUEwRDtZQUMxRCwyREFBMkQ7WUFDM0QsOENBQThDO1lBQzlDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7Z0JBQ2pCLFFBQVEsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDO2dCQUNwQixRQUFRLENBQUMsUUFBUSxHQUFHLGVBQWUsQ0FBQztnQkFDcEMsTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNsQixDQUFDO1lBQ0QsYUFBSyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQztZQUVwQixxQ0FBcUM7WUFFckMsb0ZBQW9GO1lBQ3BGLElBQUksbUJBQW1CLEdBQUcsS0FBSyxDQUFDO1lBRWhDLElBQUksV0FBVyxHQUFHLEtBQUssQ0FBQztZQUV4QixJQUFJLGVBQWUsR0FBRyxJQUFJLGdDQUFhLEVBQUUsQ0FBQztZQUUxQyxXQUFXLEdBQUcsZUFBZSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyx1QkFBdUI7WUFDL0UsbUJBQW1CLEdBQUcsV0FBVyxDQUFDO1lBRWxDLEVBQUUsQ0FBQyxDQUFDLG1CQUFtQixLQUFLLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBQ2pDLGNBQU0sQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFFbkMsUUFBUSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7Z0JBQ3BCLFFBQVEsQ0FBQyxRQUFRLEdBQUcsMEJBQTBCLENBQUM7Z0JBQy9DLE1BQU0sQ0FBQyxRQUFRLENBQUM7WUFDbEIsQ0FBQztZQUNELElBQUksQ0FBQyxDQUFDO2dCQUNKLGtCQUFrQjtnQkFDbEIsUUFBUSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7Z0JBQ3BCLFFBQVEsQ0FBQyxRQUFRLEdBQUcsZUFBZSxDQUFDO1lBQ3RDLENBQUM7WUFDRCxNQUFNLENBQUMsUUFBUSxDQUFDO1FBQ2xCLENBQUM7UUFFRCxnQkFBZ0I7WUFDZCxNQUFNLENBQUMsY0FBTSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUNqQyxDQUFDO0tBR0YsQ0FBQyxDQUFDLENBQUMsd0JBQXdCO0FBRTlCLENBQUMsQ0FBQyx5QkFBeUI7Ozs7Ozs7Ozs7OztBQy9PM0IseUJBQXFCLGVBQWUsQ0FBQztBQUtyQywyQkFBd0IsdUJBQXVCLENBQUM7QUFFaEQsRUFBRSxDQUFDLENBQUMsZUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7SUFJdEIsNkNBQTZDO0lBQzdDLGVBQU0sQ0FBQyxPQUFPLENBQUMsb0JBQW9CLEVBQUU7UUFFbkMsTUFBTSxDQUFDLG1CQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBRTNCLENBQUMsQ0FBQyxDQUFDO0FBS0gsQ0FBQyxDQUFDLDZCQUE2Qjs7Ozs7Ozs7Ozs7O0FDckIvQix5QkFBcUIsZUFBZSxDQUFDO0FBS3JDLDJCQUE2Qix1QkFBdUIsQ0FBQztBQUVyRCxFQUFFLENBQUMsQ0FBQyxlQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztJQUl0Qiw2Q0FBNkM7SUFDN0MsZUFBTSxDQUFDLE9BQU8sQ0FBQyx3QkFBd0IsRUFBRTtRQUV2QyxNQUFNLENBQUMsdUJBQVksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7SUFFL0IsQ0FBQyxDQUFDLENBQUM7QUFLSCxDQUFDLENBQUMsNkJBQTZCOzs7Ozs7Ozs7Ozs7QUNyQi9CLHlCQUFxQixlQUFlLENBQUM7QUFLckMsMkJBQXlCLHVCQUF1QixDQUFDO0FBRWpELEVBQUUsQ0FBQyxDQUFDLGVBQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0lBSXRCLDRDQUE0QztJQUM1QyxlQUFNLENBQUMsT0FBTyxDQUFDLG1CQUFtQixFQUFFO1FBRWxDLE1BQU0sQ0FBQyxtQkFBUSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUUzQixDQUFDLENBQUMsQ0FBQztBQUtILENBQUMsQ0FBQyw2QkFBNkI7Ozs7Ozs7Ozs7OztBQ3JCL0IseUJBQXFCLGVBQWUsQ0FBQztBQUtyQywyQkFBMEIsdUJBQXVCLENBQUM7QUFFbEQsRUFBRSxDQUFDLENBQUMsZUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7SUFJdEIsMENBQTBDO0lBQzFDLGVBQU0sQ0FBQyxPQUFPLENBQUMscUJBQXFCLEVBQUU7UUFFcEMsTUFBTSxDQUFDLG9CQUFTLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBRTVCLENBQUMsQ0FBQyxDQUFDO0FBSUgsQ0FBQyxDQUFDLDZCQUE2Qjs7Ozs7Ozs7Ozs7O0FDcEIvQix5QkFBcUIsZUFBZSxDQUFDO0FBS3JDLDJCQUE0Qix1QkFBdUIsQ0FBQztBQUVwRCxFQUFFLENBQUMsQ0FBQyxlQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztJQUl0Qiw0Q0FBNEM7SUFDNUMsZUFBTSxDQUFDLE9BQU8sQ0FBQyxzQkFBc0IsRUFBRTtRQUVyQyxNQUFNLENBQUMsc0JBQVcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7SUFFOUIsQ0FBQyxDQUFDLENBQUM7QUFLSCxDQUFDLENBQUMsNkJBQTZCOzs7Ozs7Ozs7Ozs7QUNyQi9CLHlCQUFxQixlQUFlLENBQUM7QUFLckMsMkJBQXdCLHVCQUF1QixDQUFDO0FBRWhELEVBQUUsQ0FBQyxDQUFDLGVBQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0lBSXRCLDZDQUE2QztJQUM3QyxlQUFNLENBQUMsT0FBTyxDQUFDLGtCQUFrQixFQUFFO1FBRWpDLE1BQU0sQ0FBQyxrQkFBTyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUUxQixDQUFDLENBQUMsQ0FBQztBQUtILENBQUMsQ0FBQyw2QkFBNkI7Ozs7Ozs7Ozs7OztBQ3JCL0IseUJBQXFCLGVBQWUsQ0FBQztBQUtyQywyQkFBMkIsdUJBQXVCLENBQUM7QUFFbkQsRUFBRSxDQUFDLENBQUMsZUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7SUFJdEIsMkNBQTJDO0lBQzNDLGVBQU0sQ0FBQyxPQUFPLENBQUMsb0JBQW9CLEVBQUU7UUFFbkMsTUFBTSxDQUFDLHFCQUFVLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBRTdCLENBQUMsQ0FBQyxDQUFDO0FBS0gsQ0FBQyxDQUFDLDZCQUE2Qjs7Ozs7Ozs7Ozs7O0FDckIvQix5QkFBdUIsZUFBZSxDQUFDO0FBS3ZDLDJCQUEwQix1QkFBdUIsQ0FBQztBQUVsRCxFQUFFLENBQUMsQ0FBQyxlQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztJQUlwQixvQ0FBb0M7SUFDcEMsZUFBTSxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUU7UUFDNUIsb0RBQW9EO1FBQ3BELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1lBQ2hCLE1BQU0sQ0FBQyxvQkFBUyxDQUFDLElBQUksQ0FBQyxFQUFFLGVBQWUsRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQztRQUMxRCxDQUFDO1FBRUQsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztJQUV0QixDQUFDLENBQUMsQ0FBQztJQUVILDZCQUE2QjtJQUU3QixlQUFNLENBQUMsT0FBTyxDQUFDLCtCQUErQixFQUFFO1FBQzlDLE1BQU0sQ0FBQyxvQkFBUyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUM1QixDQUFDLENBQUMsQ0FBQztBQUtMLENBQUMsQ0FBQyw2QkFBNkI7Ozs7Ozs7Ozs7OztBQy9CL0IseUJBQXFCLGVBQWUsQ0FBQztBQUtyQywyQkFBdUIsdUJBQXVCLENBQUM7QUFFL0MsRUFBRSxDQUFDLENBQUMsZUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7SUFJdEIsd0NBQXdDO0lBQ3hDLGVBQU0sQ0FBQyxPQUFPLENBQUMsaUJBQWlCLEVBQUU7UUFFaEMsTUFBTSxDQUFDLGlCQUFNLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBRXpCLENBQUMsQ0FBQyxDQUFDO0FBS0gsQ0FBQyxDQUFDLDZCQUE2Qjs7Ozs7Ozs7Ozs7O0FDckIvQix5QkFBdUIsZUFBZSxDQUFDO0FBSXZDLDRCQUEwQix5QkFBeUIsQ0FBQztBQUVwRCxJQUFJLGlCQUFpQixHQUFHLElBQUkscUJBQVMsRUFBRSxDQUFDO0FBQ3hDLE1BQU0sZ0JBQWdCLEdBQUcsaUJBQWlCLENBQUMsVUFBVSxDQUFDO0FBRXRELEVBQUUsQ0FBQyxDQUFDLGVBQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0lBS3BCLGVBQU0sQ0FBQyxPQUFPLENBQUMsd0JBQXdCLEVBQUU7UUFFdkMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7WUFFaEIsTUFBTSxDQUFDLGVBQU0sQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDN0IsQ0FBQztRQUNELE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7SUFFdEIsQ0FBQyxDQUFDLENBQUM7SUFFSCxlQUFNLENBQUMsT0FBTyxDQUFDLGtDQUFrQyxFQUFFO1FBRWpELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1lBR2hCLE1BQU0sQ0FBQyxlQUFNLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFDLGdCQUFnQixFQUFDLEVBQUMsR0FBRyxFQUFDLGdCQUFnQixFQUFDLEVBQUMsQ0FBQyxDQUFDO1FBQ3RFLENBQUM7UUFDRCxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO0lBRXRCLENBQUMsQ0FBQyxDQUFDO0FBS0wsQ0FBQyxDQUFDLDZCQUE2Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN0Qy9CLDZFQUE2RTtBQUU3RSx5QkFBdUIsZUFBZSxDQUFDO0FBSXZDO0lBRUEsa0JBQWtCO0lBRWxCO0lBRUEsQ0FBQztJQUVELDZGQUE2RjtJQUM3RixzQ0FBc0M7SUFDdEMsV0FBVyxDQUFDLE1BQU07UUFDaEIsSUFBSSxNQUFNLENBQUM7UUFDWCxJQUFJLENBQUM7WUFDSCxNQUFNLEdBQUcsZUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsRUFBRSxLQUFLLEVBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQztZQUNoRCxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssT0FBTyxDQUFDLENBQUMsQ0FBQztnQkFDL0Isd0JBQXdCO2dCQUN4QixNQUFNLENBQUMsSUFBSSxDQUFDO1lBQ2QsQ0FBQztZQUNELElBQUksRUFBQztnQkFDSCxNQUFNLENBQUMsS0FBSyxDQUFDO1lBQ2YsQ0FBQztRQUNILENBQUU7UUFBQSxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1lBQ2Isb0JBQW9CO1lBQ3BCLE1BQU0sQ0FBQyxLQUFLLENBQUM7UUFDZixDQUFDO0lBQ0gsQ0FBQyxDQUFDLG9CQUFvQjtJQUV0QixlQUFlLENBQUMsTUFBTTtRQUNwQixJQUFJLE1BQU0sQ0FBQztRQUNYLElBQUksQ0FBQztZQUNILE1BQU0sR0FBRyxlQUFNLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxFQUFFLEtBQUssRUFBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDO1lBQ2hELEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDO2dCQUNuQyx3QkFBd0I7Z0JBQ3hCLE1BQU0sQ0FBQyxJQUFJLENBQUM7WUFDZCxDQUFDO1lBQ0QsSUFBSSxFQUFDO2dCQUNILE1BQU0sQ0FBQyxLQUFLLENBQUM7WUFDZixDQUFDO1FBQ0gsQ0FBRTtRQUFBLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFDYixvQkFBb0I7WUFDcEIsTUFBTSxDQUFDLEtBQUssQ0FBQztRQUNmLENBQUM7SUFDSCxDQUFDLENBQUMsd0JBQXdCO0lBRTFCLGFBQWEsQ0FBQyxNQUFNO1FBQ2xCLElBQUksTUFBTSxDQUFDO1FBQ1gsSUFBSSxDQUFDO1lBQ0gsTUFBTSxHQUFHLGVBQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEVBQUUsS0FBSyxFQUFDLE1BQU0sRUFBRSxDQUFDLENBQUM7WUFDaEQsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2pDLHdCQUF3QjtnQkFDeEIsTUFBTSxDQUFDLElBQUksQ0FBQztZQUNkLENBQUM7WUFDRCxJQUFJLEVBQUM7Z0JBQ0gsTUFBTSxDQUFDLEtBQUssQ0FBQztZQUNmLENBQUM7UUFDSCxDQUFFO1FBQUEsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztZQUNiLG9CQUFvQjtZQUNwQixNQUFNLENBQUMsS0FBSyxDQUFDO1FBQ2YsQ0FBQztJQUNILENBQUM7QUFJRCxDQUFDO0FBL0RZLHFCQUFhLGdCQStEekIsaUJBQWU7Ozs7Ozs7Ozs7OztBQ3JFaEIsa0VBQWtFO0FBTWxFO0lBRUU7SUFFQSxDQUFDO0FBR0gsQ0FBQztBQVBZLCtCQUF1QiwwQkFPbkMseUNBQXVDOzs7Ozs7Ozs7Ozs7QUNYeEMseUJBQXVCLGVBQWUsQ0FBQztBQWF2QyxFQUFFLENBQUMsQ0FBQyxlQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztJQUVwQixlQUFNLENBQUMsT0FBTyxDQUFDO1FBSWIsMENBQTBDO1FBQzFDLDBDQUEwQztRQUMxQyxzQ0FBc0M7UUFDdEMsc0NBQXNDO1FBQ3RDLDhDQUE4QztRQUM5QywwQ0FBMEM7UUFFMUMsZUFBZSxDQUFDLElBQUk7WUFHbEIsOEJBQThCO1lBQzlCLElBQUksTUFBTSxHQUFHLEdBQUcsQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUM7WUFDMUMsSUFBSSxNQUFNLEdBQUcsSUFBSSxNQUFNLEVBQUUsQ0FBQztZQUUxQixJQUFJLGNBQWMsR0FBRztnQkFDbkIsS0FBSyxFQUFFLFVBQVU7Z0JBQ2pCLFNBQVMsRUFBRSxFQUFFO2dCQUNiLFFBQVEsRUFBRSxFQUFFO2dCQUNaLG9CQUFvQixFQUFFLEVBQUU7YUFDekIsQ0FBQztZQUVGLElBQUksSUFBSSxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUM3QixJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDO2dCQUM3QixHQUFHLEVBQUUsZ0NBQWdDO2FBQ3RDLENBQUMsQ0FBQztZQUNILElBQUksSUFBSSxHQUFHO2dCQUNULE1BQU0sRUFBRSxpQkFBaUI7Z0JBQ3pCLEtBQUssRUFBRSxNQUFNO2dCQUNiLHNEQUFzRDtnQkFDdEQsVUFBVSxFQUFFLEVBQUU7Z0JBQ2QsU0FBUyxFQUFFLENBQUMsQ0FBQyxhQUFhO2FBQzNCLENBQUM7WUFHRixNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsUUFBUSxHQUFHLE1BQU0sR0FBRyxJQUFJLENBQUMsR0FBRyxHQUFHLE1BQU0sR0FBRyxJQUFJLENBQUMsR0FBRyxHQUFHLDhCQUE4QixFQUFFLElBQUksQ0FBQyxRQUFRLEVBQ3hILGtCQUFrQixHQUFHLEVBQUUsUUFBUTtnQkFDN0Isc0JBQXNCO2dCQUN0Qix3QkFBd0I7Z0JBQ3hCLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7b0JBQ1IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQ0FBbUMsQ0FBQyxDQUFDO29CQUNqRCxjQUFjLENBQUMsS0FBSyxHQUFHLGtCQUFrQixDQUFDO29CQUMxQyxNQUFNLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxDQUFDO2dCQUNoQyxDQUFDO2dCQUVELEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztvQkFDVCxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO3dCQUNiLHlCQUF5Qjt3QkFDekIsbUJBQW1CO3dCQUNuQixjQUFjO3dCQUVkLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxjQUFjLEdBQUcsTUFBTSxHQUFHLElBQUksQ0FBQyxHQUFHLEdBQUcsTUFBTSxHQUFHLElBQUksQ0FBQyxHQUFHLEdBQUcsOEJBQThCLEVBQUUsSUFBSSxFQUFFLFVBQVMsR0FBRyxFQUFFLFFBQVE7NEJBQy9JLElBQUksTUFBTSxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQzs0QkFDL0IsTUFBTSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQzs0QkFDcEIsUUFBUSxDQUFDLEVBQUUsQ0FBQyxhQUFhLEVBQUUsa0JBQWtCLE1BQU07Z0NBQ2pELDBEQUEwRDtnQ0FDMUQsOEJBQThCO2dDQUM5QixPQUFPLENBQUMsR0FBRyxDQUFDLFVBQVUsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMscUJBQXFCO2dDQUN4RSxPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyx3QkFBd0I7Z0NBR3pELG1FQUFtRTtnQ0FDbkUsNERBQTREO2dDQUM1RCxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLFNBQVMsSUFBSSxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7b0NBQ2hELGNBQWMsQ0FBQyxTQUFTLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUM7b0NBQ25ELGNBQWMsQ0FBQyxRQUFRLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7Z0NBQzdDLENBQUM7Z0NBQUMsSUFBSSxDQUFDLENBQUM7b0NBQ04sY0FBYyxDQUFDLFNBQVMsR0FBRyxPQUFPLENBQUM7b0NBQ25DLGNBQWMsQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQztnQ0FDaEQsQ0FBQztnQ0FDRCxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQztvQ0FDdkMsY0FBYyxDQUFDLG9CQUFvQixHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQzlFLENBQUM7Z0NBQUMsSUFBSSxDQUFDLENBQUM7b0NBQ04sY0FBYyxDQUFDLG9CQUFvQixHQUFHLFFBQVEsQ0FBQztnQ0FDakQsQ0FBQztnQ0FFRCxNQUFNLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxDQUFDOzRCQUNoQyxDQUFDLENBQUMsQ0FBQzs0QkFDSCxRQUFRLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxVQUFTLEdBQUc7Z0NBQy9CLGNBQWMsQ0FBQyxLQUFLLEdBQUcsaUNBQWlDLENBQUM7Z0NBQ3pELE9BQU8sQ0FBQyxLQUFLLENBQUMsU0FBUyxHQUFHLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQztnQ0FDdkMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsQ0FBQzs0QkFDaEMsQ0FBQyxDQUFDLENBQUM7d0JBQ0wsQ0FBQyxDQUFDLENBQUM7b0JBRUwsQ0FBQyxDQUFDLG1CQUFtQjtnQkFFdkIsQ0FBQyxDQUFDLGVBQWU7WUFFbkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxpQkFBaUI7WUFFdkIsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUV2QixDQUFDO1FBRUQseURBQXlEO1FBQ3pELHdEQUF3RDtRQUN4RCwwQ0FBMEM7UUFDMUMsMENBQTBDO1FBQzFDLHFDQUFxQztRQUNyQyxzQ0FBc0M7UUFDdEMsOENBQThDO1FBQzlDLDBDQUEwQztRQUUxQyxXQUFXLENBQUMsSUFBSTtZQUVkLDhCQUE4QjtZQUM5QixJQUFJLE1BQU0sR0FBRyxHQUFHLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDO1lBQzFDLElBQUksTUFBTSxHQUFHLElBQUksTUFBTSxFQUFFLENBQUM7WUFFMUIsSUFBSSxjQUFjLEdBQUc7Z0JBQ25CLFFBQVEsRUFBRSxPQUFPO2dCQUNqQixJQUFJLEVBQUUsRUFBRTtnQkFDUixvQkFBb0IsRUFBRSxFQUFFO2FBQ3pCLENBQUM7WUFDRixJQUFJLElBQUksR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDN0IsSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQztnQkFDN0IsR0FBRyxFQUFFLGdDQUFnQzthQUN0QyxDQUFDLENBQUM7WUFFSCxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsUUFBUSxHQUFHLE1BQU0sR0FBRyxJQUFJLENBQUMsR0FBRyxHQUFHLE1BQU0sR0FBRyxJQUFJLENBQUMsR0FBRyxHQUFHLDhCQUE4QixFQUFFLElBQUksQ0FBQyxRQUFRLEVBQ3hILGtCQUFrQixHQUFHLEVBQUUsUUFBUTtnQkFDN0IsdUJBQXVCO2dCQUN2Qix5QkFBeUI7Z0JBQ3pCLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7b0JBQ1IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQ0FBbUMsQ0FBQyxDQUFDO29CQUNqRCxjQUFjLENBQUMsUUFBUSxHQUFHLGtCQUFrQixDQUFDO29CQUM3QyxNQUFNLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxDQUFDO2dCQUNoQyxDQUFDO2dCQUNELEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztvQkFDVCxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO3dCQUNiLGNBQWMsQ0FBQyxRQUFRLEdBQUcsa0JBQWtCLENBQUM7d0JBQzdDLE1BQU0sQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLENBQUM7b0JBQ2hDLENBQUM7Z0JBQ0gsQ0FBQztZQUNILENBQUMsQ0FBQyxDQUFDO1lBQ0wsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUN2QixDQUFDO0tBR0YsQ0FBQyxDQUFDLENBQUMscUJBQXFCO0FBRTNCLENBQUMsQ0FBQywwQkFBMEI7Ozs7Ozs7Ozs7OztBQ2pLNUIsdUJBQXFCLGFBQWEsQ0FBQztBQUNuQyx5QkFBdUIsZUFBZSxDQUFDO0FBT3ZDLDRCQUEwQiwyQkFBMkIsQ0FBQztBQUV0RCxNQUFNLE1BQU0sR0FBRyxvREFBb0QsQ0FBQztBQUNwRSxNQUFNLHNCQUFzQixHQUFHLHNFQUFzRSxDQUFDO0FBRXRHLEVBQUUsQ0FBQyxDQUFDLGVBQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0lBRXBCLGVBQU0sQ0FBQyxPQUFPLENBQUM7UUFFYix5REFBeUQ7UUFDekQseURBQXlEO1FBQ3pELHlEQUF5RDtRQUV6RCxhQUFhLENBQUMsSUFBSTtZQUNaLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUVmLElBQUksaUJBQWlCLEdBQUcsSUFBSSxxQkFBUyxFQUFFLENBQUM7WUFFeEMsSUFBSSxPQUFPLEdBQUcsVUFBVSxNQUFNLEVBQUUsUUFBUTtnQkFDdEMsSUFBSSxDQUFDO29CQUNILElBQUksUUFBUSxHQUFHLFdBQUksQ0FBQyxJQUFJLENBQUUsTUFBTSxFQUFFLE1BQU0sRUFDdEMsRUFBQyxpQkFBaUIsRUFBRTs0QkFDbEIsR0FBRyxFQUFFLGlCQUFpQixDQUFDLE1BQU07NEJBQzdCLElBQUksRUFBRSxpQkFBaUIsQ0FBQyxjQUFjO3lCQUN2QyxFQUFDLElBQUksRUFBQyxDQUNSLENBQUM7b0JBQ0YsUUFBUSxDQUFDLElBQUksRUFBRSxRQUFRLENBQUMsQ0FBQztnQkFDM0IsQ0FBRTtnQkFBQSxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO29CQUNmLElBQUksU0FBUyxDQUFDO29CQUNkLElBQUksWUFBWSxDQUFDO29CQUNqQixFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQzt3QkFDbkIsU0FBUyxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQzt3QkFDckMsWUFBWSxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQztvQkFDN0MsQ0FBQztvQkFBQyxJQUFJLENBQUMsQ0FBQzt3QkFDTixTQUFTLEdBQUcsR0FBRyxDQUFDO3dCQUNoQixZQUFZLEdBQUcsdUJBQXVCLENBQUM7b0JBQ3pDLENBQUM7b0JBQ0QsSUFBSSxPQUFPLEdBQUcsSUFBSSxlQUFNLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRSxZQUFZLENBQUMsQ0FBQztvQkFDeEQsUUFBUSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDMUIsQ0FBQztZQUNILENBQUM7WUFFRCxJQUFJLFFBQVEsR0FBRyxlQUFNLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBRWpELE1BQU0sQ0FBQyxRQUFRLENBQUM7UUFHcEIsQ0FBQztRQUVELG1CQUFtQixDQUFDLElBQUk7WUFDbEIsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBRWYsSUFBSSxpQkFBaUIsR0FBRyxJQUFJLHFCQUFTLEVBQUUsQ0FBQztZQUV4QyxJQUFJLE9BQU8sR0FBRyxVQUFVLE1BQU0sRUFBRSxRQUFRO2dCQUN0QyxJQUFJLENBQUM7b0JBQ0gsSUFBSSxRQUFRLEdBQUcsV0FBSSxDQUFDLElBQUksQ0FBRSxLQUFLLEVBQUUsTUFBTSxHQUFDLEdBQUcsR0FBQyxJQUFJLENBQUMsUUFBUSxFQUN2RCxFQUFDLGlCQUFpQixFQUFFOzRCQUNsQixHQUFHLEVBQUUsaUJBQWlCLENBQUMsTUFBTTs0QkFDN0IsSUFBSSxFQUFFLGlCQUFpQixDQUFDLGNBQWM7eUJBQ3ZDLEVBQUMsSUFBSSxFQUFDLENBQ1IsQ0FBQztvQkFDRixRQUFRLENBQUMsSUFBSSxFQUFFLFFBQVEsQ0FBQyxDQUFDO2dCQUMzQixDQUFFO2dCQUFBLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7b0JBQ2YsSUFBSSxTQUFTLENBQUM7b0JBQ2QsSUFBSSxZQUFZLENBQUM7b0JBQ2pCLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO3dCQUNuQixTQUFTLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO3dCQUNyQyxZQUFZLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDO29CQUM3QyxDQUFDO29CQUFDLElBQUksQ0FBQyxDQUFDO3dCQUNOLFNBQVMsR0FBRyxHQUFHLENBQUM7d0JBQ2hCLFlBQVksR0FBRyx1QkFBdUIsQ0FBQztvQkFDekMsQ0FBQztvQkFDRCxJQUFJLE9BQU8sR0FBRyxJQUFJLGVBQU0sQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLFlBQVksQ0FBQyxDQUFDO29CQUN4RCxRQUFRLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUMxQixDQUFDO1lBQ0gsQ0FBQztZQUVELElBQUksUUFBUSxHQUFHLGVBQU0sQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7WUFFakQsTUFBTSxDQUFDLFFBQVEsQ0FBQztRQUVwQixDQUFDO1FBR0wsbUJBQW1CO1lBQ2YsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBRWYsSUFBSSxpQkFBaUIsR0FBRyxJQUFJLHFCQUFTLEVBQUUsQ0FBQztZQUV4QyxJQUFJLE9BQU8sR0FBRyxVQUFVLHNCQUFzQixFQUFFLFFBQVE7Z0JBQ3RELElBQUksQ0FBQztvQkFDSCxJQUFJLFFBQVEsR0FBRyxXQUFJLENBQUMsSUFBSSxDQUFFLEtBQUssRUFBRSxzQkFBc0IsRUFDckQsRUFBQyxpQkFBaUIsRUFBRTs0QkFDbEIsR0FBRyxFQUFFLGlCQUFpQixDQUFDLE1BQU07NEJBQzdCLElBQUksRUFBRSxpQkFBaUIsQ0FBQyxjQUFjO3lCQUN2QyxFQUFDLENBQ0gsQ0FBQyxPQUFPLENBQUM7b0JBQ1YsUUFBUSxDQUFDLElBQUksRUFBRSxRQUFRLENBQUMsQ0FBQztnQkFDM0IsQ0FBRTtnQkFBQSxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO29CQUNmLElBQUksU0FBUyxDQUFDO29CQUNkLElBQUksWUFBWSxDQUFDO29CQUNqQixFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQzt3QkFDbkIsU0FBUyxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQzt3QkFDckMsWUFBWSxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQztvQkFDN0MsQ0FBQztvQkFBQyxJQUFJLENBQUMsQ0FBQzt3QkFDTixTQUFTLEdBQUcsR0FBRyxDQUFDO3dCQUNoQixZQUFZLEdBQUcsdUJBQXVCLENBQUM7b0JBQ3pDLENBQUM7b0JBQ0QsSUFBSSxPQUFPLEdBQUcsSUFBSSxlQUFNLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRSxZQUFZLENBQUMsQ0FBQztvQkFDeEQsUUFBUSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDMUIsQ0FBQztZQUNILENBQUM7WUFFRCxxRUFBcUU7WUFDckUsSUFBSSxRQUFRLEdBQUcsZUFBTSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO1lBQ2pFLFFBQVEsR0FBRyxRQUFRLENBQUMsSUFBSSxFQUFFLENBQUM7WUFDM0IsUUFBUSxHQUFHLFFBQVEsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDbEMsUUFBUSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDOUIsUUFBUSxHQUFHLEdBQUcsR0FBRyxRQUFRLEdBQUcsR0FBRyxDQUFDO1lBQ2hDLFFBQVEsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBRWhDLE1BQU0sQ0FBQyxRQUFRLENBQUM7WUFFaEIsb0RBQW9EO1lBQ3BELGNBQWM7WUFDZCw4QkFBOEI7WUFDOUIsb0NBQW9DO1lBQ3BDLElBQUk7WUFDSix1QkFBdUI7WUFDdkIsa0JBQWtCO1lBQ2xCLFlBQVk7WUFDWixxREFBcUQ7UUFFdkQsQ0FBQztRQUVELHFDQUFxQztRQUNyQyxzQkFBc0I7UUFDdEIscUNBQXFDO1FBRXJDLGdCQUFnQixDQUFDLFFBQVE7WUFDdkIsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBRWYsSUFBSSxpQkFBaUIsR0FBRyxJQUFJLHFCQUFTLEVBQUUsQ0FBQztZQUN4QyxJQUFJLG9CQUFvQixHQUFHLE1BQU0sR0FBQyxHQUFHLEdBQUMsUUFBUSxDQUFDO1lBRS9DLElBQUksT0FBTyxHQUFHLFVBQVUsb0JBQW9CLEVBQUUsUUFBUTtnQkFDcEQsSUFBSSxDQUFDO29CQUNILElBQUksUUFBUSxHQUFHLFdBQUksQ0FBQyxJQUFJLENBQUUsS0FBSyxFQUFFLG9CQUFvQixFQUNuRCxFQUFDLGlCQUFpQixFQUFFOzRCQUNsQixHQUFHLEVBQUUsaUJBQWlCLENBQUMsTUFBTTs0QkFDN0IsSUFBSSxFQUFFLGlCQUFpQixDQUFDLGNBQWM7eUJBQ3ZDLEVBQUMsQ0FDSCxDQUFDLE9BQU8sQ0FBQztvQkFDVixRQUFRLENBQUMsSUFBSSxFQUFFLFFBQVEsQ0FBQyxDQUFDO2dCQUMzQixDQUFFO2dCQUFBLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7b0JBQ2YsSUFBSSxTQUFTLENBQUM7b0JBQ2QsSUFBSSxZQUFZLENBQUM7b0JBQ2pCLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO3dCQUNuQixTQUFTLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO3dCQUNyQyxZQUFZLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDO29CQUM3QyxDQUFDO29CQUFDLElBQUksQ0FBQyxDQUFDO3dCQUNOLFNBQVMsR0FBRyxHQUFHLENBQUM7d0JBQ2hCLFlBQVksR0FBRyx1QkFBdUIsQ0FBQztvQkFDekMsQ0FBQztvQkFDRCxJQUFJLE9BQU8sR0FBRyxJQUFJLGVBQU0sQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLFlBQVksQ0FBQyxDQUFDO29CQUN4RCxRQUFRLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUMxQixDQUFDO1lBQ0gsQ0FBQztZQUVELElBQUksUUFBUSxHQUFHLGVBQU0sQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsb0JBQW9CLENBQUMsQ0FBQztZQUMvRCxRQUFRLEdBQUcsUUFBUSxDQUFDLElBQUksRUFBRSxDQUFDO1lBQzNCLFFBQVEsR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ2xDLFFBQVEsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQzlCLFFBQVEsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBRWhDLE1BQU0sQ0FBQyxRQUFRLENBQUM7UUFDaEIsQ0FBQztRQUdILHFDQUFxQztRQUNyQyw0QkFBNEI7UUFDNUIscUNBQXFDO1FBQ3JDLGVBQWUsQ0FBQyxhQUFhO1lBRXZCLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUNmLElBQUksaUJBQWlCLEdBQUcsSUFBSSxxQkFBUyxFQUFFLENBQUM7WUFFeEMsSUFBSSwwQkFBMEIsR0FBRyxNQUFNLEdBQUcsT0FBTyxHQUFFLGFBQWEsQ0FBQztZQUNqRSwyQ0FBMkM7WUFFM0MsSUFBSSxPQUFPLEdBQUcsVUFBVSwwQkFBMEIsRUFBRSxRQUFRO2dCQUMxRCxJQUFJLENBQUM7b0JBQ0gsSUFBSSxRQUFRLEdBQUcsV0FBSSxDQUFDLElBQUksQ0FDdEIsS0FBSyxFQUNMLDBCQUEwQixFQUMxQixFQUFDLGlCQUFpQixFQUFFOzRCQUNsQixHQUFHLEVBQUUsaUJBQWlCLENBQUMsTUFBTTs0QkFDN0IsSUFBSSxFQUFFLGlCQUFpQixDQUFDLGNBQWM7eUJBQ3ZDLEVBQUMsQ0FDSCxDQUFDLE9BQU8sQ0FBQztvQkFDVixRQUFRLENBQUMsSUFBSSxFQUFFLFFBQVEsQ0FBQyxDQUFDO2dCQUMzQixDQUFFO2dCQUFBLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7b0JBQ2YsSUFBSSxTQUFTLENBQUM7b0JBQ2QsSUFBSSxZQUFZLENBQUM7b0JBQ2pCLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO3dCQUNuQixTQUFTLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO3dCQUNyQyxZQUFZLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDO29CQUM3QyxDQUFDO29CQUFDLElBQUksQ0FBQyxDQUFDO3dCQUNOLFNBQVMsR0FBRyxHQUFHLENBQUM7d0JBQ2hCLFlBQVksR0FBRyx1QkFBdUIsQ0FBQztvQkFDekMsQ0FBQztvQkFDRCxJQUFJLE9BQU8sR0FBRyxJQUFJLGVBQU0sQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLFlBQVksQ0FBQyxDQUFDO29CQUN4RCxRQUFRLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUMxQixDQUFDO1lBQ0gsQ0FBQztZQUVELHFFQUFxRTtZQUNyRSxJQUFJLFFBQVEsR0FBRyxlQUFNLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDLDBCQUEwQixDQUFDLENBQUM7WUFDckUsUUFBUSxHQUFHLFFBQVEsQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUMzQixRQUFRLEdBQUcsUUFBUSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNsQyxRQUFRLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUM5QixRQUFRLEdBQUcsR0FBRyxHQUFHLFFBQVEsR0FBRyxHQUFHLENBQUM7WUFDaEMsUUFBUSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDaEMsTUFBTSxDQUFDLFFBQVEsQ0FBQztRQUN0QixDQUFDO1FBR0QscUNBQXFDO1FBQ3JDLDRCQUE0QjtRQUM1QixxQ0FBcUM7UUFFckMsY0FBYyxFQUFHO1lBQ2YsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQ2YsSUFBSSxpQkFBaUIsR0FBRyxJQUFJLHFCQUFTLEVBQUUsQ0FBQztZQUV4QyxJQUFJLE9BQU8sR0FBRyxVQUFVLE1BQU0sRUFBRSxRQUFRO2dCQUN0QyxJQUFJLENBQUM7b0JBQ0gsSUFBSSxRQUFRLEdBQUcsV0FBSSxDQUFDLElBQUksQ0FDdEIsS0FBSyxFQUNMLE1BQU0sRUFDTixFQUFDLGlCQUFpQixFQUFFOzRCQUNsQixHQUFHLEVBQUUsaUJBQWlCLENBQUMsTUFBTTs0QkFDN0IsSUFBSSxFQUFFLGlCQUFpQixDQUFDLGNBQWM7eUJBQ3ZDLEVBQUMsQ0FDSCxDQUFDLE9BQU8sQ0FBQztvQkFDVixRQUFRLENBQUMsSUFBSSxFQUFFLFFBQVEsQ0FBQyxDQUFDO2dCQUMzQixDQUFFO2dCQUFBLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7b0JBQ2YsSUFBSSxTQUFTLENBQUM7b0JBQ2QsSUFBSSxZQUFZLENBQUM7b0JBQ2pCLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO3dCQUNuQixTQUFTLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO3dCQUNyQyxZQUFZLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDO29CQUM3QyxDQUFDO29CQUFDLElBQUksQ0FBQyxDQUFDO3dCQUNOLFNBQVMsR0FBRyxHQUFHLENBQUM7d0JBQ2hCLFlBQVksR0FBRyx1QkFBdUIsQ0FBQztvQkFDekMsQ0FBQztvQkFDRCxJQUFJLE9BQU8sR0FBRyxJQUFJLGVBQU0sQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLFlBQVksQ0FBQyxDQUFDO29CQUN4RCxRQUFRLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUMxQixDQUFDO1lBQ0gsQ0FBQztZQUVELHFFQUFxRTtZQUNyRSxJQUFJLFFBQVEsR0FBRyxlQUFNLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ2pELFFBQVEsR0FBRyxRQUFRLENBQUMsSUFBSSxFQUFFLENBQUM7WUFDM0IsUUFBUSxHQUFHLFFBQVEsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDbEMsUUFBUSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDOUIsUUFBUSxHQUFHLEdBQUcsR0FBRyxRQUFRLEdBQUcsR0FBRyxDQUFDO1lBQ2hDLFFBQVEsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBRWhDLE1BQU0sQ0FBQyxRQUFRLENBQUM7UUFFbEIsQ0FBQztLQUlKLENBQUMsQ0FBQyxDQUFDLHFCQUFxQjtBQUUzQixDQUFDLENBQUMsMEJBQTBCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQy9SNUIsMERBQTBEO0FBQzFELCtDQUErQztBQUMvQyx5QkFBeUI7QUFDekIsS0FBSztBQUNMLEtBQUs7QUFJTCx1QkFBcUIsYUFBYSxDQUFDO0FBQ25DLHlCQUF1QixlQUFlLENBQUM7QUFNdkMsNEJBQTBCLDJCQUEyQixDQUFDO0FBRXRELE1BQU0sTUFBTSxHQUFHLG9EQUFvRCxDQUFDO0FBRXBFLEVBQUUsQ0FBQyxDQUFDLGVBQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0lBRXBCLGVBQU0sQ0FBQyxPQUFPLENBQUM7UUFFYixxQ0FBcUM7UUFDckMscUNBQXFDO1FBQ3JDLHFDQUFxQztRQUVyQyxtQkFBbUI7WUFDZixJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDZixJQUFJLGlCQUFpQixHQUFHLElBQUkscUJBQVMsRUFBRSxDQUFDO1lBQ3hDLE1BQU0sc0JBQXNCLEdBQUcsNERBQTRELENBQUM7WUFDNUYsSUFBSSxPQUFPLEdBQUcsVUFBVSxzQkFBc0IsRUFBRSxRQUFRO2dCQUN0RCxJQUFJLENBQUM7b0JBQ0gsSUFBSSxRQUFRLEdBQUcsV0FBSSxDQUFDLElBQUksQ0FBRSxLQUFLLEVBQUUsc0JBQXNCLEVBQ3JELEVBQUMsaUJBQWlCLEVBQUU7NEJBQ2xCLEdBQUcsRUFBRSxpQkFBaUIsQ0FBQyxNQUFNOzRCQUM3QixJQUFJLEVBQUUsaUJBQWlCLENBQUMsY0FBYzt5QkFDdkMsRUFBQyxDQUNILENBQUMsT0FBTyxDQUFDO29CQUNWLFFBQVEsQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDLENBQUM7Z0JBQzNCLENBQUU7Z0JBQUEsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztvQkFDZixJQUFJLFNBQVMsQ0FBQztvQkFDZCxJQUFJLFlBQVksQ0FBQztvQkFDakIsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7d0JBQ25CLFNBQVMsR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7d0JBQ3JDLFlBQVksR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7b0JBQzdDLENBQUM7b0JBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ04sU0FBUyxHQUFHLEdBQUcsQ0FBQzt3QkFDaEIsWUFBWSxHQUFHLHVCQUF1QixDQUFDO29CQUN6QyxDQUFDO29CQUNELElBQUksT0FBTyxHQUFHLElBQUksZUFBTSxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQUUsWUFBWSxDQUFDLENBQUM7b0JBQ3hELFFBQVEsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQzFCLENBQUM7WUFDSCxDQUFDO1lBRUQsSUFBSSxRQUFRLEdBQUcsZUFBTSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO1lBQ2pFLFFBQVEsR0FBRyxRQUFRLENBQUMsSUFBSSxFQUFFLENBQUM7WUFDM0IsUUFBUSxHQUFHLFFBQVEsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDbEMsUUFBUSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDOUIsUUFBUSxHQUFHLEdBQUcsR0FBRyxRQUFRLEdBQUcsR0FBRyxDQUFDO1lBQ2hDLFFBQVEsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBRWhDLHFEQUFxRDtZQUVuRCxJQUFJLEdBQUcsR0FBRyxFQUFFLENBQUM7WUFFYixHQUFHLENBQUMsQ0FBQyxJQUFJLEdBQUcsSUFBSSxRQUFRLENBQUMsQ0FBQyxDQUFDO2dCQUV2QixHQUFHLENBQUMsSUFBSSxDQUFDO29CQUNQLFFBQVEsRUFBRSxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUTtvQkFDaEMsV0FBVyxFQUFFLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFO29CQUM3QixJQUFJLEVBQUUsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUk7aUJBQ3pCLENBQUM7WUFFTixDQUFDO1lBRUQsTUFBTSxDQUFDLEdBQUcsQ0FBQztRQUVmLENBQUM7UUFFRCw0Q0FBNEM7UUFDNUMsNENBQTRDO1FBQzVDLDRDQUE0QztRQUM1Qyx5Q0FBeUM7UUFDekMsa0NBQWtDO1FBRWxDLHdCQUF3QixDQUFDLFVBQVUsRUFBRSxTQUFTO1lBQzVDLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDdkIsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQ2YsSUFBSSxpQkFBaUIsR0FBRyxJQUFJLHFCQUFTLEVBQUUsQ0FBQztZQUV4QyxJQUFJLHlCQUF5QixHQUFHLDREQUE0RCxHQUFHLEdBQUcsR0FBRSxVQUFVLEdBQUcsY0FBYyxDQUFFO1lBQ2pJLDJDQUEyQztZQUUzQyxJQUFJLE9BQU8sR0FBRyxVQUFVLHlCQUF5QixFQUFFLFFBQVE7Z0JBQ3pELElBQUksQ0FBQztvQkFDSCxJQUFJLFFBQVEsR0FBRyxXQUFJLENBQUMsSUFBSSxDQUFFLEtBQUssRUFBRSx5QkFBeUIsRUFDeEQsRUFBQyxpQkFBaUIsRUFBRTs0QkFDbEIsR0FBRyxFQUFFLGlCQUFpQixDQUFDLE1BQU07NEJBQzdCLElBQUksRUFBRSxpQkFBaUIsQ0FBQyxjQUFjO3lCQUN2QyxFQUFDLENBQ0gsQ0FBQyxPQUFPLENBQUM7b0JBQ1YsUUFBUSxDQUFDLElBQUksRUFBRSxRQUFRLENBQUMsQ0FBQztnQkFDM0IsQ0FBRTtnQkFBQSxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO29CQUNmLElBQUksU0FBUyxDQUFDO29CQUNkLElBQUksWUFBWSxDQUFDO29CQUNqQixFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQzt3QkFDbkIsU0FBUyxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQzt3QkFDckMsWUFBWSxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQztvQkFDN0MsQ0FBQztvQkFBQyxJQUFJLENBQUMsQ0FBQzt3QkFDTixTQUFTLEdBQUcsR0FBRyxDQUFDO3dCQUNoQixZQUFZLEdBQUcsdUJBQXVCLENBQUM7b0JBQ3pDLENBQUM7b0JBQ0QsSUFBSSxPQUFPLEdBQUcsSUFBSSxlQUFNLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRSxZQUFZLENBQUMsQ0FBQztvQkFDeEQsUUFBUSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDMUIsQ0FBQztZQUNILENBQUM7WUFFRCxJQUFJLFFBQVEsR0FBRyxlQUFNLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDLHlCQUF5QixDQUFDLENBQUM7WUFDcEUsUUFBUSxHQUFHLFFBQVEsQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUMzQixRQUFRLEdBQUcsUUFBUSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNsQyxRQUFRLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUM5QixRQUFRLEdBQUcsR0FBRyxHQUFHLFFBQVEsR0FBRyxHQUFHLENBQUM7WUFDaEMsUUFBUSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUM7WUFFaEMsUUFBUSxHQUFHLFFBQVEsQ0FBQyxNQUFNLENBQUMsVUFBVSxFQUFFO2dCQUNuQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxLQUFLLFNBQVMsQ0FBQyxDQUFDO1lBQ3BDLENBQUMsQ0FBQyxDQUFDO1lBR0QsTUFBTSxDQUFDLFFBQVEsQ0FBQztRQUdwQixDQUFDO0tBRUosQ0FBQyxDQUFDLENBQUMscUJBQXFCO0FBRTNCLENBQUMsQ0FBQywwQkFBMEI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN6STVCLDhEQUE4RDtBQUM5RCxtREFBbUQ7QUFDbkQsd0lBQXdJO0FBQ3hJLHlCQUFxQixlQUFlLENBQUM7QUFDckMsTUFBWSxJQUFJLFdBQU0scUJBQXFCLENBQUM7QUFFNUM7SUFZSTtRQUNFLElBQUksQ0FBQyxhQUFhLEdBQUcsZUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQ2pFLElBQUksQ0FBQyxVQUFVLEdBQUcsZUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQzlELElBQUksQ0FBQyxjQUFjLEdBQUcsZUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ2pGLElBQUksQ0FBQyxNQUFNLEdBQUcsZUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNqRSxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUM7UUFDakMsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztRQUM5QyxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUM7UUFDNUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDO1FBQzFCLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQztRQUN0QyxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7SUFDMUIsQ0FBQztBQUdMLENBQUM7QUExQlksaUJBQVMsWUEwQnJCLEVBQUMsZUFBZTs7Ozs7Ozs7Ozs7O0FDaENqQixnRUFBZ0U7QUFFaEUsNEVBQTRFO0FBQzVFLHlCQUF1QixlQUFlLENBQUM7QUFDdkMsNEJBQTBCLDJCQUEyQixDQUFDO0FBQ3RELHNCQUFnRixtQkFBbUIsQ0FBQztBQUVwRyxlQUFNLENBQUMsT0FBTyxDQUFDLGNBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxvQkFBb0I7QUFDbkQsZ0dBQWdHO0FBQ2hHLGdHQUFnRztBQUNoRyxnR0FBZ0c7QUFFaEcsSUFBSSxpQkFBaUIsR0FBRyxJQUFJLHFCQUFTLEVBQUUsQ0FBQztBQUV4Qyw0Q0FBNEM7QUFFNUMsRUFBRSxDQUFDLENBQUMsZUFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBRSxRQUFRLEVBQUUsT0FBTyxFQUFFLENBQUMsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQzFELEVBQUU7SUFDRiw4Q0FBOEM7SUFDOUMsRUFBRTtJQUNGLElBQUksQ0FBQztRQUNILFFBQVEsQ0FBQyxVQUFVLENBQUM7WUFDbEIsS0FBSyxFQUFFLGlCQUFpQixDQUFDLFVBQVU7WUFDbkMsUUFBUSxFQUFFLGlCQUFpQixDQUFDLGFBQWE7WUFDekMsUUFBUSxFQUFFLE9BQU87U0FDbEIsQ0FBQyxDQUFDO1FBRUgsbUVBQW1FO1FBRW5FLElBQUksT0FBTyxHQUFHLGVBQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEVBQUUsUUFBUSxFQUFFLE9BQU8sRUFBRSxDQUFDLENBQUM7UUFFMUQsZUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRTtZQUMvQixJQUFJLEVBQUU7Z0JBQ0osSUFBSSxFQUFFLE9BQU87Z0JBQ2IsS0FBSyxFQUFFLEVBQUU7YUFDVjtTQUNGLENBQUMsQ0FBQztJQUNMLENBQUU7SUFBQSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ1gsU0FBUztRQUVULE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVSxHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQzlCLENBQUM7QUFDSCxDQUFDLENBQUMsNEJBQTRCO0FBRTlCLHNDQUFzQztBQUN0QyxnR0FBZ0c7QUFDaEcsZ0dBQWdHO0FBQ2hHLGdHQUFnRztBQUNoRyxFQUFFLENBQUMsQ0FBQyxjQUFRLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQzlDLElBQUksQ0FBQztRQUNILEdBQUcsQ0FBQyxDQUFDLElBQUksR0FBRyxJQUFJLGlCQUFpQixDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7WUFDOUMsY0FBUSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUM7Z0JBQ3pCLElBQUksRUFBRSxpQkFBaUIsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDO2dCQUN4QyxXQUFXLEVBQUUsRUFBRTtnQkFDZixTQUFTLEVBQUUsaUJBQWlCLENBQUMsVUFBVTtnQkFDdkMsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFO2FBQ3RCLENBQUMsQ0FBQyxDQUFDLFlBQVk7UUFDbEIsQ0FBQyxDQUFDLGtCQUFrQjtJQUN0QixDQUFFO0lBQUEsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNYLE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVSxHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQzlCLENBQUM7QUFDSCxDQUFDO0FBRUQsZ0hBQWdIO0FBQ2hILGdIQUFnSDtBQUNoSCxnSEFBZ0g7QUFFaEgsMkRBQTJEO0FBQzNELElBQUksZUFBZSxHQUFHLGNBQVEsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRSxDQUFDLENBQUM7QUFDdkUsdUNBQXVDO0FBQ3ZDLElBQUksY0FBYyxHQUFHLGNBQVEsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxDQUFDLENBQUM7QUFDckUsc0NBQXNDO0FBRXRDLEVBQUUsQ0FBQyxDQUFDLGVBQVMsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDL0MsSUFBSSxDQUFDO1FBQ0gsZ0RBQWdEO1FBQ2hELCtDQUErQztRQUMvQyxnREFBZ0Q7UUFDaEQsR0FBRyxDQUFDLENBQUMsSUFBSSxHQUFHLElBQUksaUJBQWlCLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDO1lBQ25ELGVBQVMsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDO2dCQUMxQixJQUFJLEVBQUUsaUJBQWlCLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDO2dCQUNyRCxXQUFXLEVBQUUsRUFBRTtnQkFDZixRQUFRLEVBQUUsZUFBZSxDQUFDLEtBQUssQ0FBQztnQkFDaEMsU0FBUyxFQUFFLGlCQUFpQixDQUFDLFVBQVU7Z0JBQ3ZDLFNBQVMsRUFBRSxJQUFJLElBQUksRUFBRTthQUN0QixDQUFDLENBQUMsQ0FBQyxZQUFZO1lBQ2hCLElBQUksV0FBVyxHQUFHLGVBQVMsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDO2dCQUM3QyxJQUFJLEVBQUUsaUJBQWlCLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDO2FBQ3RELENBQUMsQ0FBQztZQUNILEVBQUUsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDbEUsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksaUJBQWlCLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztvQkFDakUsaUJBQVcsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDO3dCQUM1QixJQUFJLEVBQUUsaUJBQWlCLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQzt3QkFDM0QsV0FBVyxFQUFFLEVBQUU7d0JBQ2YsUUFBUSxFQUFFLGVBQWUsQ0FBQyxLQUFLLENBQUM7d0JBQ2hDLFNBQVMsRUFBRSxXQUFXLENBQUMsS0FBSyxDQUFDO3dCQUM3QixTQUFTLEVBQUUsaUJBQWlCLENBQUMsVUFBVTt3QkFDdkMsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFO3FCQUN0QixDQUFDLENBQUM7Z0JBQ0wsQ0FBQztZQUNILENBQUM7UUFDSCxDQUFDO1FBQ0QsZ0RBQWdEO1FBQ2hELGdEQUFnRDtRQUNoRCxnREFBZ0Q7UUFDaEQsR0FBRyxDQUFDLENBQUMsSUFBSSxHQUFHLElBQUksaUJBQWlCLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQztZQUNsRCxlQUFTLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQztnQkFDMUIsSUFBSSxFQUFFLGlCQUFpQixDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUM7Z0JBQ3BELFdBQVcsRUFBRSxFQUFFO2dCQUNmLFFBQVEsRUFBRSxjQUFjLENBQUMsS0FBSyxDQUFDO2dCQUMvQixTQUFTLEVBQUUsaUJBQWlCLENBQUMsVUFBVTtnQkFDdkMsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFO2FBQ3RCLENBQUMsQ0FBQyxDQUFDLFlBQVk7WUFDaEIsSUFBSSxXQUFXLEdBQUcsZUFBUyxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUM7Z0JBQzdDLElBQUksRUFBRSxpQkFBaUIsQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDO2FBQ3JELENBQUMsQ0FBQztZQUNILEVBQUUsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxVQUFVLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2pFLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLGlCQUFpQixDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO29CQUNoRSxpQkFBVyxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUM7d0JBQzVCLElBQUksRUFBRSxpQkFBaUIsQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQzt3QkFDMUQsV0FBVyxFQUFFLEVBQUU7d0JBQ2YsUUFBUSxFQUFFLGNBQWMsQ0FBQyxLQUFLLENBQUM7d0JBQy9CLFNBQVMsRUFBRSxXQUFXLENBQUMsS0FBSyxDQUFDO3dCQUM3QixTQUFTLEVBQUUsaUJBQWlCLENBQUMsVUFBVTt3QkFDdkMsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFO3FCQUN0QixDQUFDLENBQUM7Z0JBQ0wsQ0FBQztZQUNILENBQUM7UUFDSCxDQUFDO0lBQ0gsQ0FBRTtJQUFBLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDWCxPQUFPLENBQUMsR0FBRyxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUMsQ0FBQztJQUM3QixDQUFDO0FBQ0gsQ0FBQztBQUVELEVBQUUsQ0FBQyxDQUFDLGFBQU8sQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDM0MsSUFBSSxDQUFDO1FBQ0QsR0FBRyxDQUFDLENBQUMsSUFBSSxHQUFHLElBQUksaUJBQWlCLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztZQUN2QyxhQUFPLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQztnQkFDdEIsSUFBSSxFQUFFLGlCQUFpQixDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7Z0JBQ25DLFdBQVcsRUFBRSxFQUFFO2dCQUNmLFNBQVMsRUFBRSxpQkFBaUIsQ0FBQyxVQUFVO2dCQUN2QyxTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUU7YUFDeEIsQ0FBQyxDQUFDO1FBQ1AsQ0FBQztJQUNMLENBQUU7SUFBQSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ1QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFDL0IsQ0FBQztBQUNMLENBQUM7QUFFRCxFQUFFLENBQUMsQ0FBQyxrQkFBWSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNoRCxJQUFJLENBQUM7UUFDRCxHQUFHLENBQUMsQ0FBQyxJQUFJLEdBQUcsSUFBSSxpQkFBaUIsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO1lBQzdDLGtCQUFZLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQztnQkFDM0IsSUFBSSxFQUFFLGlCQUFpQixDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUM7Z0JBQ3pDLFdBQVcsRUFBRSxFQUFFO2dCQUNmLFNBQVMsRUFBRSxpQkFBaUIsQ0FBQyxVQUFVO2dCQUN2QyxTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUU7YUFDeEIsQ0FBQyxDQUFDO1FBQ1AsQ0FBQztJQUNMLENBQUU7SUFBQSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ1QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFDL0IsQ0FBQztBQUNMLENBQUM7QUFFRCxFQUFFLENBQUMsQ0FBQyxZQUFNLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQzFDLElBQUksQ0FBQztRQUNELEdBQUcsQ0FBQyxDQUFDLElBQUksR0FBRyxJQUFJLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7WUFDdEMsWUFBTSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUM7Z0JBQ3JCLElBQUksRUFBRSxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO2dCQUNsQyxXQUFXLEVBQUUsRUFBRTtnQkFDZixTQUFTLEVBQUUsaUJBQWlCLENBQUMsVUFBVTtnQkFDdkMsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFO2FBQ3hCLENBQUMsQ0FBQztRQUNQLENBQUM7SUFDTCxDQUFFO0lBQUEsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNULE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQy9CLENBQUM7QUFDTCxDQUFDO0FBRUQscUdBQXFHO0FBQ3JHLDBEQUEwRDtBQUUxRCwrQ0FBK0M7QUFDL0MsK0NBQStDO0FBQy9DLCtDQUErQzs7Ozs7Ozs7Ozs7O0FDeEwvQywwQ0FBMEM7Ozs7Ozs7Ozs7OztBQ0ExQyx5RUFBeUU7QUFDekUsb0hBQW9IO0FBQ3BILHlCQUF1QixlQUFlLENBQUM7QUFFdkMsOEJBQWdDLGFBQWEsQ0FBQztBQUU5QyxxR0FBcUc7QUFDeEYsZ0JBQVEsR0FBRyxJQUFJLDZCQUFlLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ3BELGlCQUFTLEdBQUcsSUFBSSw2QkFBZSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUN0RCxtQkFBVyxHQUFHLElBQUksNkJBQWUsQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLENBQUM7QUFDMUQsZ0JBQVEsR0FBRyxJQUFJLDZCQUFlLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ3BELGVBQU8sR0FBRyxJQUFJLDZCQUFlLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ2xELG9CQUFZLEdBQUcsSUFBSSw2QkFBZSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsQ0FBQztBQUM1RCxjQUFNLEdBQUcsSUFBSSw2QkFBZSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNoRCxrQkFBVSxHQUFHLElBQUksNkJBQWUsQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLENBQUM7QUFFeEQsaUJBQVMsR0FBRyxJQUFJLDZCQUFlLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBSW5FLEVBQUUsQ0FBQyxDQUFDLGVBQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0FBR3RCLENBQUMsQ0FBQywyQkFBMkI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdkI3QixpQkFBYyxlQUFlLENBQUMiLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbIi8vIGRvY3MgZm9yIG1ldGVvciBkZWZhdWx0IG1ldGhvZHMgOiBodHRwOi8vZG9jcy5tZXRlb3IuY29tL2FwaS9wYXNzd29yZHMuaHRtbFxuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBBY2NvdW50cyB9IGZyb20gJ21ldGVvci9hY2NvdW50cy1iYXNlJ1xuaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IHsgTWV0ZW9yT2JzZXJ2YWJsZSB9IGZyb20gJ21ldGVvci1yeGpzJztcbmltcG9ydCB7IGNoZWNrIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJztcbmltcG9ydCB7IENoZWNrZGJhY2Nlc3MgfSBmcm9tICcvc2VydmVyL2RiYXBpL3Rvb2xzL2NoZWNrZGJhY2Nlc3MudHMnO1xuaW1wb3J0IHsgUHJvZmlsZURCIH0gZnJvbSBcIi9pbXBvcnRzL2FwaS9pbmRleFwiO1xuXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG5cbiAgTWV0ZW9yLm1ldGhvZHMoe1xuXG4gICAgJ2lzVXNlckV4aXN0SW5EQicoZW1haWwpIHtcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvLyB0aGUgcmVzcG9uc2Ugb2JqZWN0IGZvciBjbGllbnQgd2l0aCBmZWVkYmFjayBhbmQgZGF0YVxuICAgICAgLy8gY29kZXMgOlxuICAgICAgLy8gOTk5ID0gdW5rbm93biBlbWFpbCBhZGRyZXNzLlxuICAgICAgLy8gNDA0ID0gRGF0YmFzZSBsZXZlbCBwcm9ibGVtIG9yIFVua25vd24gZXJyb3Igb3IgZXhjZXB0aW9uc1xuICAgICAgLy8gMTAwID0gdXNlciBhbHJlYWR5IGV4aXN0cztcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgdmFyIHJlc3BvbnNlOiBhbnkgPSB7XG4gICAgICAgIGZlZWRiYWNrOiBcIlVua25vd24gZXJyb3Igd2hpbGUgcHJvY2Vzc2luZyByZXF1ZXN0LiBQbGVhc2UgdHJ5IGFnYWluLlwiLFxuICAgICAgICBjb2RlOiA0MDRcbiAgICAgIH1cbiAgICAgIHZhciB1c2VyID0gTWV0ZW9yLnVzZXJzLmZpbmRPbmUoeyBcImVtYWlscy5hZGRyZXNzXCI6IGVtYWlsIH0pO1xuXG4gICAgICBpZiAodXNlciAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKFwidXNlciBmb3VuZFwiKTtcbiAgICAgICAgLy91c2VyIGZvdW5kXG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSAxMDA7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJUaGlzIGVtYWlsIGFscmVhZHkgcmVnaXN0ZXJlZCBpbiB0aGUgc3lzdGVtXCI7XG4gICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgIH1cbiAgICAgIGVsc2UgaWYgKHVzZXIgPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKFwidXNlciBub3QgZm91bmRcIik7XG4gICAgICAgIC8vdXNlciBub3QgZm91bmRcbiAgICAgICAgcmVzcG9uc2UuY29kZSA9IDk5OTtcbiAgICAgICAgcmVzcG9uc2UuZmVlZGJhY2sgPSBcIlRoaXMgZW1haWwgZG9lc24ndCBleGlzdCBpbiBEQlwiO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9XG4gICAgICBlbHNlIHtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgfVxuICAgIH0sXG5cbiAgICAnZ2V0RXhpc3RpbmdVc2VyRGF0YScoZW1haWwpIHtcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvLyB0aGUgcmVzcG9uc2Ugb2JqZWN0IGZvciBjbGllbnQgd2l0aCBmZWVkYmFjayBhbmQgZGF0YVxuICAgICAgLy8gY29kZXMgOlxuICAgICAgLy8gOTk5ID0gdW5rbm93biBlbWFpbCBhZGRyZXNzLlxuICAgICAgLy8gNDA0ID0gRGF0YmFzZSBsZXZlbCBwcm9ibGVtIG9yIFVua25vd24gZXJyb3Igb3IgZXhjZXB0aW9uc1xuICAgICAgLy8gMjAwID0gdXNlciBhbHJlYWR5IGV4aXN0cztcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgdmFyIHJlc3BvbnNlOiBhbnkgPSB7XG4gICAgICAgIGZlZWRiYWNrOiBcIlVua25vd24gZXJyb3Igd2hpbGUgcHJvY2Vzc2luZyByZXF1ZXN0LiBQbGVhc2UgdHJ5IGFnYWluLlwiLFxuICAgICAgICBjb2RlOiA0MDQsXG4gICAgICAgIHVzZXJEYXRhOiB1bmRlZmluZWRcbiAgICAgIH1cbiAgICAgIHZhciB1c2VyID0gTWV0ZW9yLnVzZXJzLmZpbmRPbmUoeyBcImVtYWlscy5hZGRyZXNzXCI6IGVtYWlsIH0pO1xuXG4gICAgICBpZiAodXNlciAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKFwidXNlciBmb3VuZFwiKTtcbiAgICAgICAgLy91c2VyIGZvdW5kIG5vdyB3ZSBnZXQgdXNlciBkYXRhIGZyb20gcHJvZmlsZURCXG4gICAgICAgIGxldCB1c2VyRGF0YSA9IFByb2ZpbGVEQi5maW5kT25lKHtcInVzZXJBY2NvdW50SURcIjogdXNlci5faWR9KTtcblxuICAgICAgICByZXNwb25zZS51c2VyRGF0YSA9IHtcbiAgICAgICAgICBmaXJzdE5hbWU6IHVzZXJEYXRhLmZpcnN0TmFtZSxcbiAgICAgICAgICBsYXN0TmFtZTogdXNlckRhdGEubGFzdE5hbWUsXG4gICAgICAgICAgb2NjdXBhdGlvbjogdXNlckRhdGEub2NjdXBhdGlvbixcbiAgICAgICAgICBjYW1wdXM6IHVzZXJEYXRhLmNhbXB1cyxcbiAgICAgICAgICByb2xlOiB1c2VyW1wicm9sZVwiXSxcbiAgICAgICAgICBvYmZJRDogdXNlcltcIm9iZklEXCJdLFxuICAgICAgICAgIGxhc3RMb2dpbjogdXNlcltcInByb2ZpbGVcIl1bXCJsYXN0TG9naW5cIl0sXG4gICAgICAgICAgdXNlckFjY291bnRJRDogdXNlci5faWQsXG4gICAgICAgICAgcHJvZmlsZUlEOiB1c2VyRGF0YS5faWRcbiAgICAgICAgfVxuICAgICAgICByZXNwb25zZS5jb2RlID0gMjAwO1xuICAgICAgICByZXNwb25zZS5mZWVkYmFjayA9IFwiVXNlciBleGlzdCBpbiBCYWRnZWxvclwiO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9XG4gICAgICBlbHNlIGlmICh1c2VyID09IHVuZGVmaW5lZCkge1xuICAgICAgICAvLyBjb25zb2xlLmxvZyhcInVzZXIgbm90IGZvdW5kXCIpO1xuICAgICAgICAvL3VzZXIgbm90IGZvdW5kXG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSA5OTk7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJUaGlzIGVtYWlsIGRvZXNuJ3QgZXhpc3QgaW4gREJcIjtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgfVxuICAgICAgZWxzZSB7XG4gICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgIH1cbiAgICB9LFxuXG4gICAgJ2lzVXNlclR5cGVBZG1pbicoKSB7XG4gICAgICAvLyB0aGlzIG1ldGhvZCBpcyBuZWVkZWQgZm9yIGNsaWVudCB0byBrbm93IGlmIGEgdXNlciB0eXBlIGlzIGFkbWluIG9yIG5vdFxuICAgICAgLy8gdXNlciByb2xlIHdpbGwgbmV2ZXIgYmUgcHVibGlzaGVkIHRvICBjbGllbnRcbiAgICAgIC8vIGNvZGVzIDpcbiAgICAgIC8vIDEwMCA9IHVzZXIgaXMgYW4gYWRtaW5cbiAgICAgIC8vIDk5OSA9IG5vdCBhZG1pblxuICAgICAgaWYgKCF0aGlzLnVzZXJJZCkge1xuICAgICAgICByZXR1cm4gOTk5O1xuICAgICAgfVxuICAgICAgdmFyIGRiQWNjZXNzQ2hlY2tlciA9IG5ldyBDaGVja2RiYWNjZXNzKCk7XG4gICAgICBpZiAoZGJBY2Nlc3NDaGVja2VyLmlzUm9sZUFkbWluKHRoaXMudXNlcklkKSA9PT0gdHJ1ZSkge1xuICAgICAgICByZXR1cm4gMTAwO1xuICAgICAgfVxuICAgICAgZWxzZSB7XG4gICAgICAgIHJldHVybiA5OTk7XG4gICAgICB9XG4gICAgfSwgLy8gLS0tIGVuZCBvZiBpc1VzZXJUeXBlQWRtaW4gLS0tXG5cbiAgICAnaXNVc2VyVHlwZUFwcGxpY2FudCcoKSB7XG4gICAgICAvLyB0aGlzIG1ldGhvZCBpcyBuZWVkZWQgZm9yIGNsaWVudCB0byBrbm93IGlmIGEgdXNlciB0eXBlIGlzIGFwcGxpY2FudCBvciBub3RcbiAgICAgIC8vIHVzZXIgcm9sZSB3aWxsIG5ldmVyIGJlIHB1Ymxpc2hlZCB0byAgY2xpZW50XG4gICAgICAvLyBjb2RlcyA6XG4gICAgICAvLyAxMDAgPSB1c2VyIGlzIGFuIGFwcGxpY2FudFxuICAgICAgLy8gOTk5ID0gbm90IGFwcGxpY2FudFxuICAgICAgaWYgKCF0aGlzLnVzZXJJZCkge1xuICAgICAgICByZXR1cm4gOTk5O1xuICAgICAgfVxuICAgICAgdmFyIGRiQWNjZXNzQ2hlY2tlciA9IG5ldyBDaGVja2RiYWNjZXNzKCk7XG4gICAgICBpZiAoZGJBY2Nlc3NDaGVja2VyLmlzUm9sZUFwcGxpY2FudCh0aGlzLnVzZXJJZCkgPT09IHRydWUpIHtcbiAgICAgICAgcmV0dXJuIDEwMDtcbiAgICAgIH1cbiAgICAgIGVsc2Uge1xuICAgICAgICByZXR1cm4gOTk5O1xuICAgICAgfVxuICAgIH0sIC8vIC0tLSBlbmQgb2YgaXNVc2VyVHlwZUFkbWluIC0tLVxuXG5cbiAgICAnY3JlYXRlTXlQcm9maWxlJyhkYXRhKSB7XG4gICAgICAvLyBhZGQgbmV3IHVzZXIgcHJvZmlsZSB2aWEgc2lnbnVwIGZvcm0gKCB1c2VyOiBhcHBsaWNhbnQgKVxuXG4gICAgICAvLyBUT0RPIDogdGhpcyBmdW5jdGlvbiBpcyBjYWxsZWQgd2hlbiB0aGUgdXNlciBjcmVhdGUgbmV3IGFjY291bnQgYW5kIGluc3RhbmN0bHkgbG9ncyBpbiBmb3IgdGhlIGZpcnN0IHRpbWUuXG4gICAgICAvLyB3ZSBuZWVkIHRvIGNyZWF0ZSBhbm90aGVyIG1ldGhvZCAtIHdoZW4gYWRtaW4gY3JlYXRlcyBhIHVzZXIgZnJvbSBhZG1pbiBwYW5lbFxuICAgICAgLy8gKHdoZW4gbmV3IHVzZXIgaXMgbm90IHNpbmdlZCBpbiAsIHNvIG5vIHZhbGlkIHVzZXJJRClcblxuICAgICAgaWYgKCF0aGlzLnVzZXJJZCkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH1cblxuICAgICAgLy9maXJzdCBmaW5kaW5nIHRoZSBwcm9maWxlIG9mIHRoaXMgcmVxdWVzdGluZyB1c2VyLlxuICAgICAgdmFyIG15UHJvZmlsZURCID0gUHJvZmlsZURCLmZpbmRPbmUoeyBcInVzZXJBY2NvdW50SURcIjogdGhpcy51c2VySWQgfSk7XG4gICAgICAvL2NvbnNvbGUubG9nKG15UHJvZmlsZURCKTtcblxuICAgICAgaWYgKG15UHJvZmlsZURCID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgLy90aGUgUHJvZmlsZURCIGZvciB0aGlzIHVzZXIgaGFzIG5vdCBiZWVuIGNyZWF0ZWQgeWV0LiBzbyBjcmVhdGluZyBhIG5ldyBvbmVcbiAgICAgICAgdmFyIHByb2ZpbGVJRCA9IFByb2ZpbGVEQi5jb2xsZWN0aW9uLmluc2VydCh7XG4gICAgICAgICAgdXNlckFjY291bnRJRDogdGhpcy51c2VySWRcbiAgICAgICAgfSk7XG4gICAgICAgIC8vIG5vdyB0aGUgZGIgaXMgY3JlYXRlZCwgc28gdXBkYXRpbmcgdGhlIGRhdGEgb2YgdGhpcyBjb2xsZWN0aW9uXG4gICAgICAgIHVwZGF0ZVByb2ZpbGUoZGF0YSwgcHJvZmlsZUlEKTtcbiAgICAgICAgcmV0dXJuIHRydWU7XG5cbiAgICAgIH1cblxuICAgICAgZWxzZSB7XG4gICAgICAgIC8vIHByb2ZpbGVEQiBleGlzdCBmb3IgdGhpcyB1c2VyIHNvIG1ha2luZyB1cGRhdGVzXG4gICAgICAgIHVwZGF0ZVByb2ZpbGUoZGF0YSwgbXlQcm9maWxlREIuX2lkKTtcbiAgICAgIH1cbiAgICAgIC8vIHRoZSBmdW5jdGlvbiB0byB1cGRhdGUgdGhlIFByb2ZpbGVEQlxuICAgICAgZnVuY3Rpb24gdXBkYXRlUHJvZmlsZShkYXRhLCBwcm9maWxlSUQpIHtcblxuICAgICAgICBQcm9maWxlREIuY29sbGVjdGlvbi51cGRhdGUoXG5cbiAgICAgICAgICBwcm9maWxlSUQsXG4gICAgICAgICAge1xuICAgICAgICAgICAgJHNldDoge1xuICAgICAgICAgICAgICBmaXJzdE5hbWU6IGRhdGEuZmlyc3ROYW1lLFxuICAgICAgICAgICAgICBsYXN0TmFtZTogZGF0YS5sYXN0TmFtZSxcbiAgICAgICAgICAgICAgY2FtcHVzOiBkYXRhLmNhbXB1cyxcbiAgICAgICAgICAgICAgb2NjdXBhdGlvbjogZGF0YS5vY2N1cGF0aW9uLFxuICAgICAgICAgICAgICBpbWFnZVVSTDogZGF0YS5pbWFnZVVSTFxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cblxuICAgICAgICApO1xuICAgICAgfSAvLyBlbmQgZnVuY3Rpb24gdXBkYXRlUHJvZmlsZSBkZWZcblxuICAgIH0sXG5cblxuXG4gICAgJ2FkZE5ld1VzZXJCeUFkbWluJyhyZWdpc3RlckRhdGEsIHByb2ZpbGVEYXRhKSB7XG5cblxuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgIC8vIHRoZSByZXNwb25zZSBvYmplY3QgZm9yIGNsaWVudCB3aXRoIGZlZWRiYWNrIGFuZCBkYXRhXG4gICAgICAvLyBjb2RlcyA6XG4gICAgICAvLyA5OTkgPSBhY2Nlc3MgZGVuaWVkLlxuICAgICAgLy8gNDA0ID0gRGF0YmFzZSBsZXZlbCBwcm9ibGVtIG9yIFVua25vd24gZXJyb3Igb3IgZXhjZXB0aW9uc1xuICAgICAgLy8gMjAwID0gc3VjY2VzcztcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4gICAgICB2YXIgcmVzcG9uc2U6IGFueSA9IHtcbiAgICAgICAgZmVlZGJhY2s6IFwiVW5rbm93biBlcnJvciB3aGlsZSBwcm9jZXNzaW5nLiBQbGVhc2UgdHJ5IGFnYWluLlwiLFxuICAgICAgICBjb2RlOiA0MDRcbiAgICAgIH1cblxuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgLy8gYWNjZXNzIHJ1bGVzIDpcbiAgICAgIC8vIGFkbWluIGNhbiBhZGQgYW55IG51bWJlciBvZiB1c2VyXG4gICAgICAvLyBvdGhlciB0eXBlIG9mIHVzZXJzIHdpbGwgaGF2ZSBubyBhY2Nlc3MgdG8gdGhpcyBmZWF0dXJlXG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgLy8gc3RlcCAxOiByZXF1ZXN0IHZhbGlkYXRpb24sIGJhc2ljIGZpbHRlcmluZ1xuICAgICAgaWYgKCF0aGlzLnVzZXJJZCkge1xuICAgICAgICByZXNwb25zZS5jb2RlID0gOTk5O1xuICAgICAgICByZXNwb25zZS5mZWVkYmFjayA9IFwiQWNjZXNzIGRlbmllZFwiO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9XG4gICAgICBjaGVjayhyZWdpc3RlckRhdGEsIE9iamVjdCk7XG5cbiAgICAgIC8vIHN0ZXAgMiA6IGNoZWNraW5nIERCIGFjY2VzcyByaWdodHNcblxuICAgICAgLy8gYSBmbGFnIHRvIG1ha2Ugc3VyZSB0aGlzIHJlcXVlc3RpbmcgdXNlciBoYXMgdGhlIHJpZ2h0IGFjY2VzcyB0byBtb2RpZnkgdGhpcyBkYXRhXG4gICAgICB2YXIgdXNlckhhc0FjY2Vzc1JpZ2h0cyA9IGZhbHNlO1xuXG4gICAgICB2YXIgdXNlcklzQWRtaW4gPSBmYWxzZTtcblxuICAgICAgdmFyIGRiQWNjZXNzQ2hlY2tlciA9IG5ldyBDaGVja2RiYWNjZXNzKCk7XG5cbiAgICAgIHVzZXJJc0FkbWluID0gZGJBY2Nlc3NDaGVja2VyLmlzUm9sZUFkbWluKHRoaXMudXNlcklkKTsgLy9yZXR1cm5zIHRydWUgaWYgYWRtaW5cbiAgICAgIHVzZXJIYXNBY2Nlc3NSaWdodHMgPSB1c2VySXNBZG1pbjtcblxuXG5cbiAgICAgIGlmICh1c2VySGFzQWNjZXNzUmlnaHRzID09PSB0cnVlKSB7XG4gICAgICAgIHRyeSB7XG5cbiAgICAgICAgICB2YXIgdXNlcklkID0gQWNjb3VudHMuY3JlYXRlVXNlcih7XG4gICAgICAgICAgICBlbWFpbDogcmVnaXN0ZXJEYXRhLmVtYWlsLFxuICAgICAgICAgICAgcGFzc3dvcmQ6IHJlZ2lzdGVyRGF0YS5wYXNzd29yZCxcbiAgICAgICAgICAgIHByb2ZpbGU6IHtcbiAgICAgICAgICAgICAgbGFzdExvZ2luOiAnTmV2ZXInXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgLy8gbm93IHNldHRpbmcgdXAgdXNlciByb2xlXG4gICAgICAgICAgc2V0VXNlclJvbGUocmVnaXN0ZXJEYXRhLmVtYWlsLCByZWdpc3RlckRhdGEucm9sZSk7XG4gICAgICAgICAgLy8gbmV4dCBjcmVhdGUgYSBwcm9maWxlIGZvciB0aGUgbmV3IHVzZXJcbiAgICAgICAgICB2YXIgcHJvZmlsZUlEID0gUHJvZmlsZURCLmNvbGxlY3Rpb24uaW5zZXJ0KHtcbiAgICAgICAgICAgIHVzZXJBY2NvdW50SUQ6IHVzZXJJZCxcbiAgICAgICAgICAgIGZpcnN0TmFtZTogcHJvZmlsZURhdGEuZmlyc3ROYW1lLFxuICAgICAgICAgICAgbGFzdE5hbWU6IHByb2ZpbGVEYXRhLmxhc3ROYW1lLFxuICAgICAgICAgICAgY2FtcHVzOiBwcm9maWxlRGF0YS5jYW1wdXMsXG4gICAgICAgICAgICBvY2N1cGF0aW9uOiBwcm9maWxlRGF0YS5vY2N1cGF0aW9uLFxuICAgICAgICAgICAgaW1hZ2VVUkw6IHByb2ZpbGVEYXRhLmltYWdlVVJMXG4gICAgICAgICAgfSk7XG5cbiAgICAgICAgICByZXNwb25zZS5jb2RlID0gMjAwO1xuICAgICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJuZXcgYWNjb3VudCBjcmVhdGVkXCI7XG4gICAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKSB7XG4gICAgICAgICAgcmVzcG9uc2UuY29kZSA9IDk5OTtcbiAgICAgICAgICByZXNwb25zZS5mZWVkYmFjayA9IFwiRXJyb3I6IFwiICsgZTtcbiAgICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICAgIH1cblxuICAgICAgfSAvLyBlbmQgaWYgaWYodXNlckhhc0FjY2Vzc1JpZ2h0cyA9PT0gdHJ1ZSlcbiAgICAgIGVsc2Uge1xuICAgICAgICAvLyBubyBBY2Nlc3MgcmlnaHRcbiAgICAgICAgcmVzcG9uc2UuY29kZSA9IDk5OTtcbiAgICAgICAgcmVzcG9uc2UuZmVlZGJhY2sgPSBcIkFjY2VzcyBkZW5pZWRcIjtcbiAgICAgIH1cblxuXG4gICAgICBmdW5jdGlvbiBzZXRVc2VyUm9sZShlbWFpbCwgcm9sZSkge1xuICAgICAgICB2YXIgdXNlckRCID0gTWV0ZW9yLnVzZXJzLmZpbmRPbmUoeyBcImVtYWlscy5hZGRyZXNzXCI6IGVtYWlsIH0pO1xuXG4gICAgICAgIE1ldGVvci51c2Vycy51cGRhdGUoXG4gICAgICAgICAgdXNlckRCLl9pZCxcbiAgICAgICAgICB7XG4gICAgICAgICAgICAkc2V0OiB7XG4gICAgICAgICAgICAgIFwicm9sZVwiOiByb2xlLFxuICAgICAgICAgICAgICBcIm9iZklEXCI6IFwiXCJcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIClcbiAgICAgIH1cblxuXG4gICAgICByZXR1cm4gcmVzcG9uc2U7XG5cblxuICAgIH0sIC8vICdhZGROZXdVc2VyQnlBZG1pbicoZGF0YSkgZW5kcyBoZXJlXG5cbiAgICAnZGVsZXRlVXNlckJ5QWRtaW4nKHByb2ZpbGUpIHtcblxuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgIC8vIHRoZSByZXNwb25zZSBvYmplY3QgZm9yIGNsaWVudCB3aXRoIGZlZWRiYWNrIGFuZCBkYXRhXG4gICAgICAvLyBjb2RlcyA6XG4gICAgICAvLyA5OTkgPSBhY2Nlc3MgZGVuaWVkLlxuICAgICAgLy8gNDA0ID0gRGF0YmFzZSBsZXZlbCBwcm9ibGVtIG9yIFVua25vd24gZXJyb3Igb3IgZXhjZXB0aW9uc1xuICAgICAgLy8gMjAwID0gc3VjY2VzcztcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4gICAgICB2YXIgcmVzcG9uc2U6IGFueSA9IHtcbiAgICAgICAgZmVlZGJhY2s6IFwiVW5rbm93biBlcnJvciB3aGlsZSBwcm9jZXNzaW5nLiBQbGVhc2UgdHJ5IGFnYWluLlwiLFxuICAgICAgICBjb2RlOiA0MDRcbiAgICAgIH1cblxuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgLy8gYWNjZXNzIHJ1bGVzIDpcbiAgICAgIC8vIGFkbWluIGNhbiBhZGQgYW55IG51bWJlciBvZiB1c2VyXG4gICAgICAvLyBvdGhlciB0eXBlIG9mIHVzZXJzIHdpbGwgaGF2ZSBubyBhY2Nlc3MgdG8gdGhpcyBmZWF0dXJlXG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgLy8gc3RlcCAxOiByZXF1ZXN0IHZhbGlkYXRpb24sIGJhc2ljIGZpbHRlcmluZ1xuICAgICAgaWYgKCF0aGlzLnVzZXJJZCkge1xuICAgICAgICByZXNwb25zZS5jb2RlID0gOTk5O1xuICAgICAgICByZXNwb25zZS5mZWVkYmFjayA9IFwiQWNjZXNzIGRlbmllZFwiO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9XG5cbiAgICAgIGNoZWNrKHByb2ZpbGUsIE9iamVjdCk7XG5cbiAgICAgIC8vIHN0ZXAgMiA6IGNoZWNraW5nIERCIGFjY2VzcyByaWdodHNcblxuICAgICAgLy8gYSBmbGFnIHRvIG1ha2Ugc3VyZSB0aGlzIHJlcXVlc3RpbmcgdXNlciBoYXMgdGhlIHJpZ2h0IGFjY2VzcyB0byBtb2RpZnkgdGhpcyBkYXRhXG4gICAgICB2YXIgdXNlckhhc0FjY2Vzc1JpZ2h0cyA9IGZhbHNlO1xuXG4gICAgICB2YXIgdXNlcklzQWRtaW4gPSBmYWxzZTtcblxuICAgICAgdmFyIGRiQWNjZXNzQ2hlY2tlciA9IG5ldyBDaGVja2RiYWNjZXNzKCk7XG5cbiAgICAgIHVzZXJJc0FkbWluID0gZGJBY2Nlc3NDaGVja2VyLmlzUm9sZUFkbWluKHRoaXMudXNlcklkKTsgLy9yZXR1cm5zIHRydWUgaWYgYWRtaW5cbiAgICAgIHVzZXJIYXNBY2Nlc3NSaWdodHMgPSB1c2VySXNBZG1pbjtcblxuXG5cbiAgICAgIGlmICh1c2VySGFzQWNjZXNzUmlnaHRzID09PSB0cnVlKSB7XG4gICAgICAgIHRyeSB7XG5cbiAgICAgICAgICBNZXRlb3IudXNlcnMucmVtb3ZlKHByb2ZpbGUudXNlckFjY291bnRJRCk7XG5cbiAgICAgICAgICBQcm9maWxlREIucmVtb3ZlKHByb2ZpbGUuX2lkKTtcblxuICAgICAgICAgIHJlc3BvbnNlLmNvZGUgPSAyMDA7XG4gICAgICAgICAgcmVzcG9uc2UuZmVlZGJhY2sgPSBcIlVzZXIgRGVsZXRlZFwiO1xuICAgICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSkge1xuICAgICAgICAgIHJlc3BvbnNlLmNvZGUgPSA5OTk7XG4gICAgICAgICAgcmVzcG9uc2UuZmVlZGJhY2sgPSBcIkVycm9yOiBcIiArIGU7XG4gICAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBlbHNlIHtcbiAgICAgICAgLy8gbm8gQWNjZXNzIHJpZ2h0XG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSA5OTk7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJBY2Nlc3MgZGVuaWVkXCI7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiByZXNwb25zZTtcblxuICAgIH0sXG5cblxuXG4gICAgJ3NldFVzZXJSb2xlJyhlbWFpbCwgcm9sZSkge1xuICAgICAgdmFyIHJlc3BvbnNlOiBhbnkgPSB7XG4gICAgICAgIGZlZWRiYWNrOiBcIlVua25vd24gZXJyb3Igd2hpbGUgcHJvY2Vzc2luZyByZXNldC4gUGxlYXNlIHRyeSBhZ2Fpbi5cIixcbiAgICAgICAgY29kZTogNDA0XG4gICAgICB9XG4gICAgICB2YXIgdXNlckRCID0gTWV0ZW9yLnVzZXJzLmZpbmRPbmUoeyBcImVtYWlscy5hZGRyZXNzXCI6IGVtYWlsIH0pO1xuXG4gICAgICBpZiAodXNlckRCICE9IHVuZGVmaW5lZCkge1xuICAgICAgICBNZXRlb3IudXNlcnMudXBkYXRlKFxuICAgICAgICAgIHVzZXJEQi5faWQsXG4gICAgICAgICAge1xuICAgICAgICAgICAgJHNldDoge1xuICAgICAgICAgICAgICBcInJvbGVcIjogcm9sZSxcbiAgICAgICAgICAgICAgXCJvYmZJRFwiOiBcIlwiXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICApXG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gcm9sZSArIFwiIHJvbGUgYXNzaWduZWRcIjtcbiAgICAgICAgcmVzcG9uc2UuY29kZSA9IDIwMDtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgfVxuXG4gICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgfSxcblxuICAgICd1cGRhdGVMYXN0TG9naW5TdGF0dXMnKCkge1xuXG4gICAgICB2YXIgcmVzcG9uc2U6IGFueSA9IHtcbiAgICAgICAgZmVlZGJhY2s6IFwiVW5rbm93biBlcnJvciB3aGlsZSBwcm9jZXNzaW5nLiBQbGVhc2UgdHJ5IGFnYWluLlwiLFxuICAgICAgICBjb2RlOiA0MDRcbiAgICAgIH1cblxuICAgICAgdHJ5IHtcbiAgICAgICAgTWV0ZW9yLnVzZXJzLnVwZGF0ZShcbiAgICAgICAgICB7X2lkOiB0aGlzLnVzZXJJZH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgJHNldDpcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgXCJwcm9maWxlLmxhc3RMb2dpblwiOiBuZXcgRGF0ZSgpXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICApO1xuICAgICAgICByZXNwb25zZS5jb2RlID0gMjAwO1xuICAgICAgICByZXNwb25zZS5mZWVkYmFjayA9IFwibGFzdCBsb2dpbiB0aW1lIHVwZGF0ZWRcIjtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuXG4gICAgICB9XG4gICAgICBjYXRjaCAoZSkge1xuICAgICAgICByZXNwb25zZS5jb2RlID0gOTk5O1xuICAgICAgICByZXNwb25zZS5mZWVkYmFjayA9IFwiRXJyb3I6IFwiICsgZTtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgfVxuICAgICAgLy8gY29uc29sZS5sb2coXCJ1c2VyIHN0YXR1cyB1cGRhdGVkXCIpO1xuICAgIH0sXG5cbiAgICAnaW5zZXJ0VXNlck9iZklEJyAoY3JlYXRvckVtYWlsLCBjcmVhdG9yT2JmSUQgKSB7XG4gICAgICBjb25zb2xlLmxvZyhjcmVhdG9yT2JmSUQpO1xuICAgICAgdmFyIHJlc3BvbnNlOiBhbnkgPSB7XG4gICAgICAgIGZlZWRiYWNrOiBcIlVua25vd24gZXJyb3Igd2hpbGUgcHJvY2Vzc2luZyByZXNldC4gUGxlYXNlIHRyeSBhZ2Fpbi5cIixcbiAgICAgICAgY29kZTogNDA0XG4gICAgICB9XG4gICAgICB2YXIgdXNlckRCID0gTWV0ZW9yLnVzZXJzLmZpbmRPbmUoeyBcImVtYWlscy5hZGRyZXNzXCI6IGNyZWF0b3JFbWFpbCB9KTtcblxuICAgICAgaWYgKHVzZXJEQiAhPSB1bmRlZmluZWQpIHtcbiAgICAgICAgTWV0ZW9yLnVzZXJzLnVwZGF0ZShcbiAgICAgICAgICB1c2VyREIuX2lkLFxuICAgICAgICAgIHtcbiAgICAgICAgICAgICRzZXQ6IHtcbiAgICAgICAgICAgICAgXCJvYmZJRFwiOiBjcmVhdG9yT2JmSURcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIClcbiAgICAgICAgcmVzcG9uc2UuZmVlZGJhY2sgPSBcIkNyZWF0b3IgZGV0YWlscyB1cGRhdGVkLCB5b3UgY2FuIGltcG9ydCBiYWRnZSBub3cuXCI7XG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSAyMDA7XG4gICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJQbGVhc2UgYWRkIHRoaXMgdXNlciBpbnRvIGJhZGdlbG9yIGZpcnN0LlwiO1xuICAgICAgICByZXNwb25zZS5jb2RlID0gOTk5O1xuICAgICAgfVxuXG4gICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgfVxuXG5cblxuXG5cblxuICB9KTsgLy8gRU5EIG9mIG1ldGVvciBtZXRob2RzXG5cbn0gLy8gRU5EIG9mIE1ldGVvci5pc1NlcnZlclxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBBY2NvdW50cyB9IGZyb20gJ21ldGVvci9hY2NvdW50cy1iYXNlJ1xuaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IHsgTWV0ZW9yT2JzZXJ2YWJsZSB9IGZyb20gJ21ldGVvci1yeGpzJztcbmltcG9ydCB7IGNoZWNrIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJztcbmltcG9ydCB7IENoZWNrZGJhY2Nlc3MgfSBmcm9tICcvc2VydmVyL2RiYXBpL3Rvb2xzL2NoZWNrZGJhY2Nlc3MudHMnO1xuaW1wb3J0IHsgTWV0YWRhdGFEQiB9IGZyb20gXCIvaW1wb3J0cy9hcGkvaW5kZXhcIjtcblxuXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG5cbiAgTWV0ZW9yLm1ldGhvZHMoe1xuICAgICdpbnNlcnRNZXRhZGF0YVRvTG9jYWxEQicoZGF0YSkge1xuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgIC8vIHRoZSByZXNwb25zZSBvYmplY3QgZm9yIGNsaWVudCB3aXRoIGZlZWRiYWNrIGFuZCBkYXRhXG4gICAgICAvLyBjb2RlcyA6XG4gICAgICAvLyA5OTkgPSBhY2Nlc3MgZGVuaWVkLlxuICAgICAgLy8gNDA0ID0gRGF0YmFzZSBsZXZlbCBwcm9ibGVtIG9yIFVua25vd24gZXJyb3Igb3IgZXhjZXB0aW9uc1xuICAgICAgLy8gMjAwID0gc3VjY2VzcztcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4gICAgICB2YXIgcmVzcG9uc2U6IGFueSA9IHtcbiAgICAgICAgZmVlZGJhY2s6IFwiVW5rbm93biBlcnJvciB3aGlsZSBwcm9jZXNzaW5nLiBQbGVhc2UgdHJ5IGFnYWluLlwiLFxuICAgICAgICBjb2RlOiA0MDRcbiAgICAgIH1cblxuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgLy8gYWNjZXNzIHJ1bGVzIDpcbiAgICAgIC8vIGFkbWluIGFuZCBjcmVhdG9yIGNhbiBhZGQgYW55IG51bWJlciBvZiBiYWRnZXNcbiAgICAgIC8vIG90aGVyIHR5cGUgb2YgdXNlcnMgd2lsbCBoYXZlIG5vIGFjY2VzcyB0byB0aGlzIGZlYXR1cmVcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvLyBzdGVwIDE6IHJlcXVlc3QgdmFsaWRhdGlvbiwgYmFzaWMgZmlsdGVyaW5nXG4gICAgICBpZiAoIXRoaXMudXNlcklkKSB7XG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSA5OTk7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJBY2Nlc3MgZGVuaWVkXCI7XG4gICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgIH1cbiAgICAgIGNoZWNrKGRhdGEsIE9iamVjdCk7XG5cbiAgICAgIC8vIHN0ZXAgMiA6IGNoZWNraW5nIERCIGFjY2VzcyByaWdodHNcblxuICAgICAgLy8gYSBmbGFnIHRvIG1ha2Ugc3VyZSB0aGlzIHJlcXVlc3RpbmcgdXNlciBoYXMgdGhlIHJpZ2h0IGFjY2VzcyB0byBtb2RpZnkgdGhpcyBkYXRhXG4gICAgICB2YXIgdXNlckhhc0FjY2Vzc1JpZ2h0cyA9IGZhbHNlO1xuXG4gICAgICB2YXIgdXNlcklzQWRtaW4gPSBmYWxzZTtcbiAgICAgIHZhciB1c2VySXNDcmVhdG9yID0gZmFsc2U7XG5cbiAgICAgIHZhciBkYkFjY2Vzc0NoZWNrZXIgPSBuZXcgQ2hlY2tkYmFjY2VzcygpO1xuXG4gICAgICB1c2VySXNBZG1pbiA9IGRiQWNjZXNzQ2hlY2tlci5pc1JvbGVBZG1pbih0aGlzLnVzZXJJZCk7IC8vcmV0dXJucyB0cnVlIGlmIGFkbWluXG4gICAgICB1c2VySXNDcmVhdG9yID0gZGJBY2Nlc3NDaGVja2VyLmlzUm9sZUNyZWF0b3IodGhpcy51c2VySWQpOyAvL3JldHVybnMgdHJ1ZSBpZiBjcmVhdG9yXG5cbiAgICAgIGlmICh1c2VySXNBZG1pbiB8fCB1c2VySXNDcmVhdG9yKSB7XG4gICAgICAgIHVzZXJIYXNBY2Nlc3NSaWdodHMgPSB0cnVlO1xuICAgICAgfVxuICAgICAgLy8gdXNlckhhc0FjY2Vzc1JpZ2h0cyA9IHVzZXJJc0FkbWluO1xuXG4gICAgICBpZiAodXNlckhhc0FjY2Vzc1JpZ2h0cyA9PT0gdHJ1ZSkge1xuXG4gICAgICAgIC8vIHN0ZXAgOiAzIHVwZGF0aW5nIGRhdGEgaW50byB0aGUgREJcbiAgICAgICAgTWV0YWRhdGFEQi5jb2xsZWN0aW9uLmluc2VydCh7XG5cbiAgICAgICAgICBiYWRnZV9pZDogZGF0YS5iYWRnZV9pZCxcbiAgICAgICAgICBjb3Vyc2VzOiBkYXRhLmNvdXJzZXMsXG4gICAgICAgICAgaXNzdWVyczogZGF0YS5pc3N1ZXJzLFxuICAgICAgICAgIGtleXdvcmRzOiBkYXRhLmtleXdvcmRzLFxuICAgICAgICAgIGxldmVsSUQ6IGRhdGEubGV2ZWxJRCxcbiAgICAgICAgICBjb21wZXRlbmN5SUQ6IGRhdGEuY29tcGV0ZW5jeUlELFxuICAgICAgICAgIHRvb2xzOiBkYXRhLnRvb2xzLFxuICAgICAgICAgIGNyZWF0b3I6IGRhdGEuY3JlYXRvcixcbiAgICAgICAgICBhcHBsaWNhbnRzOiBkYXRhLmFwcGxpY2FudHMsXG4gICAgICAgICAgZWFybmVyczogZGF0YS5lYXJuZXJzLFxuICAgICAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKVxuXG4gICAgICAgIH0pOyAvL2VuZCBpbnNlcnRcbiAgICAgICAgcmVzcG9uc2UuY29kZSA9IDIwMDtcbiAgICAgICAgcmVzcG9uc2UuZmVlZGJhY2sgPSBcIk5ldyBCYWRnZSBDcmVhdGlvbiBzdWNjZXNzZnVsIVwiO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9IC8vIGVuZCBpZiBpZih1c2VySGFzQWNjZXNzUmlnaHRzID09PSB0cnVlKVxuICAgICAgZWxzZSB7XG4gICAgICAgIC8vIG5vIEFjY2VzcyByaWdodFxuICAgICAgICByZXNwb25zZS5jb2RlID0gOTk5O1xuICAgICAgICByZXNwb25zZS5mZWVkYmFjayA9IFwiQWNjZXNzIGRlbmllZFwiO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuXG4gICAgfSxcblxuICAgICd1cGRhdGVNZXRhZGF0YScoZGF0YSkge1xuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgIC8vIHRoZSByZXNwb25zZSBvYmplY3QgZm9yIGNsaWVudCB3aXRoIGZlZWRiYWNrIGFuZCBkYXRhXG4gICAgICAvLyBjb2RlcyA6XG4gICAgICAvLyA5OTkgPSBhY2Nlc3MgZGVuaWVkLlxuICAgICAgLy8gNDA0ID0gRGF0YmFzZSBsZXZlbCBwcm9ibGVtIG9yIFVua25vd24gZXJyb3Igb3IgZXhjZXB0aW9uc1xuICAgICAgLy8gMjAwID0gc3VjY2VzcztcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4gICAgICB2YXIgcmVzcG9uc2U6IGFueSA9IHtcbiAgICAgICAgZmVlZGJhY2s6IFwiVW5rbm93biBlcnJvciB3aGlsZSBwcm9jZXNzaW5nLiBQbGVhc2UgdHJ5IGFnYWluLlwiLFxuICAgICAgICBjb2RlOiA0MDRcbiAgICAgIH1cblxuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgLy8gYWNjZXNzIHJ1bGVzIDpcbiAgICAgIC8vIGFkbWluIGFuZCBjcmVhdG9yIGNhbiBhZGQgYW55IG51bWJlciBvZiBiYWRnZXNcbiAgICAgIC8vIG90aGVyIHR5cGUgb2YgdXNlcnMgd2lsbCBoYXZlIG5vIGFjY2VzcyB0byB0aGlzIGZlYXR1cmVcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvLyBzdGVwIDE6IHJlcXVlc3QgdmFsaWRhdGlvbiwgYmFzaWMgZmlsdGVyaW5nXG4gICAgICBpZiAoIXRoaXMudXNlcklkKSB7XG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSA5OTk7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJBY2Nlc3MgZGVuaWVkXCI7XG4gICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgIH1cbiAgICAgIGNoZWNrKGRhdGEsIE9iamVjdCk7XG5cbiAgICAgIC8vIHN0ZXAgMiA6IGNoZWNraW5nIERCIGFjY2VzcyByaWdodHNcblxuICAgICAgLy8gYSBmbGFnIHRvIG1ha2Ugc3VyZSB0aGlzIHJlcXVlc3RpbmcgdXNlciBoYXMgdGhlIHJpZ2h0IGFjY2VzcyB0byBtb2RpZnkgdGhpcyBkYXRhXG4gICAgICB2YXIgdXNlckhhc0FjY2Vzc1JpZ2h0cyA9IGZhbHNlO1xuXG4gICAgICB2YXIgdXNlcklzQWRtaW4gPSBmYWxzZTtcbiAgICAgIHZhciB1c2VySXNDcmVhdG9yID0gZmFsc2U7XG5cbiAgICAgIHZhciBkYkFjY2Vzc0NoZWNrZXIgPSBuZXcgQ2hlY2tkYmFjY2VzcygpO1xuXG4gICAgICB1c2VySXNBZG1pbiA9IGRiQWNjZXNzQ2hlY2tlci5pc1JvbGVBZG1pbih0aGlzLnVzZXJJZCk7IC8vcmV0dXJucyB0cnVlIGlmIGFkbWluXG4gICAgICB1c2VySXNDcmVhdG9yID0gZGJBY2Nlc3NDaGVja2VyLmlzUm9sZUNyZWF0b3IodGhpcy51c2VySWQpOyAvL3JldHVybnMgdHJ1ZSBpZiBjcmVhdG9yXG5cbiAgICAgIGlmICh1c2VySXNBZG1pbiB8fCB1c2VySXNDcmVhdG9yKSB7XG4gICAgICAgIHVzZXJIYXNBY2Nlc3NSaWdodHMgPSB0cnVlO1xuICAgICAgfVxuICAgICAgLy8gdXNlckhhc0FjY2Vzc1JpZ2h0cyA9IHVzZXJJc0FkbWluO1xuXG4gICAgICBpZiAodXNlckhhc0FjY2Vzc1JpZ2h0cyA9PT0gdHJ1ZSkge1xuICAgICAgICAvLyBzdGVwIDogMyB1cGRhdGluZyBkYXRhIGludG8gdGhlIERCXG4gICAgICAgIGNvbnNvbGUubG9nKGRhdGEpO1xuICAgICAgICB2YXIgYmFkZ2VEQiA9IE1ldGFkYXRhREIuZmluZE9uZSh7XCJiYWRnZV9pZFwiOmRhdGEuYmFkZ2VfaWR9KTtcbiAgICAgICAgaWYgKGJhZGdlREIgIT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgTWV0YWRhdGFEQi5jb2xsZWN0aW9uLnVwZGF0ZShcbiAgICAgICAgICAgIGJhZGdlREIuX2lkLFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAkc2V0OlxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgIGNvdXJzZXM6IGRhdGEuY291cnNlcyxcbiAgICAgICAgICAgICAgICAgIGlzc3VlcnM6IGRhdGEuaXNzdWVycyxcbiAgICAgICAgICAgICAgICAgIGtleXdvcmRzOiBkYXRhLmtleXdvcmRzLFxuICAgICAgICAgICAgICAgICAgbGV2ZWxJRDogZGF0YS5sZXZlbElELFxuICAgICAgICAgICAgICAgICAgY29tcGV0ZW5jeUlEOiBkYXRhLmNvbXBldGVuY3lJRCxcbiAgICAgICAgICAgICAgICAgIHRvb2xzOiBkYXRhLnRvb2xzLFxuICAgICAgICAgICAgICAgICAgY3JlYXRvcjogZGF0YS5jcmVhdG9yLFxuICAgICAgICAgICAgICAgICAgYXBwbGljYW50czogZGF0YS5hcHBsaWNhbnRzLFxuICAgICAgICAgICAgICAgICAgZWFybmVyczogZGF0YS5lYXJuZXJzLFxuICAgICAgICAgICAgICAgICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7IC8vIGVuZCB1cGRhdGVcbiAgICAgICAgfVxuXG5cblxuXG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSAyMDA7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJCYWRnZSBVcGRhdGUgc3VjY2Vzc2Z1bCFcIjtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuXG5cbiAgICAgIH0gLy8gZW5kIGlmIGlmKHVzZXJIYXNBY2Nlc3NSaWdodHMgPT09IHRydWUpXG4gICAgICBlbHNlIHtcbiAgICAgICAgLy8gbm8gQWNjZXNzIHJpZ2h0XG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSA5OTk7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJBY2Nlc3MgZGVuaWVkXCI7XG4gICAgICB9XG4gICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgfSxcblxuICAgICdpbXBvcnROZXdCYWRnZUZyb21PQkYnKGRhdGEpIHtcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvLyB0aGUgcmVzcG9uc2Ugb2JqZWN0IGZvciBjbGllbnQgd2l0aCBmZWVkYmFjayBhbmQgZGF0YVxuICAgICAgLy8gY29kZXMgOlxuICAgICAgLy8gOTk5ID0gYWNjZXNzIGRlbmllZC5cbiAgICAgIC8vIDQwNCA9IERhdGJhc2UgbGV2ZWwgcHJvYmxlbSBvciBVbmtub3duIGVycm9yIG9yIGV4Y2VwdGlvbnNcbiAgICAgIC8vIDIwMCA9IHN1Y2Nlc3M7XG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuICAgICAgdmFyIHJlc3BvbnNlOiBhbnkgPSB7XG4gICAgICAgIGZlZWRiYWNrOiBcIlVua25vd24gZXJyb3Igd2hpbGUgcHJvY2Vzc2luZy4gUGxlYXNlIHRyeSBhZ2Fpbi5cIixcbiAgICAgICAgY29kZTogNDA0XG4gICAgICB9XG5cbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgIC8vIGFjY2VzcyBydWxlcyA6XG4gICAgICAvLyBhZG1pbiBhbmQgY3JlYXRvciBjYW4gYWRkIGFueSBudW1iZXIgb2YgYmFkZ2VzXG4gICAgICAvLyBvdGhlciB0eXBlIG9mIHVzZXJzIHdpbGwgaGF2ZSBubyBhY2Nlc3MgdG8gdGhpcyBmZWF0dXJlXG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgLy8gc3RlcCAxOiByZXF1ZXN0IHZhbGlkYXRpb24sIGJhc2ljIGZpbHRlcmluZ1xuICAgICAgaWYgKCF0aGlzLnVzZXJJZCkge1xuICAgICAgICByZXNwb25zZS5jb2RlID0gOTk5O1xuICAgICAgICByZXNwb25zZS5mZWVkYmFjayA9IFwiQWNjZXNzIGRlbmllZFwiO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9XG4gICAgICBjaGVjayhkYXRhLCBPYmplY3QpO1xuXG4gICAgICAvLyBzdGVwIDIgOiBjaGVja2luZyBEQiBhY2Nlc3MgcmlnaHRzXG5cbiAgICAgIC8vIGEgZmxhZyB0byBtYWtlIHN1cmUgdGhpcyByZXF1ZXN0aW5nIHVzZXIgaGFzIHRoZSByaWdodCBhY2Nlc3MgdG8gbW9kaWZ5IHRoaXMgZGF0YVxuICAgICAgdmFyIHVzZXJIYXNBY2Nlc3NSaWdodHMgPSBmYWxzZTtcblxuICAgICAgdmFyIHVzZXJJc0FkbWluID0gZmFsc2U7XG4gICAgICB2YXIgdXNlcklzQ3JlYXRvciA9IGZhbHNlO1xuXG4gICAgICB2YXIgZGJBY2Nlc3NDaGVja2VyID0gbmV3IENoZWNrZGJhY2Nlc3MoKTtcblxuICAgICAgdXNlcklzQWRtaW4gPSBkYkFjY2Vzc0NoZWNrZXIuaXNSb2xlQWRtaW4odGhpcy51c2VySWQpOyAvL3JldHVybnMgdHJ1ZSBpZiBhZG1pblxuICAgICAgdXNlcklzQ3JlYXRvciA9IGRiQWNjZXNzQ2hlY2tlci5pc1JvbGVDcmVhdG9yKHRoaXMudXNlcklkKTsgLy9yZXR1cm5zIHRydWUgaWYgY3JlYXRvclxuXG4gICAgICBpZiAodXNlcklzQWRtaW4gfHwgdXNlcklzQ3JlYXRvcikge1xuICAgICAgICB1c2VySGFzQWNjZXNzUmlnaHRzID0gdHJ1ZTtcbiAgICAgIH1cblxuICAgICAgaWYgKHVzZXJIYXNBY2Nlc3NSaWdodHMgPT09IHRydWUpIHtcblxuICAgICAgICAvLyBzdGVwIDogMyB1cGRhdGluZyBkYXRhIGludG8gdGhlIERCXG4gICAgICAgIE1ldGFkYXRhREIuY29sbGVjdGlvbi5pbnNlcnQoe1xuXG4gICAgICAgICAgYmFkZ2VfaWQ6IGRhdGEuYmFkZ2VfaWQsXG4gICAgICAgICAgY291cnNlczogZGF0YS5jb3Vyc2VzLFxuICAgICAgICAgIGlzc3VlcnM6IGRhdGEuaXNzdWVycyxcbiAgICAgICAgICBrZXl3b3JkczogZGF0YS5rZXl3b3JkcyxcbiAgICAgICAgICBsZXZlbElEOiBkYXRhLmxldmVsSUQsXG4gICAgICAgICAgY29tcGV0ZW5jeUlEOiBkYXRhLmNvbXBldGVuY3lJRCxcbiAgICAgICAgICB0b29sczogZGF0YS50b29scyxcbiAgICAgICAgICBjcmVhdG9yOiBkYXRhLmNyZWF0b3IsXG4gICAgICAgICAgYXBwbGljYW50czogZGF0YS5hcHBsaWNhbnRzLFxuICAgICAgICAgIGVhcm5lcnM6IGRhdGEuZWFybmVycyxcbiAgICAgICAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKClcblxuICAgICAgICB9KTsgLy9lbmQgaW5zZXJ0XG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSAyMDA7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJOZXcgQmFkZ2UgSW1wb3J0IHN1Y2Nlc3NmdWwhXCI7XG4gICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgIH0gLy8gZW5kIGlmIGlmKHVzZXJIYXNBY2Nlc3NSaWdodHMgPT09IHRydWUpXG4gICAgICBlbHNlIHtcbiAgICAgICAgLy8gbm8gQWNjZXNzIHJpZ2h0XG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSA5OTk7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJBY2Nlc3MgZGVuaWVkXCI7XG4gICAgICB9XG4gICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgfSxcblxuICAgICdnZXROdW1iZXJPZkJhZGdlcycoKSB7XG4gICAgICByZXR1cm4gTWV0YWRhdGFEQi5jb2xsZWN0aW9uLmZpbmQoKS5jb3VudCgpO1xuICAgIH0sXG5cbiAgICAnbWlzc2luZ01ldGFkYXRhQ291bnQnKCkge1xuICAgICAgICByZXR1cm4gTWV0YWRhdGFEQi5jb2xsZWN0aW9uLmZpbmQoe1wibGV2ZWxJRFwiOlwiXCJ9KS5jb3VudCgpO1xuICAgIH1cblxuXG4gIH0pOyAvLyBFTkQgb2YgbWV0ZW9yIG1ldGhvZHNcblxufSAvLyBFTkQgb2YgTWV0ZW9yLmlzU2VydmVyXG4iLCIvLyBkb2NzIGZvciBtZXRlb3IgZGVmYXVsdCBtZXRob2RzIDogaHR0cDovL2RvY3MubWV0ZW9yLmNvbS9hcGkvcGFzc3dvcmRzLmh0bWxcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgQWNjb3VudHMgfSBmcm9tICdtZXRlb3IvYWNjb3VudHMtYmFzZSdcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCB7IE1ldGVvck9ic2VydmFibGUgfSBmcm9tICdtZXRlb3Itcnhqcyc7XG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjayc7XG5pbXBvcnQgeyBDaGVja2RiYWNjZXNzIH0gZnJvbSAnL3NlcnZlci9kYmFwaS90b29scy9jaGVja2RiYWNjZXNzLnRzJztcbmltcG9ydCB7IENhbXB1c0RCLCBQcm9maWxlREIsIEZhY3VsdHlEQiB9IGZyb20gXCIvaW1wb3J0cy9hcGkvaW5kZXhcIjtcblxuXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG5cbiAgTWV0ZW9yLm1ldGhvZHMoe1xuXG5cbiAgICAnaXNDYW1wdXNFeGlzdEluREInKGNhbXB1c05hbWUpIHtcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvLyB0aGUgcmVzcG9uc2Ugb2JqZWN0IGZvciBjbGllbnQgd2l0aCBmZWVkYmFjayBhbmQgZGF0YVxuICAgICAgLy8gY29kZXMgOlxuICAgICAgLy8gOTk5ID0gdW5rbm93biBuYW1lLlxuICAgICAgLy8gNDA0ID0gRGF0YmFzZSBsZXZlbCBwcm9ibGVtIG9yIFVua25vd24gZXJyb3Igb3IgZXhjZXB0aW9uc1xuICAgICAgLy8gMjAwID0gY2FtcHVzIG5hbWUgYWxyZWFkeSBleGlzdHM7XG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgIHZhciByZXNwb25zZTogYW55ID0ge1xuICAgICAgICBmZWVkYmFjazogXCJVbmtub3duIGVycm9yIHdoaWxlIHByb2Nlc3NpbmcgcmVxdWVzdC4gUGxlYXNlIHRyeSBhZ2Fpbi5cIixcbiAgICAgICAgY29kZTogNDA0XG4gICAgICB9XG5cbiAgICAgIHZhciBjYW1wdXNOYW1laW5EQiA9IENhbXB1c0RCLmZpbmRPbmUoeyBcIm5hbWVcIjogY2FtcHVzTmFtZSB9KTtcblxuXG4gICAgICBpZiAoY2FtcHVzTmFtZWluREIgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICByZXNwb25zZS5jb2RlID0gMjAwO1xuICAgICAgICByZXNwb25zZS5mZWVkYmFjayA9IFwiVGhpcyBDYW1wdXMgaXMgYWxyZWFkeSByZWdpc3RlcmVkIGluIHRoZSBzeXN0ZW1cIjtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgfVxuICAgICAgZWxzZSBpZiAoY2FtcHVzTmFtZWluREIgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICByZXNwb25zZS5jb2RlID0gOTk5O1xuICAgICAgICByZXNwb25zZS5mZWVkYmFjayA9IFwiVGhpcyBDYW1wdXMgaXMgbm90IHJlZ2lzdGVyZWQgaW4gdGhlIHN5c3RlbVwiO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9XG4gICAgICBlbHNlIHtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgfVxuICAgIH0sXG5cbiAgICAnYWRkTmV3Q2FtcHVzJyhkYXRhKSB7XG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgLy8gdGhlIHJlc3BvbnNlIG9iamVjdCBmb3IgY2xpZW50IHdpdGggZmVlZGJhY2sgYW5kIGRhdGFcbiAgICAgIC8vIGNvZGVzIDpcbiAgICAgIC8vIDk5OSA9IGFjY2VzcyBkZW5pZWQuXG4gICAgICAvLyA0MDQgPSBEYXRiYXNlIGxldmVsIHByb2JsZW0gb3IgVW5rbm93biBlcnJvciBvciBleGNlcHRpb25zXG4gICAgICAvLyAyMDAgPSBzdWNjZXNzO1xuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbiAgICAgIHZhciByZXNwb25zZTogYW55ID0ge1xuICAgICAgICBmZWVkYmFjazogXCJVbmtub3duIGVycm9yIHdoaWxlIHByb2Nlc3NpbmcuIFBsZWFzZSB0cnkgYWdhaW4uXCIsXG4gICAgICAgIGNvZGU6IDQwNFxuICAgICAgfVxuXG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvLyBhY2Nlc3MgcnVsZXMgOlxuICAgICAgLy8gYWRtaW4gY2FuIGFkZCBhbnkgbnVtYmVyIG9mIGNhbXB1c1xuICAgICAgLy8gb3RoZXIgdHlwZSBvZiB1c2VycyB3aWxsIGhhdmUgbm8gYWNjZXNzIHRvIHRoaXMgZmVhdHVyZVxuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgIC8vIHN0ZXAgMTogcmVxdWVzdCB2YWxpZGF0aW9uLCBiYXNpYyBmaWx0ZXJpbmdcbiAgICAgIGlmICghdGhpcy51c2VySWQpIHtcbiAgICAgICAgcmVzcG9uc2UuY29kZSA9IDk5OTtcbiAgICAgICAgcmVzcG9uc2UuZmVlZGJhY2sgPSBcIkFjY2VzcyBkZW5pZWRcIjtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgfVxuICAgICAgY2hlY2soZGF0YSwgT2JqZWN0KTtcblxuICAgICAgLy8gc3RlcCAyIDogY2hlY2tpbmcgREIgYWNjZXNzIHJpZ2h0c1xuXG4gICAgICAvLyBhIGZsYWcgdG8gbWFrZSBzdXJlIHRoaXMgcmVxdWVzdGluZyB1c2VyIGhhcyB0aGUgcmlnaHQgYWNjZXNzIHRvIG1vZGlmeSB0aGlzIGRhdGFcbiAgICAgIHZhciB1c2VySGFzQWNjZXNzUmlnaHRzID0gZmFsc2U7XG5cbiAgICAgIHZhciB1c2VySXNBZG1pbiA9IGZhbHNlO1xuXG4gICAgICB2YXIgZGJBY2Nlc3NDaGVja2VyID0gbmV3IENoZWNrZGJhY2Nlc3MoKTtcblxuICAgICAgdXNlcklzQWRtaW4gPSBkYkFjY2Vzc0NoZWNrZXIuaXNSb2xlQWRtaW4odGhpcy51c2VySWQpOyAvL3JldHVybnMgdHJ1ZSBpZiBhZG1pblxuICAgICAgdXNlckhhc0FjY2Vzc1JpZ2h0cyA9IHVzZXJJc0FkbWluO1xuXG4gICAgICBpZiAodXNlckhhc0FjY2Vzc1JpZ2h0cyA9PT0gdHJ1ZSkge1xuXG4gICAgICAgIC8vIHN0ZXAgOiAzIHVwZGF0aW5nIGRhdGEgaW50byB0aGUgREJcbiAgICAgICAgQ2FtcHVzREIuY29sbGVjdGlvbi5pbnNlcnQoe1xuXG4gICAgICAgICAgbmFtZTogZGF0YS5uYW1lLFxuICAgICAgICAgIGRlc2NyaXB0aW9uOiBkYXRhLmRlc2NyaXB0aW9uLFxuICAgICAgICAgIGNyZWF0ZWRCeTogTWV0ZW9yLnVzZXIoKS5lbWFpbHNbMF0uYWRkcmVzcyxcbiAgICAgICAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKCksXG5cbiAgICAgICAgfSk7IC8vZW5kIGluc2VydFxuICAgICAgICByZXNwb25zZS5jb2RlID0gMjAwO1xuICAgICAgICByZXNwb25zZS5mZWVkYmFjayA9IFwiTmV3IENhbXB1cyBDcmVhdGlvbiBzdWNjZXNzZnVsbCFcIjtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgfSAvLyBlbmQgaWYgaWYodXNlckhhc0FjY2Vzc1JpZ2h0cyA9PT0gdHJ1ZSlcbiAgICAgIGVsc2Uge1xuICAgICAgICAvLyBubyBBY2Nlc3MgcmlnaHRcbiAgICAgICAgcmVzcG9uc2UuY29kZSA9IDk5OTtcbiAgICAgICAgcmVzcG9uc2UuZmVlZGJhY2sgPSBcIkFjY2VzcyBkZW5pZWRcIjtcbiAgICAgIH1cbiAgICAgIHJldHVybiByZXNwb25zZTtcblxuXG5cbiAgICB9LFxuXG4gICAgJ3VwZGF0ZUNhbXB1cycoZGF0YSkge1xuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgIC8vIHRoZSByZXNwb25zZSBvYmplY3QgZm9yIGNsaWVudCB3aXRoIGZlZWRiYWNrIGFuZCBkYXRhXG4gICAgICAvLyBjb2RlcyA6XG4gICAgICAvLyA5OTkgPSBhY2Nlc3MgZGVuaWVkLlxuICAgICAgLy8gNDA0ID0gRGF0YmFzZSBsZXZlbCBwcm9ibGVtIG9yIFVua25vd24gZXJyb3Igb3IgZXhjZXB0aW9uc1xuICAgICAgLy8gMjAwID0gc3VjY2VzcztcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4gICAgICB2YXIgcmVzcG9uc2U6IGFueSA9IHtcbiAgICAgICAgZmVlZGJhY2s6IFwiVW5rbm93biBlcnJvciB3aGlsZSBwcm9jZXNzaW5nLiBQbGVhc2UgdHJ5IGFnYWluLlwiLFxuICAgICAgICBjb2RlOiA0MDRcbiAgICAgIH1cblxuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgLy8gYWNjZXNzIHJ1bGVzIDpcbiAgICAgIC8vIGFkbWluIGNhbiBlZGl0IGFueSBudW1iZXIgb2YgY2FtcHVzXG4gICAgICAvLyBvdGhlciB0eXBlIG9mIHVzZXJzIHdpbGwgaGF2ZSBubyBhY2Nlc3MgdG8gdGhpcyBmZWF0dXJlXG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgLy8gc3RlcCAxOiByZXF1ZXN0IHZhbGlkYXRpb24sIGJhc2ljIGZpbHRlcmluZ1xuICAgICAgaWYgKCF0aGlzLnVzZXJJZCkge1xuICAgICAgICByZXNwb25zZS5jb2RlID0gOTk5O1xuICAgICAgICByZXNwb25zZS5mZWVkYmFjayA9IFwiQWNjZXNzIGRlbmllZFwiO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9XG4gICAgICBjaGVjayhkYXRhLCBPYmplY3QpO1xuXG4gICAgICAvLyBzdGVwIDIgOiBjaGVja2luZyBEQiBhY2Nlc3MgcmlnaHRzXG5cbiAgICAgIC8vIGEgZmxhZyB0byBtYWtlIHN1cmUgdGhpcyByZXF1ZXN0aW5nIHVzZXIgaGFzIHRoZSByaWdodCBhY2Nlc3MgdG8gbW9kaWZ5IHRoaXMgZGF0YVxuICAgICAgdmFyIHVzZXJIYXNBY2Nlc3NSaWdodHMgPSBmYWxzZTtcblxuICAgICAgdmFyIHVzZXJJc0FkbWluID0gZmFsc2U7XG5cbiAgICAgIHZhciBkYkFjY2Vzc0NoZWNrZXIgPSBuZXcgQ2hlY2tkYmFjY2VzcygpO1xuXG4gICAgICB1c2VySXNBZG1pbiA9IGRiQWNjZXNzQ2hlY2tlci5pc1JvbGVBZG1pbih0aGlzLnVzZXJJZCk7IC8vcmV0dXJucyB0cnVlIGlmIGFkbWluXG4gICAgICB1c2VySGFzQWNjZXNzUmlnaHRzID0gdXNlcklzQWRtaW47XG5cbiAgICAgIGlmICh1c2VySGFzQWNjZXNzUmlnaHRzID09PSB0cnVlKSB7XG5cbiAgICAgICAgLy8gc3RlcCA6IDMgdXBkYXRpbmcgZGF0YSBpbnRvIHRoZSBEQlxuICAgICAgICBDYW1wdXNEQi5jb2xsZWN0aW9uLnVwZGF0ZShcbiAgICAgICAgICBkYXRhLl9pZCxcbiAgICAgICAgICB7XG4gICAgICAgICAgICAkc2V0OlxuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgbmFtZTogZGF0YS5uYW1lLFxuICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBkYXRhLmRlc2NyaXB0aW9uLFxuICAgICAgICAgICAgICAgIGNyZWF0ZWRCeTogTWV0ZW9yLnVzZXIoKS5lbWFpbHNbMF0uYWRkcmVzcyxcbiAgICAgICAgICAgICAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKCksXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICB9KTsgLy8gZW5kIHVwZGF0ZVxuXG5cbiAgICAgICAgcmVzcG9uc2UuY29kZSA9IDIwMDtcbiAgICAgICAgcmVzcG9uc2UuZmVlZGJhY2sgPSBcIkNhbXB1cyBVcGRhdGUgc3VjY2Vzc2Z1bGwhXCI7XG4gICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgIH0gLy8gZW5kIGlmIGlmKHVzZXJIYXNBY2Nlc3NSaWdodHMgPT09IHRydWUpXG4gICAgICBlbHNlIHtcbiAgICAgICAgLy8gbm8gQWNjZXNzIHJpZ2h0XG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSA5OTk7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJBY2Nlc3MgZGVuaWVkXCI7XG4gICAgICB9XG4gICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgfSxcblxuICAgICdpc0NhbXB1c0hhc0ZhY3VsdHknKGNhbXB1c0lEKSB7XG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgLy8gdGhlIHJlc3BvbnNlIG9iamVjdCBmb3IgY2xpZW50IHdpdGggZmVlZGJhY2sgYW5kIGRhdGFcbiAgICAgIC8vIGNvZGVzIDpcbiAgICAgIC8vIDk5OSA9IGNhbXB1cyBoYXMgbm8gZmFjdWx0eS5cbiAgICAgIC8vIDQwNCA9IERhdGJhc2UgbGV2ZWwgcHJvYmxlbSBvciBVbmtub3duIGVycm9yIG9yIGV4Y2VwdGlvbnNcbiAgICAgIC8vIDIwMCA9IGNhbXB1cyBoYXMgZmFjdWx0eVxuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbiAgICAgIHZhciByZXNwb25zZTogYW55ID0ge1xuICAgICAgICBmZWVkYmFjazogXCJVbmtub3duIGVycm9yIHdoaWxlIHByb2Nlc3NpbmcgcmVxdWVzdC4gUGxlYXNlIHRyeSBhZ2Fpbi5cIixcbiAgICAgICAgY29kZTogNDA0XG4gICAgICB9XG5cbiAgICAgIHZhciBub09mRmFjdWx0eSA9IEZhY3VsdHlEQi5jb2xsZWN0aW9uLmZpbmQoeyBcImNhbXB1c0lEXCI6IGNhbXB1c0lEIH0pLmNvdW50KCk7XG5cbiAgICAgIGlmIChub09mRmFjdWx0eSAhPT0gdW5kZWZpbmVkICYmIG5vT2ZGYWN1bHR5ID4gMCkge1xuICAgICAgICByZXNwb25zZS5jb2RlID0gOTk5O1xuICAgICAgICByZXNwb25zZS5mZWVkYmFjayA9IFwiVGhpcyBDYW1wdXMgaGFzIGZhY3VsdHkuIERlbGV0ZSBmYWN1bHRpZXMgb2YgdGhpcyBjYW1wdXMgZmlyc3QuXCI7XG4gICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgIH1cbiAgICAgIGVsc2UgaWYgKG5vT2ZGYWN1bHR5ID09PSB1bmRlZmluZWQgfHwgbm9PZkZhY3VsdHkgPT09IDApIHtcbiAgICAgICAgcmVzcG9uc2UuY29kZSA9IDIwMDtcbiAgICAgICAgcmVzcG9uc2UuZmVlZGJhY2sgPSBcIlRoaXMgQ2FtcHVzIGRvZXNuJ3QgaGF2ZSBhbnkgZmFjdWx0eVwiO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9XG4gICAgICBlbHNlIHtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgfVxuICAgIH0sXG5cbiAgICAnZGVsZXRlQ2FtcHVzJyhkYXRhKSB7XG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgLy8gdGhlIHJlc3BvbnNlIG9iamVjdCBmb3IgY2xpZW50IHdpdGggZmVlZGJhY2sgYW5kIGRhdGFcbiAgICAgIC8vIGNvZGVzIDpcbiAgICAgIC8vIDk5OSA9IGFjY2VzcyBkZW5pZWQuXG4gICAgICAvLyA0MDQgPSBEYXRiYXNlIGxldmVsIHByb2JsZW0gb3IgVW5rbm93biBlcnJvciBvciBleGNlcHRpb25zXG4gICAgICAvLyAyMDAgPSBzdWNjZXNzO1xuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbiAgICAgIHZhciByZXNwb25zZTogYW55ID0ge1xuICAgICAgICBmZWVkYmFjazogXCJVbmtub3duIGVycm9yIHdoaWxlIHByb2Nlc3NpbmcuIFBsZWFzZSB0cnkgYWdhaW4uXCIsXG4gICAgICAgIGNvZGU6IDQwNFxuICAgICAgfVxuXG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvLyBhY2Nlc3MgcnVsZXMgOlxuICAgICAgLy8gYWRtaW4gY2FuIGVkaXQgYW55IG51bWJlciBvZiBjYW1wdXNcbiAgICAgIC8vIG90aGVyIHR5cGUgb2YgdXNlcnMgd2lsbCBoYXZlIG5vIGFjY2VzcyB0byB0aGlzIGZlYXR1cmVcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvLyBzdGVwIDE6IHJlcXVlc3QgdmFsaWRhdGlvbiwgYmFzaWMgZmlsdGVyaW5nXG4gICAgICBpZiAoIXRoaXMudXNlcklkKSB7XG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSA5OTk7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJBY2Nlc3MgZGVuaWVkXCI7XG4gICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgIH1cbiAgICAgIGNoZWNrKGRhdGEsIE9iamVjdCk7XG5cbiAgICAgIC8vIHN0ZXAgMiA6IGNoZWNraW5nIERCIGFjY2VzcyByaWdodHNcblxuICAgICAgLy8gYSBmbGFnIHRvIG1ha2Ugc3VyZSB0aGlzIHJlcXVlc3RpbmcgdXNlciBoYXMgdGhlIHJpZ2h0IGFjY2VzcyB0byBtb2RpZnkgdGhpcyBkYXRhXG4gICAgICB2YXIgdXNlckhhc0FjY2Vzc1JpZ2h0cyA9IGZhbHNlO1xuXG4gICAgICB2YXIgdXNlcklzQWRtaW4gPSBmYWxzZTtcblxuICAgICAgdmFyIGRiQWNjZXNzQ2hlY2tlciA9IG5ldyBDaGVja2RiYWNjZXNzKCk7XG5cbiAgICAgIHVzZXJJc0FkbWluID0gZGJBY2Nlc3NDaGVja2VyLmlzUm9sZUFkbWluKHRoaXMudXNlcklkKTsgLy9yZXR1cm5zIHRydWUgaWYgYWRtaW5cbiAgICAgIHVzZXJIYXNBY2Nlc3NSaWdodHMgPSB1c2VySXNBZG1pbjtcblxuICAgICAgaWYgKHVzZXJIYXNBY2Nlc3NSaWdodHMgPT09IHRydWUpIHtcbiAgICAgICAgQ2FtcHVzREIuY29sbGVjdGlvbi5yZW1vdmUoZGF0YS5faWQpO1xuXG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSAyMDA7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJDYW1wdXMgZGVsZXRlIHN1Y2Nlc3NmdWxsIVwiO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9XG4gICAgICBlbHNlIHtcbiAgICAgICAgLy8gbm8gQWNjZXNzIHJpZ2h0XG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSA5OTk7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJBY2Nlc3MgZGVuaWVkXCI7XG4gICAgICB9XG4gICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgfSxcblxuICAgICdnZXRBbGxDYW1wdXNOYW1lJygpIHtcbiAgICAgIHJldHVybiBDYW1wdXNEQi5maW5kKHt9KS5mZXRjaCgpO1xuICAgIH1cblxuXG4gIH0pOyAvLyBFTkQgb2YgbWV0ZW9yIG1ldGhvZHNcblxufSAvLyBFTkQgb2YgTWV0ZW9yLmlzU2VydmVyXG4iLCIvLyBkb2NzIGZvciBtZXRlb3IgZGVmYXVsdCBtZXRob2RzIDogaHR0cDovL2RvY3MubWV0ZW9yLmNvbS9hcGkvcGFzc3dvcmRzLmh0bWxcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgQWNjb3VudHMgfSBmcm9tICdtZXRlb3IvYWNjb3VudHMtYmFzZSdcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCB7IE1ldGVvck9ic2VydmFibGUgfSBmcm9tICdtZXRlb3Itcnhqcyc7XG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjayc7XG5pbXBvcnQgeyBDaGVja2RiYWNjZXNzIH0gZnJvbSAnL3NlcnZlci9kYmFwaS90b29scy9jaGVja2RiYWNjZXNzLnRzJztcbmltcG9ydCB7IENvbXBldGVuY3lEQiwgUHJvZmlsZURCLCBGYWN1bHR5REIgfSBmcm9tIFwiL2ltcG9ydHMvYXBpL2luZGV4XCI7XG5cblxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xuXG4gIE1ldGVvci5tZXRob2RzKHtcblxuXG4gICAgJ2lzQ29tcGV0ZW5jeUV4aXN0SW5EQicoY29tcGV0ZW5jeU5hbWUpIHtcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvLyB0aGUgcmVzcG9uc2Ugb2JqZWN0IGZvciBjbGllbnQgd2l0aCBmZWVkYmFjayBhbmQgZGF0YVxuICAgICAgLy8gY29kZXMgOlxuICAgICAgLy8gOTk5ID0gdW5rbm93biBuYW1lLlxuICAgICAgLy8gNDA0ID0gRGF0YmFzZSBsZXZlbCBwcm9ibGVtIG9yIFVua25vd24gZXJyb3Igb3IgZXhjZXB0aW9uc1xuICAgICAgLy8gMjAwID0gY29tcGV0ZW5jeSBuYW1lIGFscmVhZHkgZXhpc3RzO1xuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICB2YXIgcmVzcG9uc2U6IGFueSA9IHtcbiAgICAgICAgZmVlZGJhY2s6IFwiVW5rbm93biBlcnJvciB3aGlsZSBwcm9jZXNzaW5nIHJlcXVlc3QuIFBsZWFzZSB0cnkgYWdhaW4uXCIsXG4gICAgICAgIGNvZGU6IDQwNFxuICAgICAgfVxuXG4gICAgICB2YXIgY29tcGV0ZW5jeU5hbWVpbkRCID0gQ29tcGV0ZW5jeURCLmZpbmRPbmUoeyBcIm5hbWVcIjogY29tcGV0ZW5jeU5hbWUgfSk7XG5cblxuICAgICAgaWYgKGNvbXBldGVuY3lOYW1laW5EQiAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSAyMDA7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJUaGlzIGNvbXBldGVuY3kgaXMgYWxyZWFkeSByZWdpc3RlcmVkIGluIHRoZSBzeXN0ZW1cIjtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgfVxuICAgICAgZWxzZSBpZiAoY29tcGV0ZW5jeU5hbWVpbkRCID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgcmVzcG9uc2UuY29kZSA9IDk5OTtcbiAgICAgICAgcmVzcG9uc2UuZmVlZGJhY2sgPSBcIlRoaXMgY29tcGV0ZW5jeSBpcyBub3QgcmVnaXN0ZXJlZCBpbiB0aGUgc3lzdGVtXCI7XG4gICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgIH1cbiAgICAgIGVsc2Uge1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9XG4gICAgfSxcblxuICAgICdhZGROZXdDb21wZXRlbmN5JyhkYXRhKSB7XG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgLy8gdGhlIHJlc3BvbnNlIG9iamVjdCBmb3IgY2xpZW50IHdpdGggZmVlZGJhY2sgYW5kIGRhdGFcbiAgICAgIC8vIGNvZGVzIDpcbiAgICAgIC8vIDk5OSA9IGFjY2VzcyBkZW5pZWQuXG4gICAgICAvLyA0MDQgPSBEYXRiYXNlIGxldmVsIHByb2JsZW0gb3IgVW5rbm93biBlcnJvciBvciBleGNlcHRpb25zXG4gICAgICAvLyAyMDAgPSBzdWNjZXNzO1xuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbiAgICAgIHZhciByZXNwb25zZTogYW55ID0ge1xuICAgICAgICBmZWVkYmFjazogXCJVbmtub3duIGVycm9yIHdoaWxlIHByb2Nlc3NpbmcuIFBsZWFzZSB0cnkgYWdhaW4uXCIsXG4gICAgICAgIGNvZGU6IDQwNFxuICAgICAgfVxuXG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvLyBhY2Nlc3MgcnVsZXMgOlxuICAgICAgLy8gYWRtaW4gY2FuIGFkZCBhbnkgbnVtYmVyIG9mIGNvbXBldGVuY3lcbiAgICAgIC8vIG90aGVyIHR5cGUgb2YgdXNlcnMgd2lsbCBoYXZlIG5vIGFjY2VzcyB0byB0aGlzIGZlYXR1cmVcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvLyBzdGVwIDE6IHJlcXVlc3QgdmFsaWRhdGlvbiwgYmFzaWMgZmlsdGVyaW5nXG4gICAgICBpZiAoIXRoaXMudXNlcklkKSB7XG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSA5OTk7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJBY2Nlc3MgZGVuaWVkXCI7XG4gICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgIH1cbiAgICAgIGNoZWNrKGRhdGEsIE9iamVjdCk7XG5cbiAgICAgIC8vIHN0ZXAgMiA6IGNoZWNraW5nIERCIGFjY2VzcyByaWdodHNcblxuICAgICAgLy8gYSBmbGFnIHRvIG1ha2Ugc3VyZSB0aGlzIHJlcXVlc3RpbmcgdXNlciBoYXMgdGhlIHJpZ2h0IGFjY2VzcyB0byBtb2RpZnkgdGhpcyBkYXRhXG4gICAgICB2YXIgdXNlckhhc0FjY2Vzc1JpZ2h0cyA9IGZhbHNlO1xuXG4gICAgICB2YXIgdXNlcklzQWRtaW4gPSBmYWxzZTtcblxuICAgICAgdmFyIGRiQWNjZXNzQ2hlY2tlciA9IG5ldyBDaGVja2RiYWNjZXNzKCk7XG5cbiAgICAgIHVzZXJJc0FkbWluID0gZGJBY2Nlc3NDaGVja2VyLmlzUm9sZUFkbWluKHRoaXMudXNlcklkKTsgLy9yZXR1cm5zIHRydWUgaWYgYWRtaW5cbiAgICAgIHVzZXJIYXNBY2Nlc3NSaWdodHMgPSB1c2VySXNBZG1pbjtcblxuICAgICAgaWYgKHVzZXJIYXNBY2Nlc3NSaWdodHMgPT09IHRydWUpIHtcblxuICAgICAgICAvLyBzdGVwIDogMyB1cGRhdGluZyBkYXRhIGludG8gdGhlIERCXG4gICAgICAgIENvbXBldGVuY3lEQi5jb2xsZWN0aW9uLmluc2VydCh7XG5cbiAgICAgICAgICBuYW1lOiBkYXRhLm5hbWUsXG4gICAgICAgICAgZGVzY3JpcHRpb246IGRhdGEuZGVzY3JpcHRpb24sXG4gICAgICAgICAgY3JlYXRlZEJ5OiBNZXRlb3IudXNlcigpLmVtYWlsc1swXS5hZGRyZXNzLFxuICAgICAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKSxcblxuICAgICAgICB9KTsgLy9lbmQgaW5zZXJ0XG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSAyMDA7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJOZXcgQ29tcGV0ZW5jeSBDcmVhdGlvbiBzdWNjZXNzZnVsbCFcIjtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgfSAvLyBlbmQgaWYgaWYodXNlckhhc0FjY2Vzc1JpZ2h0cyA9PT0gdHJ1ZSlcbiAgICAgIGVsc2Uge1xuICAgICAgICAvLyBubyBBY2Nlc3MgcmlnaHRcbiAgICAgICAgcmVzcG9uc2UuY29kZSA9IDk5OTtcbiAgICAgICAgcmVzcG9uc2UuZmVlZGJhY2sgPSBcIkFjY2VzcyBkZW5pZWRcIjtcbiAgICAgIH1cbiAgICAgIHJldHVybiByZXNwb25zZTtcblxuXG5cbiAgICB9LFxuXG4gICAgJ3VwZGF0ZUNvbXBldGVuY3knKGRhdGEpIHtcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvLyB0aGUgcmVzcG9uc2Ugb2JqZWN0IGZvciBjbGllbnQgd2l0aCBmZWVkYmFjayBhbmQgZGF0YVxuICAgICAgLy8gY29kZXMgOlxuICAgICAgLy8gOTk5ID0gYWNjZXNzIGRlbmllZC5cbiAgICAgIC8vIDQwNCA9IERhdGJhc2UgbGV2ZWwgcHJvYmxlbSBvciBVbmtub3duIGVycm9yIG9yIGV4Y2VwdGlvbnNcbiAgICAgIC8vIDIwMCA9IHN1Y2Nlc3M7XG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuICAgICAgdmFyIHJlc3BvbnNlOiBhbnkgPSB7XG4gICAgICAgIGZlZWRiYWNrOiBcIlVua25vd24gZXJyb3Igd2hpbGUgcHJvY2Vzc2luZy4gUGxlYXNlIHRyeSBhZ2Fpbi5cIixcbiAgICAgICAgY29kZTogNDA0XG4gICAgICB9XG5cbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgIC8vIGFjY2VzcyBydWxlcyA6XG4gICAgICAvLyBhZG1pbiBjYW4gZWRpdCBhbnkgbnVtYmVyIG9mIGxldmVsXG4gICAgICAvLyBvdGhlciB0eXBlIG9mIHVzZXJzIHdpbGwgaGF2ZSBubyBhY2Nlc3MgdG8gdGhpcyBmZWF0dXJlXG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgLy8gc3RlcCAxOiByZXF1ZXN0IHZhbGlkYXRpb24sIGJhc2ljIGZpbHRlcmluZ1xuICAgICAgaWYgKCF0aGlzLnVzZXJJZCkge1xuICAgICAgICByZXNwb25zZS5jb2RlID0gOTk5O1xuICAgICAgICByZXNwb25zZS5mZWVkYmFjayA9IFwiQWNjZXNzIGRlbmllZFwiO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9XG4gICAgICBjaGVjayhkYXRhLCBPYmplY3QpO1xuXG4gICAgICAvLyBzdGVwIDIgOiBjaGVja2luZyBEQiBhY2Nlc3MgcmlnaHRzXG5cbiAgICAgIC8vIGEgZmxhZyB0byBtYWtlIHN1cmUgdGhpcyByZXF1ZXN0aW5nIHVzZXIgaGFzIHRoZSByaWdodCBhY2Nlc3MgdG8gbW9kaWZ5IHRoaXMgZGF0YVxuICAgICAgdmFyIHVzZXJIYXNBY2Nlc3NSaWdodHMgPSBmYWxzZTtcblxuICAgICAgdmFyIHVzZXJJc0FkbWluID0gZmFsc2U7XG5cbiAgICAgIHZhciBkYkFjY2Vzc0NoZWNrZXIgPSBuZXcgQ2hlY2tkYmFjY2VzcygpO1xuXG4gICAgICB1c2VySXNBZG1pbiA9IGRiQWNjZXNzQ2hlY2tlci5pc1JvbGVBZG1pbih0aGlzLnVzZXJJZCk7IC8vcmV0dXJucyB0cnVlIGlmIGFkbWluXG4gICAgICB1c2VySGFzQWNjZXNzUmlnaHRzID0gdXNlcklzQWRtaW47XG5cbiAgICAgIGlmICh1c2VySGFzQWNjZXNzUmlnaHRzID09PSB0cnVlKSB7XG5cbiAgICAgICAgLy8gc3RlcCA6IDMgdXBkYXRpbmcgZGF0YSBpbnRvIHRoZSBEQlxuICAgICAgICBDb21wZXRlbmN5REIuY29sbGVjdGlvbi51cGRhdGUoXG4gICAgICAgICAgZGF0YS5faWQsXG4gICAgICAgICAge1xuICAgICAgICAgICAgJHNldDpcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIG5hbWU6IGRhdGEubmFtZSxcbiAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogZGF0YS5kZXNjcmlwdGlvbixcbiAgICAgICAgICAgICAgICBjcmVhdGVkQnk6IE1ldGVvci51c2VyKCkuZW1haWxzWzBdLmFkZHJlc3MsXG4gICAgICAgICAgICAgICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpLFxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgfSk7IC8vIGVuZCB1cGRhdGVcblxuXG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSAyMDA7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJMZXZlbCBVcGRhdGUgc3VjY2Vzc2Z1bGwhXCI7XG4gICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgIH0gLy8gZW5kIGlmIGlmKHVzZXJIYXNBY2Nlc3NSaWdodHMgPT09IHRydWUpXG4gICAgICBlbHNlIHtcbiAgICAgICAgLy8gbm8gQWNjZXNzIHJpZ2h0XG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSA5OTk7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJBY2Nlc3MgZGVuaWVkXCI7XG4gICAgICB9XG4gICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgfSxcblxuICAgICdkZWxldGVDb21wZXRlbmN5JyhkYXRhKSB7XG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgLy8gdGhlIHJlc3BvbnNlIG9iamVjdCBmb3IgY2xpZW50IHdpdGggZmVlZGJhY2sgYW5kIGRhdGFcbiAgICAgIC8vIGNvZGVzIDpcbiAgICAgIC8vIDk5OSA9IGFjY2VzcyBkZW5pZWQuXG4gICAgICAvLyA0MDQgPSBEYXRiYXNlIGxldmVsIHByb2JsZW0gb3IgVW5rbm93biBlcnJvciBvciBleGNlcHRpb25zXG4gICAgICAvLyAyMDAgPSBzdWNjZXNzO1xuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbiAgICAgIHZhciByZXNwb25zZTogYW55ID0ge1xuICAgICAgICBmZWVkYmFjazogXCJVbmtub3duIGVycm9yIHdoaWxlIHByb2Nlc3NpbmcuIFBsZWFzZSB0cnkgYWdhaW4uXCIsXG4gICAgICAgIGNvZGU6IDQwNFxuICAgICAgfVxuXG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvLyBhY2Nlc3MgcnVsZXMgOlxuICAgICAgLy8gYWRtaW4gY2FuIGVkaXQgYW55IG51bWJlciBvZiBjb21wZXRlbmN5XG4gICAgICAvLyBvdGhlciB0eXBlIG9mIHVzZXJzIHdpbGwgaGF2ZSBubyBhY2Nlc3MgdG8gdGhpcyBmZWF0dXJlXG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgLy8gc3RlcCAxOiByZXF1ZXN0IHZhbGlkYXRpb24sIGJhc2ljIGZpbHRlcmluZ1xuICAgICAgaWYgKCF0aGlzLnVzZXJJZCkge1xuICAgICAgICByZXNwb25zZS5jb2RlID0gOTk5O1xuICAgICAgICByZXNwb25zZS5mZWVkYmFjayA9IFwiQWNjZXNzIGRlbmllZFwiO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9XG4gICAgICBjaGVjayhkYXRhLCBPYmplY3QpO1xuXG4gICAgICAvLyBzdGVwIDIgOiBjaGVja2luZyBEQiBhY2Nlc3MgcmlnaHRzXG5cbiAgICAgIC8vIGEgZmxhZyB0byBtYWtlIHN1cmUgdGhpcyByZXF1ZXN0aW5nIHVzZXIgaGFzIHRoZSByaWdodCBhY2Nlc3MgdG8gbW9kaWZ5IHRoaXMgZGF0YVxuICAgICAgdmFyIHVzZXJIYXNBY2Nlc3NSaWdodHMgPSBmYWxzZTtcblxuICAgICAgdmFyIHVzZXJJc0FkbWluID0gZmFsc2U7XG5cbiAgICAgIHZhciBkYkFjY2Vzc0NoZWNrZXIgPSBuZXcgQ2hlY2tkYmFjY2VzcygpO1xuXG4gICAgICB1c2VySXNBZG1pbiA9IGRiQWNjZXNzQ2hlY2tlci5pc1JvbGVBZG1pbih0aGlzLnVzZXJJZCk7IC8vcmV0dXJucyB0cnVlIGlmIGFkbWluXG4gICAgICB1c2VySGFzQWNjZXNzUmlnaHRzID0gdXNlcklzQWRtaW47XG5cbiAgICAgIGlmICh1c2VySGFzQWNjZXNzUmlnaHRzID09PSB0cnVlKSB7XG4gICAgICAgIENvbXBldGVuY3lEQi5jb2xsZWN0aW9uLnJlbW92ZShkYXRhLl9pZCk7XG5cbiAgICAgICAgcmVzcG9uc2UuY29kZSA9IDIwMDtcbiAgICAgICAgcmVzcG9uc2UuZmVlZGJhY2sgPSBcIkxldmVsIGRlbGV0ZSBzdWNjZXNzZnVsbCFcIjtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgfVxuICAgICAgZWxzZSB7XG4gICAgICAgIC8vIG5vIEFjY2VzcyByaWdodFxuICAgICAgICByZXNwb25zZS5jb2RlID0gOTk5O1xuICAgICAgICByZXNwb25zZS5mZWVkYmFjayA9IFwiQWNjZXNzIGRlbmllZFwiO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgIH0sXG5cbiAgICAnZ2V0QWxsQ29tcGV0ZW5jeU5hbWUnKCkge1xuICAgICAgcmV0dXJuIENvbXBldGVuY3lEQi5maW5kKHt9KS5mZXRjaCgpO1xuICAgIH1cblxuXG4gIH0pOyAvLyBFTkQgb2YgbWV0ZW9yIG1ldGhvZHNcblxufSAvLyBFTkQgb2YgTWV0ZW9yLmlzU2VydmVyXG4iLCIvLyBkb2NzIGZvciBtZXRlb3IgZGVmYXVsdCBtZXRob2RzIDogaHR0cDovL2RvY3MubWV0ZW9yLmNvbS9hcGkvcGFzc3dvcmRzLmh0bWxcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgQWNjb3VudHMgfSBmcm9tICdtZXRlb3IvYWNjb3VudHMtYmFzZSdcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCB7IE1ldGVvck9ic2VydmFibGUgfSBmcm9tICdtZXRlb3Itcnhqcyc7XG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjayc7XG5pbXBvcnQgeyBDaGVja2RiYWNjZXNzIH0gZnJvbSAnL3NlcnZlci9kYmFwaS90b29scy9jaGVja2RiYWNjZXNzLnRzJztcbmltcG9ydCB7IENvdXJzZURCLCBJbnN0aXR1dGVEQiwgRmFjdWx0eURCLCBQcm9maWxlREIgfSBmcm9tIFwiL2ltcG9ydHMvYXBpL2luZGV4XCI7XG5cblxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xuXG4gIE1ldGVvci5tZXRob2RzKHtcblxuXG4gICAgJ2lzQ291cnNlRXhpc3RJbkRCJyhjb3Vyc2VOYW1lLCBjYW1wdXNJRCwgZmFjdWx0eUlELCBpbnN0aXR1dGVJRCkge1xuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgIC8vIHRoZSByZXNwb25zZSBvYmplY3QgZm9yIGNsaWVudCB3aXRoIGZlZWRiYWNrIGFuZCBkYXRhXG4gICAgICAvLyBjb2RlcyA6XG4gICAgICAvLyA5OTkgPSB1bmtub3duIG5hbWUuXG4gICAgICAvLyA0MDQgPSBEYXRiYXNlIGxldmVsIHByb2JsZW0gb3IgVW5rbm93biBlcnJvciBvciBleGNlcHRpb25zXG4gICAgICAvLyAyMDAgPSBmYWN1bHR5IG5hbWUgYWxyZWFkeSBleGlzdHM7XG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgIHZhciByZXNwb25zZTogYW55ID0ge1xuICAgICAgICBmZWVkYmFjazogXCJVbmtub3duIGVycm9yIHdoaWxlIHByb2Nlc3NpbmcgcmVxdWVzdC4gUGxlYXNlIHRyeSBhZ2Fpbi5cIixcbiAgICAgICAgY29kZTogNDA0XG4gICAgICB9XG5cbiAgICAgIHZhciBjb3Vyc2VOYW1laW5EQiA9IENvdXJzZURCLmZpbmRPbmUoeyBcIm5hbWVcIjogY291cnNlTmFtZSwgXCJjYW1wdXNJRFwiOiBjYW1wdXNJRCwgXCJmYWN1bHR5SURcIjogZmFjdWx0eUlELCBcImluc3RpdHV0ZUlEXCI6IGluc3RpdHV0ZUlEIH0pO1xuXG5cbiAgICAgIGlmIChjb3Vyc2VOYW1laW5EQiAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSAyMDA7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJUaGlzIENvdXJzZSBpcyBhbHJlYWR5IHJlZ2lzdGVyZWQgaW4gdGhlIHN5c3RlbVwiO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9XG4gICAgICBlbHNlIGlmIChjb3Vyc2VOYW1laW5EQiA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSA5OTk7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJUaGlzIENvdXJzZSBpcyBub3QgcmVnaXN0ZXJlZCBpbiB0aGUgc3lzdGVtXCI7XG4gICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgIH1cbiAgICAgIGVsc2Uge1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9XG4gICAgfSxcblxuICAgICdhZGROZXdDb3Vyc2UnKGRhdGEpIHtcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvLyB0aGUgcmVzcG9uc2Ugb2JqZWN0IGZvciBjbGllbnQgd2l0aCBmZWVkYmFjayBhbmQgZGF0YVxuICAgICAgLy8gY29kZXMgOlxuICAgICAgLy8gOTk5ID0gYWNjZXNzIGRlbmllZC5cbiAgICAgIC8vIDQwNCA9IERhdGJhc2UgbGV2ZWwgcHJvYmxlbSBvciBVbmtub3duIGVycm9yIG9yIGV4Y2VwdGlvbnNcbiAgICAgIC8vIDIwMCA9IHN1Y2Nlc3M7XG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuICAgICAgdmFyIHJlc3BvbnNlOiBhbnkgPSB7XG4gICAgICAgIGZlZWRiYWNrOiBcIlVua25vd24gZXJyb3Igd2hpbGUgcHJvY2Vzc2luZy4gUGxlYXNlIHRyeSBhZ2Fpbi5cIixcbiAgICAgICAgY29kZTogNDA0XG4gICAgICB9XG5cbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgIC8vIGFjY2VzcyBydWxlcyA6XG4gICAgICAvLyBhZG1pbiBjYW4gYWRkIGFueSBudW1iZXIgb2YgZmFjdWx0eVxuICAgICAgLy8gb3RoZXIgdHlwZSBvZiB1c2VycyB3aWxsIGhhdmUgbm8gYWNjZXNzIHRvIHRoaXMgZmVhdHVyZVxuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgIC8vIHN0ZXAgMTogcmVxdWVzdCB2YWxpZGF0aW9uLCBiYXNpYyBmaWx0ZXJpbmdcbiAgICAgIGlmICghdGhpcy51c2VySWQpIHtcbiAgICAgICAgcmVzcG9uc2UuY29kZSA9IDk5OTtcbiAgICAgICAgcmVzcG9uc2UuZmVlZGJhY2sgPSBcIkFjY2VzcyBkZW5pZWRcIjtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgfVxuICAgICAgY2hlY2soZGF0YSwgT2JqZWN0KTtcblxuICAgICAgLy8gc3RlcCAyIDogY2hlY2tpbmcgREIgYWNjZXNzIHJpZ2h0c1xuXG4gICAgICAvLyBhIGZsYWcgdG8gbWFrZSBzdXJlIHRoaXMgcmVxdWVzdGluZyB1c2VyIGhhcyB0aGUgcmlnaHQgYWNjZXNzIHRvIG1vZGlmeSB0aGlzIGRhdGFcbiAgICAgIHZhciB1c2VySGFzQWNjZXNzUmlnaHRzID0gZmFsc2U7XG5cbiAgICAgIHZhciB1c2VySXNBZG1pbiA9IGZhbHNlO1xuXG4gICAgICB2YXIgZGJBY2Nlc3NDaGVja2VyID0gbmV3IENoZWNrZGJhY2Nlc3MoKTtcblxuICAgICAgdXNlcklzQWRtaW4gPSBkYkFjY2Vzc0NoZWNrZXIuaXNSb2xlQWRtaW4odGhpcy51c2VySWQpOyAvL3JldHVybnMgdHJ1ZSBpZiBhZG1pblxuICAgICAgdXNlckhhc0FjY2Vzc1JpZ2h0cyA9IHVzZXJJc0FkbWluO1xuXG4gICAgICBpZiAodXNlckhhc0FjY2Vzc1JpZ2h0cyA9PT0gdHJ1ZSkge1xuXG4gICAgICAgIC8vIHN0ZXAgOiAzIHVwZGF0aW5nIGRhdGEgaW50byB0aGUgREJcbiAgICAgICAgQ291cnNlREIuY29sbGVjdGlvbi5pbnNlcnQoe1xuXG4gICAgICAgICAgbmFtZTogZGF0YS5uYW1lLFxuICAgICAgICAgIGRlc2NyaXB0aW9uOiBkYXRhLmRlc2NyaXB0aW9uLFxuICAgICAgICAgIGNhbXB1c0lEOiBkYXRhLmNhbXB1c0lELFxuICAgICAgICAgIGZhY3VsdHlJRDogZGF0YS5mYWN1bHR5SUQsXG4gICAgICAgICAgaW5zdGl0dXRlSUQ6IGRhdGEuaW5zdGl0dXRlSUQsXG4gICAgICAgICAgY3JlYXRlZEJ5OiBNZXRlb3IudXNlcigpLmVtYWlsc1swXS5hZGRyZXNzLFxuICAgICAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKSxcblxuICAgICAgICB9KTsgLy9lbmQgaW5zZXJ0XG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSAyMDA7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJOZXcgQ291cnNlIENyZWF0aW9uIHN1Y2Nlc3NmdWxsIVwiO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9IC8vIGVuZCBpZiBpZih1c2VySGFzQWNjZXNzUmlnaHRzID09PSB0cnVlKVxuICAgICAgZWxzZSB7XG4gICAgICAgIC8vIG5vIEFjY2VzcyByaWdodFxuICAgICAgICByZXNwb25zZS5jb2RlID0gOTk5O1xuICAgICAgICByZXNwb25zZS5mZWVkYmFjayA9IFwiQWNjZXNzIGRlbmllZFwiO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuXG5cblxuICAgIH0sXG5cbiAgICAndXBkYXRlQ291cnNlJyhkYXRhKSB7XG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgLy8gdGhlIHJlc3BvbnNlIG9iamVjdCBmb3IgY2xpZW50IHdpdGggZmVlZGJhY2sgYW5kIGRhdGFcbiAgICAgIC8vIGNvZGVzIDpcbiAgICAgIC8vIDk5OSA9IGFjY2VzcyBkZW5pZWQuXG4gICAgICAvLyA0MDQgPSBEYXRiYXNlIGxldmVsIHByb2JsZW0gb3IgVW5rbm93biBlcnJvciBvciBleGNlcHRpb25zXG4gICAgICAvLyAyMDAgPSBzdWNjZXNzO1xuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbiAgICAgIHZhciByZXNwb25zZTogYW55ID0ge1xuICAgICAgICBmZWVkYmFjazogXCJVbmtub3duIGVycm9yIHdoaWxlIHByb2Nlc3NpbmcuIFBsZWFzZSB0cnkgYWdhaW4uXCIsXG4gICAgICAgIGNvZGU6IDQwNFxuICAgICAgfVxuXG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvLyBhY2Nlc3MgcnVsZXMgOlxuICAgICAgLy8gYWRtaW4gY2FuIGVkaXQgYW55IG51bWJlciBvZiBjYW1wdXNcbiAgICAgIC8vIG90aGVyIHR5cGUgb2YgdXNlcnMgd2lsbCBoYXZlIG5vIGFjY2VzcyB0byB0aGlzIGZlYXR1cmVcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvLyBzdGVwIDE6IHJlcXVlc3QgdmFsaWRhdGlvbiwgYmFzaWMgZmlsdGVyaW5nXG4gICAgICBpZiAoIXRoaXMudXNlcklkKSB7XG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSA5OTk7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJBY2Nlc3MgZGVuaWVkXCI7XG4gICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgIH1cbiAgICAgIGNoZWNrKGRhdGEsIE9iamVjdCk7XG5cbiAgICAgIC8vIHN0ZXAgMiA6IGNoZWNraW5nIERCIGFjY2VzcyByaWdodHNcblxuICAgICAgLy8gYSBmbGFnIHRvIG1ha2Ugc3VyZSB0aGlzIHJlcXVlc3RpbmcgdXNlciBoYXMgdGhlIHJpZ2h0IGFjY2VzcyB0byBtb2RpZnkgdGhpcyBkYXRhXG4gICAgICB2YXIgdXNlckhhc0FjY2Vzc1JpZ2h0cyA9IGZhbHNlO1xuXG4gICAgICB2YXIgdXNlcklzQWRtaW4gPSBmYWxzZTtcblxuICAgICAgdmFyIGRiQWNjZXNzQ2hlY2tlciA9IG5ldyBDaGVja2RiYWNjZXNzKCk7XG5cbiAgICAgIHVzZXJJc0FkbWluID0gZGJBY2Nlc3NDaGVja2VyLmlzUm9sZUFkbWluKHRoaXMudXNlcklkKTsgLy9yZXR1cm5zIHRydWUgaWYgYWRtaW5cbiAgICAgIHVzZXJIYXNBY2Nlc3NSaWdodHMgPSB1c2VySXNBZG1pbjtcblxuICAgICAgaWYgKHVzZXJIYXNBY2Nlc3NSaWdodHMgPT09IHRydWUpIHtcblxuICAgICAgICAvLyBzdGVwIDogMyB1cGRhdGluZyBkYXRhIGludG8gdGhlIERCXG4gICAgICAgIENvdXJzZURCLmNvbGxlY3Rpb24udXBkYXRlKFxuICAgICAgICAgIGRhdGEuX2lkLFxuICAgICAgICAgIHtcbiAgICAgICAgICAgICRzZXQ6XG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBuYW1lOiBkYXRhLm5hbWUsXG4gICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IGRhdGEuZGVzY3JpcHRpb24sXG4gICAgICAgICAgICAgICAgY2FtcHVzSUQ6IGRhdGEuY2FtcHVzSUQsXG4gICAgICAgICAgICAgICAgZmFjdWx0eUlEOiBkYXRhLmZhY3VsdHlJRCxcbiAgICAgICAgICAgICAgICBpbnN0aXR1dGVJRDogZGF0YS5pbnN0aXR1dGVJRCxcbiAgICAgICAgICAgICAgICBjcmVhdGVkQnk6IE1ldGVvci51c2VyKCkuZW1haWxzWzBdLmFkZHJlc3MsXG4gICAgICAgICAgICAgICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpLFxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgfSk7IC8vIGVuZCB1cGRhdGVcblxuXG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSAyMDA7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJDb3Vyc2UgVXBkYXRlIHN1Y2Nlc3NmdWxsIVwiO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9IC8vIGVuZCBpZiBpZih1c2VySGFzQWNjZXNzUmlnaHRzID09PSB0cnVlKVxuICAgICAgZWxzZSB7XG4gICAgICAgIC8vIG5vIEFjY2VzcyByaWdodFxuICAgICAgICByZXNwb25zZS5jb2RlID0gOTk5O1xuICAgICAgICByZXNwb25zZS5mZWVkYmFjayA9IFwiQWNjZXNzIGRlbmllZFwiO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgIH0sXG5cbiAgICAnZGVsZXRlQ291cnNlJyhkYXRhKSB7XG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgLy8gdGhlIHJlc3BvbnNlIG9iamVjdCBmb3IgY2xpZW50IHdpdGggZmVlZGJhY2sgYW5kIGRhdGFcbiAgICAgIC8vIGNvZGVzIDpcbiAgICAgIC8vIDk5OSA9IGFjY2VzcyBkZW5pZWQuXG4gICAgICAvLyA0MDQgPSBEYXRiYXNlIGxldmVsIHByb2JsZW0gb3IgVW5rbm93biBlcnJvciBvciBleGNlcHRpb25zXG4gICAgICAvLyAyMDAgPSBzdWNjZXNzO1xuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbiAgICAgIHZhciByZXNwb25zZTogYW55ID0ge1xuICAgICAgICBmZWVkYmFjazogXCJVbmtub3duIGVycm9yIHdoaWxlIHByb2Nlc3NpbmcuIFBsZWFzZSB0cnkgYWdhaW4uXCIsXG4gICAgICAgIGNvZGU6IDQwNFxuICAgICAgfVxuXG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvLyBhY2Nlc3MgcnVsZXMgOlxuICAgICAgLy8gYWRtaW4gY2FuIGVkaXQgYW55IG51bWJlciBvZiBjYW1wdXNcbiAgICAgIC8vIG90aGVyIHR5cGUgb2YgdXNlcnMgd2lsbCBoYXZlIG5vIGFjY2VzcyB0byB0aGlzIGZlYXR1cmVcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvLyBzdGVwIDE6IHJlcXVlc3QgdmFsaWRhdGlvbiwgYmFzaWMgZmlsdGVyaW5nXG4gICAgICBpZiAoIXRoaXMudXNlcklkKSB7XG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSA5OTk7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJBY2Nlc3MgZGVuaWVkXCI7XG4gICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgIH1cbiAgICAgIGNoZWNrKGRhdGEsIE9iamVjdCk7XG5cbiAgICAgIC8vIHN0ZXAgMiA6IGNoZWNraW5nIERCIGFjY2VzcyByaWdodHNcblxuICAgICAgLy8gYSBmbGFnIHRvIG1ha2Ugc3VyZSB0aGlzIHJlcXVlc3RpbmcgdXNlciBoYXMgdGhlIHJpZ2h0IGFjY2VzcyB0byBtb2RpZnkgdGhpcyBkYXRhXG4gICAgICB2YXIgdXNlckhhc0FjY2Vzc1JpZ2h0cyA9IGZhbHNlO1xuXG4gICAgICB2YXIgdXNlcklzQWRtaW4gPSBmYWxzZTtcblxuICAgICAgdmFyIGRiQWNjZXNzQ2hlY2tlciA9IG5ldyBDaGVja2RiYWNjZXNzKCk7XG5cbiAgICAgIHVzZXJJc0FkbWluID0gZGJBY2Nlc3NDaGVja2VyLmlzUm9sZUFkbWluKHRoaXMudXNlcklkKTsgLy9yZXR1cm5zIHRydWUgaWYgYWRtaW5cbiAgICAgIHVzZXJIYXNBY2Nlc3NSaWdodHMgPSB1c2VySXNBZG1pbjtcblxuICAgICAgaWYgKHVzZXJIYXNBY2Nlc3NSaWdodHMgPT09IHRydWUpIHtcbiAgICAgICAgQ291cnNlREIuY29sbGVjdGlvbi5yZW1vdmUoZGF0YS5faWQpO1xuXG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSAyMDA7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJDb3Vyc2UgZGVsZXRlIHN1Y2Nlc3NmdWxsIVwiO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9XG4gICAgICBlbHNlIHtcbiAgICAgICAgLy8gbm8gQWNjZXNzIHJpZ2h0XG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSA5OTk7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJBY2Nlc3MgZGVuaWVkXCI7XG4gICAgICB9XG4gICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgfVxuXG4gIH0pOyAvLyBFTkQgb2YgbWV0ZW9yIG1ldGhvZHNcblxufSAvLyBFTkQgb2YgTWV0ZW9yLmlzU2VydmVyXG4iLCIvLyBkb2NzIGZvciBtZXRlb3IgZGVmYXVsdCBtZXRob2RzIDogaHR0cDovL2RvY3MubWV0ZW9yLmNvbS9hcGkvcGFzc3dvcmRzLmh0bWxcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgQWNjb3VudHMgfSBmcm9tICdtZXRlb3IvYWNjb3VudHMtYmFzZSdcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCB7IE1ldGVvck9ic2VydmFibGUgfSBmcm9tICdtZXRlb3Itcnhqcyc7XG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjayc7XG5pbXBvcnQgeyBDaGVja2RiYWNjZXNzIH0gZnJvbSAnL3NlcnZlci9kYmFwaS90b29scy9jaGVja2RiYWNjZXNzLnRzJztcbmltcG9ydCB7IEZhY3VsdHlEQiwgUHJvZmlsZURCLCBJbnN0aXR1dGVEQiB9IGZyb20gXCIvaW1wb3J0cy9hcGkvaW5kZXhcIjtcblxuXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG5cbiAgTWV0ZW9yLm1ldGhvZHMoe1xuXG5cbiAgICAnaXNGYWN1bHR5RXhpc3RJbkRCJyhmYWN1bHR5TmFtZSwgY2FtcHVzSUQpIHtcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvLyB0aGUgcmVzcG9uc2Ugb2JqZWN0IGZvciBjbGllbnQgd2l0aCBmZWVkYmFjayBhbmQgZGF0YVxuICAgICAgLy8gY29kZXMgOlxuICAgICAgLy8gOTk5ID0gdW5rbm93biBuYW1lLlxuICAgICAgLy8gNDA0ID0gRGF0YmFzZSBsZXZlbCBwcm9ibGVtIG9yIFVua25vd24gZXJyb3Igb3IgZXhjZXB0aW9uc1xuICAgICAgLy8gMjAwID0gZmFjdWx0eSBuYW1lIGFscmVhZHkgZXhpc3RzO1xuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICB2YXIgcmVzcG9uc2U6IGFueSA9IHtcbiAgICAgICAgZmVlZGJhY2s6IFwiVW5rbm93biBlcnJvciB3aGlsZSBwcm9jZXNzaW5nIHJlcXVlc3QuIFBsZWFzZSB0cnkgYWdhaW4uXCIsXG4gICAgICAgIGNvZGU6IDQwNFxuICAgICAgfVxuXG4gICAgICB2YXIgZmFjbHV0eU5hbWVpbkRCID0gRmFjdWx0eURCLmZpbmRPbmUoeyBcIm5hbWVcIjogZmFjdWx0eU5hbWUsIFwiY2FtcHVzSURcIjogY2FtcHVzSUQgfSk7XG5cblxuICAgICAgaWYgKGZhY2x1dHlOYW1laW5EQiAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSAyMDA7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJUaGlzIEZhY3VsdHkgaXMgYWxyZWFkeSByZWdpc3RlcmVkIGluIHRoZSBzeXN0ZW1cIjtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgfVxuICAgICAgZWxzZSBpZiAoZmFjbHV0eU5hbWVpbkRCID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgcmVzcG9uc2UuY29kZSA9IDk5OTtcbiAgICAgICAgcmVzcG9uc2UuZmVlZGJhY2sgPSBcIlRoaXMgRmFjdWx0eSBpcyBub3QgcmVnaXN0ZXJlZCBpbiB0aGUgc3lzdGVtXCI7XG4gICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgIH1cbiAgICAgIGVsc2Uge1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9XG4gICAgfSxcblxuICAgICdhZGROZXdGYWN1bHR5JyhkYXRhKSB7XG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgLy8gdGhlIHJlc3BvbnNlIG9iamVjdCBmb3IgY2xpZW50IHdpdGggZmVlZGJhY2sgYW5kIGRhdGFcbiAgICAgIC8vIGNvZGVzIDpcbiAgICAgIC8vIDk5OSA9IGFjY2VzcyBkZW5pZWQuXG4gICAgICAvLyA0MDQgPSBEYXRiYXNlIGxldmVsIHByb2JsZW0gb3IgVW5rbm93biBlcnJvciBvciBleGNlcHRpb25zXG4gICAgICAvLyAyMDAgPSBzdWNjZXNzO1xuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbiAgICAgIHZhciByZXNwb25zZTogYW55ID0ge1xuICAgICAgICBmZWVkYmFjazogXCJVbmtub3duIGVycm9yIHdoaWxlIHByb2Nlc3NpbmcuIFBsZWFzZSB0cnkgYWdhaW4uXCIsXG4gICAgICAgIGNvZGU6IDQwNFxuICAgICAgfVxuXG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvLyBhY2Nlc3MgcnVsZXMgOlxuICAgICAgLy8gYWRtaW4gY2FuIGFkZCBhbnkgbnVtYmVyIG9mIGZhY3VsdHlcbiAgICAgIC8vIG90aGVyIHR5cGUgb2YgdXNlcnMgd2lsbCBoYXZlIG5vIGFjY2VzcyB0byB0aGlzIGZlYXR1cmVcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvLyBzdGVwIDE6IHJlcXVlc3QgdmFsaWRhdGlvbiwgYmFzaWMgZmlsdGVyaW5nXG4gICAgICBpZiAoIXRoaXMudXNlcklkKSB7XG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSA5OTk7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJBY2Nlc3MgZGVuaWVkXCI7XG4gICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgIH1cbiAgICAgIGNoZWNrKGRhdGEsIE9iamVjdCk7XG5cbiAgICAgIC8vIHN0ZXAgMiA6IGNoZWNraW5nIERCIGFjY2VzcyByaWdodHNcblxuICAgICAgLy8gYSBmbGFnIHRvIG1ha2Ugc3VyZSB0aGlzIHJlcXVlc3RpbmcgdXNlciBoYXMgdGhlIHJpZ2h0IGFjY2VzcyB0byBtb2RpZnkgdGhpcyBkYXRhXG4gICAgICB2YXIgdXNlckhhc0FjY2Vzc1JpZ2h0cyA9IGZhbHNlO1xuXG4gICAgICB2YXIgdXNlcklzQWRtaW4gPSBmYWxzZTtcblxuICAgICAgdmFyIGRiQWNjZXNzQ2hlY2tlciA9IG5ldyBDaGVja2RiYWNjZXNzKCk7XG5cbiAgICAgIHVzZXJJc0FkbWluID0gZGJBY2Nlc3NDaGVja2VyLmlzUm9sZUFkbWluKHRoaXMudXNlcklkKTsgLy9yZXR1cm5zIHRydWUgaWYgYWRtaW5cbiAgICAgIHVzZXJIYXNBY2Nlc3NSaWdodHMgPSB1c2VySXNBZG1pbjtcblxuICAgICAgaWYgKHVzZXJIYXNBY2Nlc3NSaWdodHMgPT09IHRydWUpIHtcblxuICAgICAgICAvLyBzdGVwIDogMyB1cGRhdGluZyBkYXRhIGludG8gdGhlIERCXG4gICAgICAgIEZhY3VsdHlEQi5jb2xsZWN0aW9uLmluc2VydCh7XG5cbiAgICAgICAgICBuYW1lOiBkYXRhLm5hbWUsXG4gICAgICAgICAgZGVzY3JpcHRpb246IGRhdGEuZGVzY3JpcHRpb24sXG4gICAgICAgICAgY2FtcHVzSUQ6IGRhdGEuY2FtcHVzSUQsXG4gICAgICAgICAgY3JlYXRlZEJ5OiBNZXRlb3IudXNlcigpLmVtYWlsc1swXS5hZGRyZXNzLFxuICAgICAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKSxcblxuICAgICAgICB9KTsgLy9lbmQgaW5zZXJ0XG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSAyMDA7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJOZXcgRmFjdWx0eSBDcmVhdGlvbiBzdWNjZXNzZnVsIVwiO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9IC8vIGVuZCBpZiBpZih1c2VySGFzQWNjZXNzUmlnaHRzID09PSB0cnVlKVxuICAgICAgZWxzZSB7XG4gICAgICAgIC8vIG5vIEFjY2VzcyByaWdodFxuICAgICAgICByZXNwb25zZS5jb2RlID0gOTk5O1xuICAgICAgICByZXNwb25zZS5mZWVkYmFjayA9IFwiQWNjZXNzIGRlbmllZFwiO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuXG5cblxuICAgIH0sXG5cbiAgICAndXBkYXRlRmFjdWx0eScoZGF0YSkge1xuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgIC8vIHRoZSByZXNwb25zZSBvYmplY3QgZm9yIGNsaWVudCB3aXRoIGZlZWRiYWNrIGFuZCBkYXRhXG4gICAgICAvLyBjb2RlcyA6XG4gICAgICAvLyA5OTkgPSBhY2Nlc3MgZGVuaWVkLlxuICAgICAgLy8gNDA0ID0gRGF0YmFzZSBsZXZlbCBwcm9ibGVtIG9yIFVua25vd24gZXJyb3Igb3IgZXhjZXB0aW9uc1xuICAgICAgLy8gMjAwID0gc3VjY2VzcztcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4gICAgICB2YXIgcmVzcG9uc2U6IGFueSA9IHtcbiAgICAgICAgZmVlZGJhY2s6IFwiVW5rbm93biBlcnJvciB3aGlsZSBwcm9jZXNzaW5nLiBQbGVhc2UgdHJ5IGFnYWluLlwiLFxuICAgICAgICBjb2RlOiA0MDRcbiAgICAgIH1cblxuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgLy8gYWNjZXNzIHJ1bGVzIDpcbiAgICAgIC8vIGFkbWluIGNhbiBlZGl0IGFueSBudW1iZXIgb2YgY2FtcHVzXG4gICAgICAvLyBvdGhlciB0eXBlIG9mIHVzZXJzIHdpbGwgaGF2ZSBubyBhY2Nlc3MgdG8gdGhpcyBmZWF0dXJlXG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgLy8gc3RlcCAxOiByZXF1ZXN0IHZhbGlkYXRpb24sIGJhc2ljIGZpbHRlcmluZ1xuICAgICAgaWYgKCF0aGlzLnVzZXJJZCkge1xuICAgICAgICByZXNwb25zZS5jb2RlID0gOTk5O1xuICAgICAgICByZXNwb25zZS5mZWVkYmFjayA9IFwiQWNjZXNzIGRlbmllZFwiO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9XG4gICAgICBjaGVjayhkYXRhLCBPYmplY3QpO1xuXG4gICAgICAvLyBzdGVwIDIgOiBjaGVja2luZyBEQiBhY2Nlc3MgcmlnaHRzXG5cbiAgICAgIC8vIGEgZmxhZyB0byBtYWtlIHN1cmUgdGhpcyByZXF1ZXN0aW5nIHVzZXIgaGFzIHRoZSByaWdodCBhY2Nlc3MgdG8gbW9kaWZ5IHRoaXMgZGF0YVxuICAgICAgdmFyIHVzZXJIYXNBY2Nlc3NSaWdodHMgPSBmYWxzZTtcblxuICAgICAgdmFyIHVzZXJJc0FkbWluID0gZmFsc2U7XG5cbiAgICAgIHZhciBkYkFjY2Vzc0NoZWNrZXIgPSBuZXcgQ2hlY2tkYmFjY2VzcygpO1xuXG4gICAgICB1c2VySXNBZG1pbiA9IGRiQWNjZXNzQ2hlY2tlci5pc1JvbGVBZG1pbih0aGlzLnVzZXJJZCk7IC8vcmV0dXJucyB0cnVlIGlmIGFkbWluXG4gICAgICB1c2VySGFzQWNjZXNzUmlnaHRzID0gdXNlcklzQWRtaW47XG5cbiAgICAgIGlmICh1c2VySGFzQWNjZXNzUmlnaHRzID09PSB0cnVlKSB7XG5cbiAgICAgICAgLy8gc3RlcCA6IDMgdXBkYXRpbmcgZGF0YSBpbnRvIHRoZSBEQlxuICAgICAgICBGYWN1bHR5REIuY29sbGVjdGlvbi51cGRhdGUoXG4gICAgICAgICAgZGF0YS5faWQsXG4gICAgICAgICAge1xuICAgICAgICAgICAgJHNldDpcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIG5hbWU6IGRhdGEubmFtZSxcbiAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogZGF0YS5kZXNjcmlwdGlvbixcbiAgICAgICAgICAgICAgICBjYW1wdXNJRDogZGF0YS5jYW1wdXNJRCxcbiAgICAgICAgICAgICAgICBjcmVhdGVkQnk6IE1ldGVvci51c2VyKCkuZW1haWxzWzBdLmFkZHJlc3MsXG4gICAgICAgICAgICAgICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpLFxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgfSk7IC8vIGVuZCB1cGRhdGVcblxuXG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSAyMDA7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJDYW1wdXMgVXBkYXRlIHN1Y2Nlc3NmdWxsIVwiO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9IC8vIGVuZCBpZiBpZih1c2VySGFzQWNjZXNzUmlnaHRzID09PSB0cnVlKVxuICAgICAgZWxzZSB7XG4gICAgICAgIC8vIG5vIEFjY2VzcyByaWdodFxuICAgICAgICByZXNwb25zZS5jb2RlID0gOTk5O1xuICAgICAgICByZXNwb25zZS5mZWVkYmFjayA9IFwiQWNjZXNzIGRlbmllZFwiO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgIH0sXG5cbiAgICAnaXNGYWN1bHR5SGFzSW5zdGl0dXRlJyhmYWN1bHR5SUQpIHtcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvLyB0aGUgcmVzcG9uc2Ugb2JqZWN0IGZvciBjbGllbnQgd2l0aCBmZWVkYmFjayBhbmQgZGF0YVxuICAgICAgLy8gY29kZXMgOlxuICAgICAgLy8gOTk5ID0gZmFjdWx0eSBoYXMgaW5zdGl0dXRlLlxuICAgICAgLy8gNDA0ID0gRGF0YmFzZSBsZXZlbCBwcm9ibGVtIG9yIFVua25vd24gZXJyb3Igb3IgZXhjZXB0aW9uc1xuICAgICAgLy8gMjAwID0gZmFjdWx0eSBoYXMgbm8gaW5zdGl0dXRlXG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuICAgICAgdmFyIHJlc3BvbnNlOiBhbnkgPSB7XG4gICAgICAgIGZlZWRiYWNrOiBcIlVua25vd24gZXJyb3Igd2hpbGUgcHJvY2Vzc2luZyByZXF1ZXN0LiBQbGVhc2UgdHJ5IGFnYWluLlwiLFxuICAgICAgICBjb2RlOiA0MDRcbiAgICAgIH1cblxuICAgICAgdmFyIG5vT2ZJbnN0aXR1dGUgPSBJbnN0aXR1dGVEQi5jb2xsZWN0aW9uLmZpbmQoeyBcImZhY3VsdHlJRFwiOiBmYWN1bHR5SUQgfSkuY291bnQoKTtcblxuICAgICAgaWYgKG5vT2ZJbnN0aXR1dGUgIT09IHVuZGVmaW5lZCAmJiBub09mSW5zdGl0dXRlID4gMCkge1xuICAgICAgICByZXNwb25zZS5jb2RlID0gOTk5O1xuICAgICAgICByZXNwb25zZS5mZWVkYmFjayA9IFwiVGhpcyBGYWN1bHR5IGhhcyBJbnN0aXR1dGUuIERlbGV0ZSBpbnN0aXR1dGVzIG9mIHRoaXMgZmFjdWx0eSBmaXJzdC5cIjtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgfVxuICAgICAgZWxzZSBpZiAobm9PZkluc3RpdHV0ZSA9PT0gdW5kZWZpbmVkIHx8IG5vT2ZJbnN0aXR1dGUgPT09IDApIHtcbiAgICAgICAgcmVzcG9uc2UuY29kZSA9IDIwMDtcbiAgICAgICAgcmVzcG9uc2UuZmVlZGJhY2sgPSBcIlRoaXMgRmFjdWx0eSBkb2Vzbid0IGhhdmUgYW55IGluc3RpdHV0ZVwiO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9XG4gICAgICBlbHNlIHtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgfVxuICAgIH0sXG5cbiAgICAnZGVsZXRlRmFjdWx0eScoZGF0YSkge1xuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgIC8vIHRoZSByZXNwb25zZSBvYmplY3QgZm9yIGNsaWVudCB3aXRoIGZlZWRiYWNrIGFuZCBkYXRhXG4gICAgICAvLyBjb2RlcyA6XG4gICAgICAvLyA5OTkgPSBhY2Nlc3MgZGVuaWVkLlxuICAgICAgLy8gNDA0ID0gRGF0YmFzZSBsZXZlbCBwcm9ibGVtIG9yIFVua25vd24gZXJyb3Igb3IgZXhjZXB0aW9uc1xuICAgICAgLy8gMjAwID0gc3VjY2VzcztcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4gICAgICB2YXIgcmVzcG9uc2U6IGFueSA9IHtcbiAgICAgICAgZmVlZGJhY2s6IFwiVW5rbm93biBlcnJvciB3aGlsZSBwcm9jZXNzaW5nLiBQbGVhc2UgdHJ5IGFnYWluLlwiLFxuICAgICAgICBjb2RlOiA0MDRcbiAgICAgIH1cblxuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgLy8gYWNjZXNzIHJ1bGVzIDpcbiAgICAgIC8vIGFkbWluIGNhbiBlZGl0IGFueSBudW1iZXIgb2YgY2FtcHVzXG4gICAgICAvLyBvdGhlciB0eXBlIG9mIHVzZXJzIHdpbGwgaGF2ZSBubyBhY2Nlc3MgdG8gdGhpcyBmZWF0dXJlXG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgLy8gc3RlcCAxOiByZXF1ZXN0IHZhbGlkYXRpb24sIGJhc2ljIGZpbHRlcmluZ1xuICAgICAgaWYgKCF0aGlzLnVzZXJJZCkge1xuICAgICAgICByZXNwb25zZS5jb2RlID0gOTk5O1xuICAgICAgICByZXNwb25zZS5mZWVkYmFjayA9IFwiQWNjZXNzIGRlbmllZFwiO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9XG4gICAgICBjaGVjayhkYXRhLCBPYmplY3QpO1xuXG4gICAgICAvLyBzdGVwIDIgOiBjaGVja2luZyBEQiBhY2Nlc3MgcmlnaHRzXG5cbiAgICAgIC8vIGEgZmxhZyB0byBtYWtlIHN1cmUgdGhpcyByZXF1ZXN0aW5nIHVzZXIgaGFzIHRoZSByaWdodCBhY2Nlc3MgdG8gbW9kaWZ5IHRoaXMgZGF0YVxuICAgICAgdmFyIHVzZXJIYXNBY2Nlc3NSaWdodHMgPSBmYWxzZTtcblxuICAgICAgdmFyIHVzZXJJc0FkbWluID0gZmFsc2U7XG5cbiAgICAgIHZhciBkYkFjY2Vzc0NoZWNrZXIgPSBuZXcgQ2hlY2tkYmFjY2VzcygpO1xuXG4gICAgICB1c2VySXNBZG1pbiA9IGRiQWNjZXNzQ2hlY2tlci5pc1JvbGVBZG1pbih0aGlzLnVzZXJJZCk7IC8vcmV0dXJucyB0cnVlIGlmIGFkbWluXG4gICAgICB1c2VySGFzQWNjZXNzUmlnaHRzID0gdXNlcklzQWRtaW47XG5cbiAgICAgIGlmICh1c2VySGFzQWNjZXNzUmlnaHRzID09PSB0cnVlKSB7XG4gICAgICAgIEZhY3VsdHlEQi5jb2xsZWN0aW9uLnJlbW92ZShkYXRhLl9pZCk7XG5cbiAgICAgICAgcmVzcG9uc2UuY29kZSA9IDIwMDtcbiAgICAgICAgcmVzcG9uc2UuZmVlZGJhY2sgPSBcIkNhbXB1cyBkZWxldGUgc3VjY2Vzc2Z1bGwhXCI7XG4gICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgIH1cbiAgICAgIGVsc2Uge1xuICAgICAgICAvLyBubyBBY2Nlc3MgcmlnaHRcbiAgICAgICAgcmVzcG9uc2UuY29kZSA9IDk5OTtcbiAgICAgICAgcmVzcG9uc2UuZmVlZGJhY2sgPSBcIkFjY2VzcyBkZW5pZWRcIjtcbiAgICAgIH1cbiAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICB9XG5cbiAgfSk7IC8vIEVORCBvZiBtZXRlb3IgbWV0aG9kc1xuXG59IC8vIEVORCBvZiBNZXRlb3IuaXNTZXJ2ZXJcbiIsIi8vIGRvY3MgZm9yIG1ldGVvciBkZWZhdWx0IG1ldGhvZHMgOiBodHRwOi8vZG9jcy5tZXRlb3IuY29tL2FwaS9wYXNzd29yZHMuaHRtbFxuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBBY2NvdW50cyB9IGZyb20gJ21ldGVvci9hY2NvdW50cy1iYXNlJ1xuaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IHsgTWV0ZW9yT2JzZXJ2YWJsZSB9IGZyb20gJ21ldGVvci1yeGpzJztcbmltcG9ydCB7IGNoZWNrIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJztcbmltcG9ydCB7IENoZWNrZGJhY2Nlc3MgfSBmcm9tICcvc2VydmVyL2RiYXBpL3Rvb2xzL2NoZWNrZGJhY2Nlc3MudHMnO1xuaW1wb3J0IHsgSW5zdGl0dXRlREIsIEZhY3VsdHlEQiwgUHJvZmlsZURCLCBDb3Vyc2VEQiB9IGZyb20gXCIvaW1wb3J0cy9hcGkvaW5kZXhcIjtcblxuXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG5cbiAgTWV0ZW9yLm1ldGhvZHMoe1xuXG5cbiAgICAnaXNJbnN0aXR1dGVFeGlzdEluREInKGluc3RpdHV0ZU5hbWUsIGNhbXB1c0lELCBmYWN1bHR5SUQpIHtcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvLyB0aGUgcmVzcG9uc2Ugb2JqZWN0IGZvciBjbGllbnQgd2l0aCBmZWVkYmFjayBhbmQgZGF0YVxuICAgICAgLy8gY29kZXMgOlxuICAgICAgLy8gOTk5ID0gdW5rbm93biBuYW1lLlxuICAgICAgLy8gNDA0ID0gRGF0YmFzZSBsZXZlbCBwcm9ibGVtIG9yIFVua25vd24gZXJyb3Igb3IgZXhjZXB0aW9uc1xuICAgICAgLy8gMjAwID0gZmFjdWx0eSBuYW1lIGFscmVhZHkgZXhpc3RzO1xuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICB2YXIgcmVzcG9uc2U6IGFueSA9IHtcbiAgICAgICAgZmVlZGJhY2s6IFwiVW5rbm93biBlcnJvciB3aGlsZSBwcm9jZXNzaW5nIHJlcXVlc3QuIFBsZWFzZSB0cnkgYWdhaW4uXCIsXG4gICAgICAgIGNvZGU6IDQwNFxuICAgICAgfVxuXG4gICAgICB2YXIgaW5zdGl0dXRlTmFtZWluREIgPSBJbnN0aXR1dGVEQi5maW5kT25lKHsgXCJuYW1lXCI6IGluc3RpdHV0ZU5hbWUsIFwiY2FtcHVzSURcIjogY2FtcHVzSUQsIFwiZmFjdWx0eUlEXCI6IGZhY3VsdHlJRCB9KTtcblxuXG4gICAgICBpZiAoaW5zdGl0dXRlTmFtZWluREIgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICByZXNwb25zZS5jb2RlID0gMjAwO1xuICAgICAgICByZXNwb25zZS5mZWVkYmFjayA9IFwiVGhpcyBJbnN0aXR1dGUgaXMgYWxyZWFkeSByZWdpc3RlcmVkIGluIHRoZSBzeXN0ZW1cIjtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgfVxuICAgICAgZWxzZSBpZiAoaW5zdGl0dXRlTmFtZWluREIgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICByZXNwb25zZS5jb2RlID0gOTk5O1xuICAgICAgICByZXNwb25zZS5mZWVkYmFjayA9IFwiVGhpcyBJbnN0aXR1dGUgaXMgbm90IHJlZ2lzdGVyZWQgaW4gdGhlIHN5c3RlbVwiO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9XG4gICAgICBlbHNlIHtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgfVxuICAgIH0sXG5cbiAgICAnYWRkTmV3SW5zdGl0dXRlJyhkYXRhKSB7XG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgLy8gdGhlIHJlc3BvbnNlIG9iamVjdCBmb3IgY2xpZW50IHdpdGggZmVlZGJhY2sgYW5kIGRhdGFcbiAgICAgIC8vIGNvZGVzIDpcbiAgICAgIC8vIDk5OSA9IGFjY2VzcyBkZW5pZWQuXG4gICAgICAvLyA0MDQgPSBEYXRiYXNlIGxldmVsIHByb2JsZW0gb3IgVW5rbm93biBlcnJvciBvciBleGNlcHRpb25zXG4gICAgICAvLyAyMDAgPSBzdWNjZXNzO1xuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbiAgICAgIHZhciByZXNwb25zZTogYW55ID0ge1xuICAgICAgICBmZWVkYmFjazogXCJVbmtub3duIGVycm9yIHdoaWxlIHByb2Nlc3NpbmcuIFBsZWFzZSB0cnkgYWdhaW4uXCIsXG4gICAgICAgIGNvZGU6IDQwNFxuICAgICAgfVxuXG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvLyBhY2Nlc3MgcnVsZXMgOlxuICAgICAgLy8gYWRtaW4gY2FuIGFkZCBhbnkgbnVtYmVyIG9mIGZhY3VsdHlcbiAgICAgIC8vIG90aGVyIHR5cGUgb2YgdXNlcnMgd2lsbCBoYXZlIG5vIGFjY2VzcyB0byB0aGlzIGZlYXR1cmVcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvLyBzdGVwIDE6IHJlcXVlc3QgdmFsaWRhdGlvbiwgYmFzaWMgZmlsdGVyaW5nXG4gICAgICBpZiAoIXRoaXMudXNlcklkKSB7XG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSA5OTk7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJBY2Nlc3MgZGVuaWVkXCI7XG4gICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgIH1cbiAgICAgIGNoZWNrKGRhdGEsIE9iamVjdCk7XG5cbiAgICAgIC8vIHN0ZXAgMiA6IGNoZWNraW5nIERCIGFjY2VzcyByaWdodHNcblxuICAgICAgLy8gYSBmbGFnIHRvIG1ha2Ugc3VyZSB0aGlzIHJlcXVlc3RpbmcgdXNlciBoYXMgdGhlIHJpZ2h0IGFjY2VzcyB0byBtb2RpZnkgdGhpcyBkYXRhXG4gICAgICB2YXIgdXNlckhhc0FjY2Vzc1JpZ2h0cyA9IGZhbHNlO1xuXG4gICAgICB2YXIgdXNlcklzQWRtaW4gPSBmYWxzZTtcblxuICAgICAgdmFyIGRiQWNjZXNzQ2hlY2tlciA9IG5ldyBDaGVja2RiYWNjZXNzKCk7XG5cbiAgICAgIHVzZXJJc0FkbWluID0gZGJBY2Nlc3NDaGVja2VyLmlzUm9sZUFkbWluKHRoaXMudXNlcklkKTsgLy9yZXR1cm5zIHRydWUgaWYgYWRtaW5cbiAgICAgIHVzZXJIYXNBY2Nlc3NSaWdodHMgPSB1c2VySXNBZG1pbjtcblxuICAgICAgaWYgKHVzZXJIYXNBY2Nlc3NSaWdodHMgPT09IHRydWUpIHtcblxuICAgICAgICAvLyBzdGVwIDogMyB1cGRhdGluZyBkYXRhIGludG8gdGhlIERCXG4gICAgICAgIEluc3RpdHV0ZURCLmNvbGxlY3Rpb24uaW5zZXJ0KHtcblxuICAgICAgICAgIG5hbWU6IGRhdGEubmFtZSxcbiAgICAgICAgICBkZXNjcmlwdGlvbjogZGF0YS5kZXNjcmlwdGlvbixcbiAgICAgICAgICBjYW1wdXNJRDogZGF0YS5jYW1wdXNJRCxcbiAgICAgICAgICBmYWN1bHR5SUQ6IGRhdGEuZmFjdWx0eUlELFxuICAgICAgICAgIGNyZWF0ZWRCeTogTWV0ZW9yLnVzZXIoKS5lbWFpbHNbMF0uYWRkcmVzcyxcbiAgICAgICAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKCksXG5cbiAgICAgICAgfSk7IC8vZW5kIGluc2VydFxuICAgICAgICByZXNwb25zZS5jb2RlID0gMjAwO1xuICAgICAgICByZXNwb25zZS5mZWVkYmFjayA9IFwiTmV3IEluc3RpdHV0ZSBDcmVhdGlvbiBzdWNjZXNzZnVsbCFcIjtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgfSAvLyBlbmQgaWYgaWYodXNlckhhc0FjY2Vzc1JpZ2h0cyA9PT0gdHJ1ZSlcbiAgICAgIGVsc2Uge1xuICAgICAgICAvLyBubyBBY2Nlc3MgcmlnaHRcbiAgICAgICAgcmVzcG9uc2UuY29kZSA9IDk5OTtcbiAgICAgICAgcmVzcG9uc2UuZmVlZGJhY2sgPSBcIkFjY2VzcyBkZW5pZWRcIjtcbiAgICAgIH1cbiAgICAgIHJldHVybiByZXNwb25zZTtcblxuXG5cbiAgICB9LFxuXG4gICAgJ3VwZGF0ZUluc3RpdHV0ZScoZGF0YSkge1xuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgIC8vIHRoZSByZXNwb25zZSBvYmplY3QgZm9yIGNsaWVudCB3aXRoIGZlZWRiYWNrIGFuZCBkYXRhXG4gICAgICAvLyBjb2RlcyA6XG4gICAgICAvLyA5OTkgPSBhY2Nlc3MgZGVuaWVkLlxuICAgICAgLy8gNDA0ID0gRGF0YmFzZSBsZXZlbCBwcm9ibGVtIG9yIFVua25vd24gZXJyb3Igb3IgZXhjZXB0aW9uc1xuICAgICAgLy8gMjAwID0gc3VjY2VzcztcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4gICAgICB2YXIgcmVzcG9uc2U6IGFueSA9IHtcbiAgICAgICAgZmVlZGJhY2s6IFwiVW5rbm93biBlcnJvciB3aGlsZSBwcm9jZXNzaW5nLiBQbGVhc2UgdHJ5IGFnYWluLlwiLFxuICAgICAgICBjb2RlOiA0MDRcbiAgICAgIH1cblxuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgLy8gYWNjZXNzIHJ1bGVzIDpcbiAgICAgIC8vIGFkbWluIGNhbiBlZGl0IGFueSBudW1iZXIgb2YgY2FtcHVzXG4gICAgICAvLyBvdGhlciB0eXBlIG9mIHVzZXJzIHdpbGwgaGF2ZSBubyBhY2Nlc3MgdG8gdGhpcyBmZWF0dXJlXG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgLy8gc3RlcCAxOiByZXF1ZXN0IHZhbGlkYXRpb24sIGJhc2ljIGZpbHRlcmluZ1xuICAgICAgaWYgKCF0aGlzLnVzZXJJZCkge1xuICAgICAgICByZXNwb25zZS5jb2RlID0gOTk5O1xuICAgICAgICByZXNwb25zZS5mZWVkYmFjayA9IFwiQWNjZXNzIGRlbmllZFwiO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9XG4gICAgICBjaGVjayhkYXRhLCBPYmplY3QpO1xuXG4gICAgICAvLyBzdGVwIDIgOiBjaGVja2luZyBEQiBhY2Nlc3MgcmlnaHRzXG5cbiAgICAgIC8vIGEgZmxhZyB0byBtYWtlIHN1cmUgdGhpcyByZXF1ZXN0aW5nIHVzZXIgaGFzIHRoZSByaWdodCBhY2Nlc3MgdG8gbW9kaWZ5IHRoaXMgZGF0YVxuICAgICAgdmFyIHVzZXJIYXNBY2Nlc3NSaWdodHMgPSBmYWxzZTtcblxuICAgICAgdmFyIHVzZXJJc0FkbWluID0gZmFsc2U7XG5cbiAgICAgIHZhciBkYkFjY2Vzc0NoZWNrZXIgPSBuZXcgQ2hlY2tkYmFjY2VzcygpO1xuXG4gICAgICB1c2VySXNBZG1pbiA9IGRiQWNjZXNzQ2hlY2tlci5pc1JvbGVBZG1pbih0aGlzLnVzZXJJZCk7IC8vcmV0dXJucyB0cnVlIGlmIGFkbWluXG4gICAgICB1c2VySGFzQWNjZXNzUmlnaHRzID0gdXNlcklzQWRtaW47XG5cbiAgICAgIGlmICh1c2VySGFzQWNjZXNzUmlnaHRzID09PSB0cnVlKSB7XG5cbiAgICAgICAgLy8gc3RlcCA6IDMgdXBkYXRpbmcgZGF0YSBpbnRvIHRoZSBEQlxuICAgICAgICBJbnN0aXR1dGVEQi5jb2xsZWN0aW9uLnVwZGF0ZShcbiAgICAgICAgICBkYXRhLl9pZCxcbiAgICAgICAgICB7XG4gICAgICAgICAgICAkc2V0OlxuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgbmFtZTogZGF0YS5uYW1lLFxuICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBkYXRhLmRlc2NyaXB0aW9uLFxuICAgICAgICAgICAgICAgIGNhbXB1c0lEOiBkYXRhLmNhbXB1c0lELFxuICAgICAgICAgICAgICAgIGZhY3VsdHlJRDogZGF0YS5mYWN1bHR5SUQsXG4gICAgICAgICAgICAgICAgY3JlYXRlZEJ5OiBNZXRlb3IudXNlcigpLmVtYWlsc1swXS5hZGRyZXNzLFxuICAgICAgICAgICAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKSxcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgIH0pOyAvLyBlbmQgdXBkYXRlXG5cblxuICAgICAgICByZXNwb25zZS5jb2RlID0gMjAwO1xuICAgICAgICByZXNwb25zZS5mZWVkYmFjayA9IFwiSW5zdGl0dXRlIFVwZGF0ZSBzdWNjZXNzZnVsbCFcIjtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgfSAvLyBlbmQgaWYgaWYodXNlckhhc0FjY2Vzc1JpZ2h0cyA9PT0gdHJ1ZSlcbiAgICAgIGVsc2Uge1xuICAgICAgICAvLyBubyBBY2Nlc3MgcmlnaHRcbiAgICAgICAgcmVzcG9uc2UuY29kZSA9IDk5OTtcbiAgICAgICAgcmVzcG9uc2UuZmVlZGJhY2sgPSBcIkFjY2VzcyBkZW5pZWRcIjtcbiAgICAgIH1cbiAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICB9LFxuXG4gICAgJ2lzSW5zdGl0dXRlSGFzQ291cnNlJyhpbnN0aXR1dGVJRCkge1xuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgIC8vIHRoZSByZXNwb25zZSBvYmplY3QgZm9yIGNsaWVudCB3aXRoIGZlZWRiYWNrIGFuZCBkYXRhXG4gICAgICAvLyBjb2RlcyA6XG4gICAgICAvLyA5OTkgPSBpbnN0aXR1dGUgaGFzIGNvdXJzZS5cbiAgICAgIC8vIDQwNCA9IERhdGJhc2UgbGV2ZWwgcHJvYmxlbSBvciBVbmtub3duIGVycm9yIG9yIGV4Y2VwdGlvbnNcbiAgICAgIC8vIDIwMCA9IGluc3RpdHV0ZSBoYXMgbm8gY291cnNlXG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuICAgICAgdmFyIHJlc3BvbnNlOiBhbnkgPSB7XG4gICAgICAgIGZlZWRiYWNrOiBcIlVua25vd24gZXJyb3Igd2hpbGUgcHJvY2Vzc2luZyByZXF1ZXN0LiBQbGVhc2UgdHJ5IGFnYWluLlwiLFxuICAgICAgICBjb2RlOiA0MDRcbiAgICAgIH1cblxuICAgICAgdmFyIG5vT2ZDb3Vyc2VzID0gQ291cnNlREIuY29sbGVjdGlvbi5maW5kKHsgXCJpbnN0aXR1dGVJRFwiOiBpbnN0aXR1dGVJRCB9KS5jb3VudCgpO1xuXG4gICAgICBpZiAobm9PZkNvdXJzZXMgIT09IHVuZGVmaW5lZCAmJiBub09mQ291cnNlcyA+IDApIHtcbiAgICAgICAgcmVzcG9uc2UuY29kZSA9IDk5OTtcbiAgICAgICAgcmVzcG9uc2UuZmVlZGJhY2sgPSBcIlRoaXMgSW5zdGl0dXRlIGhhcyBjb3Vyc2UuIERlbGV0ZSBjb3Vyc2VzIG9mIHRoaXMgaW5zdGl0dXRlIGZpcnN0LlwiO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9XG4gICAgICBlbHNlIGlmIChub09mQ291cnNlcyA9PT0gdW5kZWZpbmVkIHx8IG5vT2ZDb3Vyc2VzID09PSAwKSB7XG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSAyMDA7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJUaGlzIEluc3RpdHV0ZSBkb2Vzbid0IGhhdmUgYW55IGNvdXJzZVwiO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9XG4gICAgICBlbHNlIHtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgfVxuICAgIH0sXG5cblxuICAgICdkZWxldGVJbnN0aXR1dGUnKGRhdGEpIHtcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvLyB0aGUgcmVzcG9uc2Ugb2JqZWN0IGZvciBjbGllbnQgd2l0aCBmZWVkYmFjayBhbmQgZGF0YVxuICAgICAgLy8gY29kZXMgOlxuICAgICAgLy8gOTk5ID0gYWNjZXNzIGRlbmllZC5cbiAgICAgIC8vIDQwNCA9IERhdGJhc2UgbGV2ZWwgcHJvYmxlbSBvciBVbmtub3duIGVycm9yIG9yIGV4Y2VwdGlvbnNcbiAgICAgIC8vIDIwMCA9IHN1Y2Nlc3M7XG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuICAgICAgdmFyIHJlc3BvbnNlOiBhbnkgPSB7XG4gICAgICAgIGZlZWRiYWNrOiBcIlVua25vd24gZXJyb3Igd2hpbGUgcHJvY2Vzc2luZy4gUGxlYXNlIHRyeSBhZ2Fpbi5cIixcbiAgICAgICAgY29kZTogNDA0XG4gICAgICB9XG5cbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgIC8vIGFjY2VzcyBydWxlcyA6XG4gICAgICAvLyBhZG1pbiBjYW4gZWRpdCBhbnkgbnVtYmVyIG9mIGNhbXB1c1xuICAgICAgLy8gb3RoZXIgdHlwZSBvZiB1c2VycyB3aWxsIGhhdmUgbm8gYWNjZXNzIHRvIHRoaXMgZmVhdHVyZVxuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgIC8vIHN0ZXAgMTogcmVxdWVzdCB2YWxpZGF0aW9uLCBiYXNpYyBmaWx0ZXJpbmdcbiAgICAgIGlmICghdGhpcy51c2VySWQpIHtcbiAgICAgICAgcmVzcG9uc2UuY29kZSA9IDk5OTtcbiAgICAgICAgcmVzcG9uc2UuZmVlZGJhY2sgPSBcIkFjY2VzcyBkZW5pZWRcIjtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgfVxuICAgICAgY2hlY2soZGF0YSwgT2JqZWN0KTtcblxuICAgICAgLy8gc3RlcCAyIDogY2hlY2tpbmcgREIgYWNjZXNzIHJpZ2h0c1xuXG4gICAgICAvLyBhIGZsYWcgdG8gbWFrZSBzdXJlIHRoaXMgcmVxdWVzdGluZyB1c2VyIGhhcyB0aGUgcmlnaHQgYWNjZXNzIHRvIG1vZGlmeSB0aGlzIGRhdGFcbiAgICAgIHZhciB1c2VySGFzQWNjZXNzUmlnaHRzID0gZmFsc2U7XG5cbiAgICAgIHZhciB1c2VySXNBZG1pbiA9IGZhbHNlO1xuXG4gICAgICB2YXIgZGJBY2Nlc3NDaGVja2VyID0gbmV3IENoZWNrZGJhY2Nlc3MoKTtcblxuICAgICAgdXNlcklzQWRtaW4gPSBkYkFjY2Vzc0NoZWNrZXIuaXNSb2xlQWRtaW4odGhpcy51c2VySWQpOyAvL3JldHVybnMgdHJ1ZSBpZiBhZG1pblxuICAgICAgdXNlckhhc0FjY2Vzc1JpZ2h0cyA9IHVzZXJJc0FkbWluO1xuXG4gICAgICBpZiAodXNlckhhc0FjY2Vzc1JpZ2h0cyA9PT0gdHJ1ZSkge1xuICAgICAgICBJbnN0aXR1dGVEQi5jb2xsZWN0aW9uLnJlbW92ZShkYXRhLl9pZCk7XG5cbiAgICAgICAgcmVzcG9uc2UuY29kZSA9IDIwMDtcbiAgICAgICAgcmVzcG9uc2UuZmVlZGJhY2sgPSBcIkluc3RpdHV0ZSBkZWxldGUgc3VjY2Vzc2Z1bGwhXCI7XG4gICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgIH1cbiAgICAgIGVsc2Uge1xuICAgICAgICAvLyBubyBBY2Nlc3MgcmlnaHRcbiAgICAgICAgcmVzcG9uc2UuY29kZSA9IDk5OTtcbiAgICAgICAgcmVzcG9uc2UuZmVlZGJhY2sgPSBcIkFjY2VzcyBkZW5pZWRcIjtcbiAgICAgIH1cbiAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICB9XG5cbiAgfSk7IC8vIEVORCBvZiBtZXRlb3IgbWV0aG9kc1xuXG59IC8vIEVORCBvZiBNZXRlb3IuaXNTZXJ2ZXJcbiIsIi8vIGRvY3MgZm9yIG1ldGVvciBkZWZhdWx0IG1ldGhvZHMgOiBodHRwOi8vZG9jcy5tZXRlb3IuY29tL2FwaS9wYXNzd29yZHMuaHRtbFxuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBBY2NvdW50cyB9IGZyb20gJ21ldGVvci9hY2NvdW50cy1iYXNlJ1xuaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IHsgTWV0ZW9yT2JzZXJ2YWJsZSB9IGZyb20gJ21ldGVvci1yeGpzJztcbmltcG9ydCB7IGNoZWNrIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJztcbmltcG9ydCB7IENoZWNrZGJhY2Nlc3MgfSBmcm9tICcvc2VydmVyL2RiYXBpL3Rvb2xzL2NoZWNrZGJhY2Nlc3MudHMnO1xuaW1wb3J0IHsgTGV2ZWxEQiwgUHJvZmlsZURCLCBGYWN1bHR5REIgfSBmcm9tIFwiL2ltcG9ydHMvYXBpL2luZGV4XCI7XG5cblxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xuXG4gIE1ldGVvci5tZXRob2RzKHtcblxuXG4gICAgJ2lzTGV2ZWxFeGlzdEluREInKGxldmVsTmFtZSkge1xuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgIC8vIHRoZSByZXNwb25zZSBvYmplY3QgZm9yIGNsaWVudCB3aXRoIGZlZWRiYWNrIGFuZCBkYXRhXG4gICAgICAvLyBjb2RlcyA6XG4gICAgICAvLyA5OTkgPSB1bmtub3duIG5hbWUuXG4gICAgICAvLyA0MDQgPSBEYXRiYXNlIGxldmVsIHByb2JsZW0gb3IgVW5rbm93biBlcnJvciBvciBleGNlcHRpb25zXG4gICAgICAvLyAyMDAgPSBsZXZlbCBuYW1lIGFscmVhZHkgZXhpc3RzO1xuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICB2YXIgcmVzcG9uc2U6IGFueSA9IHtcbiAgICAgICAgZmVlZGJhY2s6IFwiVW5rbm93biBlcnJvciB3aGlsZSBwcm9jZXNzaW5nIHJlcXVlc3QuIFBsZWFzZSB0cnkgYWdhaW4uXCIsXG4gICAgICAgIGNvZGU6IDQwNFxuICAgICAgfVxuXG4gICAgICB2YXIgbGV2ZWxOYW1laW5EQiA9IExldmVsREIuZmluZE9uZSh7IFwibmFtZVwiOiBsZXZlbE5hbWUgfSk7XG5cblxuICAgICAgaWYgKGxldmVsTmFtZWluREIgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICByZXNwb25zZS5jb2RlID0gMjAwO1xuICAgICAgICByZXNwb25zZS5mZWVkYmFjayA9IFwiVGhpcyBMZXZlbCBpcyBhbHJlYWR5IHJlZ2lzdGVyZWQgaW4gdGhlIHN5c3RlbVwiO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9XG4gICAgICBlbHNlIGlmIChsZXZlbE5hbWVpbkRCID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgcmVzcG9uc2UuY29kZSA9IDk5OTtcbiAgICAgICAgcmVzcG9uc2UuZmVlZGJhY2sgPSBcIlRoaXMgTGV2ZWwgaXMgbm90IHJlZ2lzdGVyZWQgaW4gdGhlIHN5c3RlbVwiO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9XG4gICAgICBlbHNlIHtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgfVxuICAgIH0sXG5cbiAgICAnYWRkTmV3TGV2ZWwnKGRhdGEpIHtcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvLyB0aGUgcmVzcG9uc2Ugb2JqZWN0IGZvciBjbGllbnQgd2l0aCBmZWVkYmFjayBhbmQgZGF0YVxuICAgICAgLy8gY29kZXMgOlxuICAgICAgLy8gOTk5ID0gYWNjZXNzIGRlbmllZC5cbiAgICAgIC8vIDQwNCA9IERhdGJhc2UgbGV2ZWwgcHJvYmxlbSBvciBVbmtub3duIGVycm9yIG9yIGV4Y2VwdGlvbnNcbiAgICAgIC8vIDIwMCA9IHN1Y2Nlc3M7XG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuICAgICAgdmFyIHJlc3BvbnNlOiBhbnkgPSB7XG4gICAgICAgIGZlZWRiYWNrOiBcIlVua25vd24gZXJyb3Igd2hpbGUgcHJvY2Vzc2luZy4gUGxlYXNlIHRyeSBhZ2Fpbi5cIixcbiAgICAgICAgY29kZTogNDA0XG4gICAgICB9XG5cbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgIC8vIGFjY2VzcyBydWxlcyA6XG4gICAgICAvLyBhZG1pbiBjYW4gYWRkIGFueSBudW1iZXIgb2YgbGV2ZWxcbiAgICAgIC8vIG90aGVyIHR5cGUgb2YgdXNlcnMgd2lsbCBoYXZlIG5vIGFjY2VzcyB0byB0aGlzIGZlYXR1cmVcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvLyBzdGVwIDE6IHJlcXVlc3QgdmFsaWRhdGlvbiwgYmFzaWMgZmlsdGVyaW5nXG4gICAgICBpZiAoIXRoaXMudXNlcklkKSB7XG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSA5OTk7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJBY2Nlc3MgZGVuaWVkXCI7XG4gICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgIH1cbiAgICAgIGNoZWNrKGRhdGEsIE9iamVjdCk7XG5cbiAgICAgIC8vIHN0ZXAgMiA6IGNoZWNraW5nIERCIGFjY2VzcyByaWdodHNcblxuICAgICAgLy8gYSBmbGFnIHRvIG1ha2Ugc3VyZSB0aGlzIHJlcXVlc3RpbmcgdXNlciBoYXMgdGhlIHJpZ2h0IGFjY2VzcyB0byBtb2RpZnkgdGhpcyBkYXRhXG4gICAgICB2YXIgdXNlckhhc0FjY2Vzc1JpZ2h0cyA9IGZhbHNlO1xuXG4gICAgICB2YXIgdXNlcklzQWRtaW4gPSBmYWxzZTtcblxuICAgICAgdmFyIGRiQWNjZXNzQ2hlY2tlciA9IG5ldyBDaGVja2RiYWNjZXNzKCk7XG5cbiAgICAgIHVzZXJJc0FkbWluID0gZGJBY2Nlc3NDaGVja2VyLmlzUm9sZUFkbWluKHRoaXMudXNlcklkKTsgLy9yZXR1cm5zIHRydWUgaWYgYWRtaW5cbiAgICAgIHVzZXJIYXNBY2Nlc3NSaWdodHMgPSB1c2VySXNBZG1pbjtcblxuICAgICAgaWYgKHVzZXJIYXNBY2Nlc3NSaWdodHMgPT09IHRydWUpIHtcblxuICAgICAgICAvLyBzdGVwIDogMyB1cGRhdGluZyBkYXRhIGludG8gdGhlIERCXG4gICAgICAgIExldmVsREIuY29sbGVjdGlvbi5pbnNlcnQoe1xuXG4gICAgICAgICAgbmFtZTogZGF0YS5uYW1lLFxuICAgICAgICAgIGRlc2NyaXB0aW9uOiBkYXRhLmRlc2NyaXB0aW9uLFxuICAgICAgICAgIGNyZWF0ZWRCeTogTWV0ZW9yLnVzZXIoKS5lbWFpbHNbMF0uYWRkcmVzcyxcbiAgICAgICAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKCksXG5cbiAgICAgICAgfSk7IC8vZW5kIGluc2VydFxuICAgICAgICByZXNwb25zZS5jb2RlID0gMjAwO1xuICAgICAgICByZXNwb25zZS5mZWVkYmFjayA9IFwiTmV3IExldmVsIENyZWF0aW9uIHN1Y2Nlc3NmdWxsIVwiO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9IC8vIGVuZCBpZiBpZih1c2VySGFzQWNjZXNzUmlnaHRzID09PSB0cnVlKVxuICAgICAgZWxzZSB7XG4gICAgICAgIC8vIG5vIEFjY2VzcyByaWdodFxuICAgICAgICByZXNwb25zZS5jb2RlID0gOTk5O1xuICAgICAgICByZXNwb25zZS5mZWVkYmFjayA9IFwiQWNjZXNzIGRlbmllZFwiO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuXG5cblxuICAgIH0sXG5cbiAgICAndXBkYXRlTGV2ZWwnKGRhdGEpIHtcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvLyB0aGUgcmVzcG9uc2Ugb2JqZWN0IGZvciBjbGllbnQgd2l0aCBmZWVkYmFjayBhbmQgZGF0YVxuICAgICAgLy8gY29kZXMgOlxuICAgICAgLy8gOTk5ID0gYWNjZXNzIGRlbmllZC5cbiAgICAgIC8vIDQwNCA9IERhdGJhc2UgbGV2ZWwgcHJvYmxlbSBvciBVbmtub3duIGVycm9yIG9yIGV4Y2VwdGlvbnNcbiAgICAgIC8vIDIwMCA9IHN1Y2Nlc3M7XG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuICAgICAgdmFyIHJlc3BvbnNlOiBhbnkgPSB7XG4gICAgICAgIGZlZWRiYWNrOiBcIlVua25vd24gZXJyb3Igd2hpbGUgcHJvY2Vzc2luZy4gUGxlYXNlIHRyeSBhZ2Fpbi5cIixcbiAgICAgICAgY29kZTogNDA0XG4gICAgICB9XG5cbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgIC8vIGFjY2VzcyBydWxlcyA6XG4gICAgICAvLyBhZG1pbiBjYW4gZWRpdCBhbnkgbnVtYmVyIG9mIGxldmVsXG4gICAgICAvLyBvdGhlciB0eXBlIG9mIHVzZXJzIHdpbGwgaGF2ZSBubyBhY2Nlc3MgdG8gdGhpcyBmZWF0dXJlXG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgLy8gc3RlcCAxOiByZXF1ZXN0IHZhbGlkYXRpb24sIGJhc2ljIGZpbHRlcmluZ1xuICAgICAgaWYgKCF0aGlzLnVzZXJJZCkge1xuICAgICAgICByZXNwb25zZS5jb2RlID0gOTk5O1xuICAgICAgICByZXNwb25zZS5mZWVkYmFjayA9IFwiQWNjZXNzIGRlbmllZFwiO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9XG4gICAgICBjaGVjayhkYXRhLCBPYmplY3QpO1xuXG4gICAgICAvLyBzdGVwIDIgOiBjaGVja2luZyBEQiBhY2Nlc3MgcmlnaHRzXG5cbiAgICAgIC8vIGEgZmxhZyB0byBtYWtlIHN1cmUgdGhpcyByZXF1ZXN0aW5nIHVzZXIgaGFzIHRoZSByaWdodCBhY2Nlc3MgdG8gbW9kaWZ5IHRoaXMgZGF0YVxuICAgICAgdmFyIHVzZXJIYXNBY2Nlc3NSaWdodHMgPSBmYWxzZTtcblxuICAgICAgdmFyIHVzZXJJc0FkbWluID0gZmFsc2U7XG5cbiAgICAgIHZhciBkYkFjY2Vzc0NoZWNrZXIgPSBuZXcgQ2hlY2tkYmFjY2VzcygpO1xuXG4gICAgICB1c2VySXNBZG1pbiA9IGRiQWNjZXNzQ2hlY2tlci5pc1JvbGVBZG1pbih0aGlzLnVzZXJJZCk7IC8vcmV0dXJucyB0cnVlIGlmIGFkbWluXG4gICAgICB1c2VySGFzQWNjZXNzUmlnaHRzID0gdXNlcklzQWRtaW47XG5cbiAgICAgIGlmICh1c2VySGFzQWNjZXNzUmlnaHRzID09PSB0cnVlKSB7XG5cbiAgICAgICAgLy8gc3RlcCA6IDMgdXBkYXRpbmcgZGF0YSBpbnRvIHRoZSBEQlxuICAgICAgICBMZXZlbERCLmNvbGxlY3Rpb24udXBkYXRlKFxuICAgICAgICAgIGRhdGEuX2lkLFxuICAgICAgICAgIHtcbiAgICAgICAgICAgICRzZXQ6XG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBuYW1lOiBkYXRhLm5hbWUsXG4gICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IGRhdGEuZGVzY3JpcHRpb24sXG4gICAgICAgICAgICAgICAgY3JlYXRlZEJ5OiBNZXRlb3IudXNlcigpLmVtYWlsc1swXS5hZGRyZXNzLFxuICAgICAgICAgICAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKSxcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgIH0pOyAvLyBlbmQgdXBkYXRlXG5cblxuICAgICAgICByZXNwb25zZS5jb2RlID0gMjAwO1xuICAgICAgICByZXNwb25zZS5mZWVkYmFjayA9IFwiTGV2ZWwgVXBkYXRlIHN1Y2Nlc3NmdWxsIVwiO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9IC8vIGVuZCBpZiBpZih1c2VySGFzQWNjZXNzUmlnaHRzID09PSB0cnVlKVxuICAgICAgZWxzZSB7XG4gICAgICAgIC8vIG5vIEFjY2VzcyByaWdodFxuICAgICAgICByZXNwb25zZS5jb2RlID0gOTk5O1xuICAgICAgICByZXNwb25zZS5mZWVkYmFjayA9IFwiQWNjZXNzIGRlbmllZFwiO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgIH0sXG5cbiAgICAnZGVsZXRlTGV2ZWwnKGRhdGEpIHtcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvLyB0aGUgcmVzcG9uc2Ugb2JqZWN0IGZvciBjbGllbnQgd2l0aCBmZWVkYmFjayBhbmQgZGF0YVxuICAgICAgLy8gY29kZXMgOlxuICAgICAgLy8gOTk5ID0gYWNjZXNzIGRlbmllZC5cbiAgICAgIC8vIDQwNCA9IERhdGJhc2UgbGV2ZWwgcHJvYmxlbSBvciBVbmtub3duIGVycm9yIG9yIGV4Y2VwdGlvbnNcbiAgICAgIC8vIDIwMCA9IHN1Y2Nlc3M7XG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuICAgICAgdmFyIHJlc3BvbnNlOiBhbnkgPSB7XG4gICAgICAgIGZlZWRiYWNrOiBcIlVua25vd24gZXJyb3Igd2hpbGUgcHJvY2Vzc2luZy4gUGxlYXNlIHRyeSBhZ2Fpbi5cIixcbiAgICAgICAgY29kZTogNDA0XG4gICAgICB9XG5cbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgIC8vIGFjY2VzcyBydWxlcyA6XG4gICAgICAvLyBhZG1pbiBjYW4gZWRpdCBhbnkgbnVtYmVyIG9mIGxldmVsXG4gICAgICAvLyBvdGhlciB0eXBlIG9mIHVzZXJzIHdpbGwgaGF2ZSBubyBhY2Nlc3MgdG8gdGhpcyBmZWF0dXJlXG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgLy8gc3RlcCAxOiByZXF1ZXN0IHZhbGlkYXRpb24sIGJhc2ljIGZpbHRlcmluZ1xuICAgICAgaWYgKCF0aGlzLnVzZXJJZCkge1xuICAgICAgICByZXNwb25zZS5jb2RlID0gOTk5O1xuICAgICAgICByZXNwb25zZS5mZWVkYmFjayA9IFwiQWNjZXNzIGRlbmllZFwiO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9XG4gICAgICBjaGVjayhkYXRhLCBPYmplY3QpO1xuXG4gICAgICAvLyBzdGVwIDIgOiBjaGVja2luZyBEQiBhY2Nlc3MgcmlnaHRzXG5cbiAgICAgIC8vIGEgZmxhZyB0byBtYWtlIHN1cmUgdGhpcyByZXF1ZXN0aW5nIHVzZXIgaGFzIHRoZSByaWdodCBhY2Nlc3MgdG8gbW9kaWZ5IHRoaXMgZGF0YVxuICAgICAgdmFyIHVzZXJIYXNBY2Nlc3NSaWdodHMgPSBmYWxzZTtcblxuICAgICAgdmFyIHVzZXJJc0FkbWluID0gZmFsc2U7XG5cbiAgICAgIHZhciBkYkFjY2Vzc0NoZWNrZXIgPSBuZXcgQ2hlY2tkYmFjY2VzcygpO1xuXG4gICAgICB1c2VySXNBZG1pbiA9IGRiQWNjZXNzQ2hlY2tlci5pc1JvbGVBZG1pbih0aGlzLnVzZXJJZCk7IC8vcmV0dXJucyB0cnVlIGlmIGFkbWluXG4gICAgICB1c2VySGFzQWNjZXNzUmlnaHRzID0gdXNlcklzQWRtaW47XG5cbiAgICAgIGlmICh1c2VySGFzQWNjZXNzUmlnaHRzID09PSB0cnVlKSB7XG4gICAgICAgIExldmVsREIuY29sbGVjdGlvbi5yZW1vdmUoZGF0YS5faWQpO1xuXG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSAyMDA7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJMZXZlbCBkZWxldGUgc3VjY2Vzc2Z1bGwhXCI7XG4gICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgIH1cbiAgICAgIGVsc2Uge1xuICAgICAgICAvLyBubyBBY2Nlc3MgcmlnaHRcbiAgICAgICAgcmVzcG9uc2UuY29kZSA9IDk5OTtcbiAgICAgICAgcmVzcG9uc2UuZmVlZGJhY2sgPSBcIkFjY2VzcyBkZW5pZWRcIjtcbiAgICAgIH1cbiAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICB9LFxuXG4gICAgJ2dldEFsbExldmVsTmFtZScoKSB7XG4gICAgICByZXR1cm4gTGV2ZWxEQi5maW5kKHt9KS5mZXRjaCgpO1xuICAgIH1cblxuXG4gIH0pOyAvLyBFTkQgb2YgbWV0ZW9yIG1ldGhvZHNcblxufSAvLyBFTkQgb2YgTWV0ZW9yLmlzU2VydmVyXG4iLCIvLyBkb2NzIGZvciBtZXRlb3IgZGVmYXVsdCBtZXRob2RzIDogaHR0cDovL2RvY3MubWV0ZW9yLmNvbS9hcGkvcGFzc3dvcmRzLmh0bWxcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgQWNjb3VudHMgfSBmcm9tICdtZXRlb3IvYWNjb3VudHMtYmFzZSdcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCB7IE1ldGVvck9ic2VydmFibGUgfSBmcm9tICdtZXRlb3Itcnhqcyc7XG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjayc7XG5pbXBvcnQgeyBDaGVja2RiYWNjZXNzIH0gZnJvbSAnL3NlcnZlci9kYmFwaS90b29scy9jaGVja2RiYWNjZXNzLnRzJztcbmltcG9ydCB7IFRvb2xEQiB9IGZyb20gXCIvaW1wb3J0cy9hcGkvaW5kZXhcIjtcblxuXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG5cbiAgTWV0ZW9yLm1ldGhvZHMoe1xuXG5cbiAgICAnaXNUb29sRXhpc3RJbkRCJyh0b29sTmFtZSkge1xuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgIC8vIHRoZSByZXNwb25zZSBvYmplY3QgZm9yIGNsaWVudCB3aXRoIGZlZWRiYWNrIGFuZCBkYXRhXG4gICAgICAvLyBjb2RlcyA6XG4gICAgICAvLyA5OTkgPSB1bmtub3duIG5hbWUuXG4gICAgICAvLyA0MDQgPSBEYXRiYXNlIHRvb2wgcHJvYmxlbSBvciBVbmtub3duIGVycm9yIG9yIGV4Y2VwdGlvbnNcbiAgICAgIC8vIDIwMCA9IHRvb2wgbmFtZSBhbHJlYWR5IGV4aXN0cztcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgdmFyIHJlc3BvbnNlOiBhbnkgPSB7XG4gICAgICAgIGZlZWRiYWNrOiBcIlVua25vd24gZXJyb3Igd2hpbGUgcHJvY2Vzc2luZyByZXF1ZXN0LiBQbGVhc2UgdHJ5IGFnYWluLlwiLFxuICAgICAgICBjb2RlOiA0MDRcbiAgICAgIH1cblxuICAgICAgdmFyIHRvb2xOYW1laW5EQiA9IFRvb2xEQi5maW5kT25lKHsgXCJuYW1lXCI6IHRvb2xOYW1lIH0pO1xuXG5cbiAgICAgIGlmICh0b29sTmFtZWluREIgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICByZXNwb25zZS5jb2RlID0gMjAwO1xuICAgICAgICByZXNwb25zZS5mZWVkYmFjayA9IFwiVGhpcyBUb29sIGlzIGFscmVhZHkgcmVnaXN0ZXJlZCBpbiB0aGUgc3lzdGVtXCI7XG4gICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgIH1cbiAgICAgIGVsc2UgaWYgKHRvb2xOYW1laW5EQiA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSA5OTk7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJUaGlzIFRvb2wgaXMgbm90IHJlZ2lzdGVyZWQgaW4gdGhlIHN5c3RlbVwiO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9XG4gICAgICBlbHNlIHtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgfVxuICAgIH0sXG5cbiAgICAnYWRkTmV3VG9vbCcoZGF0YSkge1xuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgIC8vIHRoZSByZXNwb25zZSBvYmplY3QgZm9yIGNsaWVudCB3aXRoIGZlZWRiYWNrIGFuZCBkYXRhXG4gICAgICAvLyBjb2RlcyA6XG4gICAgICAvLyA5OTkgPSBhY2Nlc3MgZGVuaWVkLlxuICAgICAgLy8gNDA0ID0gRGF0YmFzZSB0b29sIHByb2JsZW0gb3IgVW5rbm93biBlcnJvciBvciBleGNlcHRpb25zXG4gICAgICAvLyAyMDAgPSBzdWNjZXNzO1xuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbiAgICAgIHZhciByZXNwb25zZTogYW55ID0ge1xuICAgICAgICBmZWVkYmFjazogXCJVbmtub3duIGVycm9yIHdoaWxlIHByb2Nlc3NpbmcuIFBsZWFzZSB0cnkgYWdhaW4uXCIsXG4gICAgICAgIGNvZGU6IDQwNFxuICAgICAgfVxuXG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvLyBhY2Nlc3MgcnVsZXMgOlxuICAgICAgLy8gYWRtaW4gY2FuIGFkZCBhbnkgbnVtYmVyIG9mIHRvb2xcbiAgICAgIC8vIG90aGVyIHR5cGUgb2YgdXNlcnMgd2lsbCBoYXZlIG5vIGFjY2VzcyB0byB0aGlzIGZlYXR1cmVcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvLyBzdGVwIDE6IHJlcXVlc3QgdmFsaWRhdGlvbiwgYmFzaWMgZmlsdGVyaW5nXG4gICAgICBpZiAoIXRoaXMudXNlcklkKSB7XG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSA5OTk7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJBY2Nlc3MgZGVuaWVkXCI7XG4gICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgIH1cbiAgICAgIGNoZWNrKGRhdGEsIE9iamVjdCk7XG5cbiAgICAgIC8vIHN0ZXAgMiA6IGNoZWNraW5nIERCIGFjY2VzcyByaWdodHNcblxuICAgICAgLy8gYSBmbGFnIHRvIG1ha2Ugc3VyZSB0aGlzIHJlcXVlc3RpbmcgdXNlciBoYXMgdGhlIHJpZ2h0IGFjY2VzcyB0byBtb2RpZnkgdGhpcyBkYXRhXG4gICAgICB2YXIgdXNlckhhc0FjY2Vzc1JpZ2h0cyA9IGZhbHNlO1xuXG4gICAgICB2YXIgdXNlcklzQWRtaW4gPSBmYWxzZTtcblxuICAgICAgdmFyIGRiQWNjZXNzQ2hlY2tlciA9IG5ldyBDaGVja2RiYWNjZXNzKCk7XG5cbiAgICAgIHVzZXJJc0FkbWluID0gZGJBY2Nlc3NDaGVja2VyLmlzUm9sZUFkbWluKHRoaXMudXNlcklkKTsgLy9yZXR1cm5zIHRydWUgaWYgYWRtaW5cbiAgICAgIHVzZXJIYXNBY2Nlc3NSaWdodHMgPSB1c2VySXNBZG1pbjtcblxuICAgICAgaWYgKHVzZXJIYXNBY2Nlc3NSaWdodHMgPT09IHRydWUpIHtcblxuICAgICAgICAvLyBzdGVwIDogMyB1cGRhdGluZyBkYXRhIGludG8gdGhlIERCXG4gICAgICAgIFRvb2xEQi5jb2xsZWN0aW9uLmluc2VydCh7XG5cbiAgICAgICAgICBuYW1lOiBkYXRhLm5hbWUsXG4gICAgICAgICAgZGVzY3JpcHRpb246IGRhdGEuZGVzY3JpcHRpb24sXG4gICAgICAgICAgY3JlYXRlZEJ5OiBNZXRlb3IudXNlcigpLmVtYWlsc1swXS5hZGRyZXNzLFxuICAgICAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKSxcblxuICAgICAgICB9KTsgLy9lbmQgaW5zZXJ0XG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSAyMDA7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJOZXcgVG9vbCBDcmVhdGlvbiBzdWNjZXNzZnVsbCFcIjtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgfSAvLyBlbmQgaWYgaWYodXNlckhhc0FjY2Vzc1JpZ2h0cyA9PT0gdHJ1ZSlcbiAgICAgIGVsc2Uge1xuICAgICAgICAvLyBubyBBY2Nlc3MgcmlnaHRcbiAgICAgICAgcmVzcG9uc2UuY29kZSA9IDk5OTtcbiAgICAgICAgcmVzcG9uc2UuZmVlZGJhY2sgPSBcIkFjY2VzcyBkZW5pZWRcIjtcbiAgICAgIH1cbiAgICAgIHJldHVybiByZXNwb25zZTtcblxuXG5cbiAgICB9LFxuXG4gICAgJ3VwZGF0ZVRvb2wnKGRhdGEpIHtcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvLyB0aGUgcmVzcG9uc2Ugb2JqZWN0IGZvciBjbGllbnQgd2l0aCBmZWVkYmFjayBhbmQgZGF0YVxuICAgICAgLy8gY29kZXMgOlxuICAgICAgLy8gOTk5ID0gYWNjZXNzIGRlbmllZC5cbiAgICAgIC8vIDQwNCA9IERhdGJhc2UgdG9vbCBwcm9ibGVtIG9yIFVua25vd24gZXJyb3Igb3IgZXhjZXB0aW9uc1xuICAgICAgLy8gMjAwID0gc3VjY2VzcztcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4gICAgICB2YXIgcmVzcG9uc2U6IGFueSA9IHtcbiAgICAgICAgZmVlZGJhY2s6IFwiVW5rbm93biBlcnJvciB3aGlsZSBwcm9jZXNzaW5nLiBQbGVhc2UgdHJ5IGFnYWluLlwiLFxuICAgICAgICBjb2RlOiA0MDRcbiAgICAgIH1cblxuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgLy8gYWNjZXNzIHJ1bGVzIDpcbiAgICAgIC8vIGFkbWluIGNhbiBlZGl0IGFueSBudW1iZXIgb2YgdG9vbFxuICAgICAgLy8gb3RoZXIgdHlwZSBvZiB1c2VycyB3aWxsIGhhdmUgbm8gYWNjZXNzIHRvIHRoaXMgZmVhdHVyZVxuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgIC8vIHN0ZXAgMTogcmVxdWVzdCB2YWxpZGF0aW9uLCBiYXNpYyBmaWx0ZXJpbmdcbiAgICAgIGlmICghdGhpcy51c2VySWQpIHtcbiAgICAgICAgcmVzcG9uc2UuY29kZSA9IDk5OTtcbiAgICAgICAgcmVzcG9uc2UuZmVlZGJhY2sgPSBcIkFjY2VzcyBkZW5pZWRcIjtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgfVxuICAgICAgY2hlY2soZGF0YSwgT2JqZWN0KTtcblxuICAgICAgLy8gc3RlcCAyIDogY2hlY2tpbmcgREIgYWNjZXNzIHJpZ2h0c1xuXG4gICAgICAvLyBhIGZsYWcgdG8gbWFrZSBzdXJlIHRoaXMgcmVxdWVzdGluZyB1c2VyIGhhcyB0aGUgcmlnaHQgYWNjZXNzIHRvIG1vZGlmeSB0aGlzIGRhdGFcbiAgICAgIHZhciB1c2VySGFzQWNjZXNzUmlnaHRzID0gZmFsc2U7XG5cbiAgICAgIHZhciB1c2VySXNBZG1pbiA9IGZhbHNlO1xuXG4gICAgICB2YXIgZGJBY2Nlc3NDaGVja2VyID0gbmV3IENoZWNrZGJhY2Nlc3MoKTtcblxuICAgICAgdXNlcklzQWRtaW4gPSBkYkFjY2Vzc0NoZWNrZXIuaXNSb2xlQWRtaW4odGhpcy51c2VySWQpOyAvL3JldHVybnMgdHJ1ZSBpZiBhZG1pblxuICAgICAgdXNlckhhc0FjY2Vzc1JpZ2h0cyA9IHVzZXJJc0FkbWluO1xuXG4gICAgICBpZiAodXNlckhhc0FjY2Vzc1JpZ2h0cyA9PT0gdHJ1ZSkge1xuXG4gICAgICAgIC8vIHN0ZXAgOiAzIHVwZGF0aW5nIGRhdGEgaW50byB0aGUgREJcbiAgICAgICAgVG9vbERCLmNvbGxlY3Rpb24udXBkYXRlKFxuICAgICAgICAgIGRhdGEuX2lkLFxuICAgICAgICAgIHtcbiAgICAgICAgICAgICRzZXQ6XG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBuYW1lOiBkYXRhLm5hbWUsXG4gICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IGRhdGEuZGVzY3JpcHRpb24sXG4gICAgICAgICAgICAgICAgY3JlYXRlZEJ5OiBNZXRlb3IudXNlcigpLmVtYWlsc1swXS5hZGRyZXNzLFxuICAgICAgICAgICAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKSxcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgIH0pOyAvLyBlbmQgdXBkYXRlXG5cblxuICAgICAgICByZXNwb25zZS5jb2RlID0gMjAwO1xuICAgICAgICByZXNwb25zZS5mZWVkYmFjayA9IFwiVG9vbCBVcGRhdGUgc3VjY2Vzc2Z1bGwhXCI7XG4gICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgIH0gLy8gZW5kIGlmIGlmKHVzZXJIYXNBY2Nlc3NSaWdodHMgPT09IHRydWUpXG4gICAgICBlbHNlIHtcbiAgICAgICAgLy8gbm8gQWNjZXNzIHJpZ2h0XG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSA5OTk7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJBY2Nlc3MgZGVuaWVkXCI7XG4gICAgICB9XG4gICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgfSxcblxuICAgICdkZWxldGVUb29sJyhkYXRhKSB7XG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgLy8gdGhlIHJlc3BvbnNlIG9iamVjdCBmb3IgY2xpZW50IHdpdGggZmVlZGJhY2sgYW5kIGRhdGFcbiAgICAgIC8vIGNvZGVzIDpcbiAgICAgIC8vIDk5OSA9IGFjY2VzcyBkZW5pZWQuXG4gICAgICAvLyA0MDQgPSBEYXRiYXNlIHRvb2wgcHJvYmxlbSBvciBVbmtub3duIGVycm9yIG9yIGV4Y2VwdGlvbnNcbiAgICAgIC8vIDIwMCA9IHN1Y2Nlc3M7XG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuICAgICAgdmFyIHJlc3BvbnNlOiBhbnkgPSB7XG4gICAgICAgIGZlZWRiYWNrOiBcIlVua25vd24gZXJyb3Igd2hpbGUgcHJvY2Vzc2luZy4gUGxlYXNlIHRyeSBhZ2Fpbi5cIixcbiAgICAgICAgY29kZTogNDA0XG4gICAgICB9XG5cbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgIC8vIGFjY2VzcyBydWxlcyA6XG4gICAgICAvLyBhZG1pbiBjYW4gZWRpdCBhbnkgbnVtYmVyIG9mIHRvb2xcbiAgICAgIC8vIG90aGVyIHR5cGUgb2YgdXNlcnMgd2lsbCBoYXZlIG5vIGFjY2VzcyB0byB0aGlzIGZlYXR1cmVcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvLyBzdGVwIDE6IHJlcXVlc3QgdmFsaWRhdGlvbiwgYmFzaWMgZmlsdGVyaW5nXG4gICAgICBpZiAoIXRoaXMudXNlcklkKSB7XG4gICAgICAgIHJlc3BvbnNlLmNvZGUgPSA5OTk7XG4gICAgICAgIHJlc3BvbnNlLmZlZWRiYWNrID0gXCJBY2Nlc3MgZGVuaWVkXCI7XG4gICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgIH1cbiAgICAgIGNoZWNrKGRhdGEsIE9iamVjdCk7XG5cbiAgICAgIC8vIHN0ZXAgMiA6IGNoZWNraW5nIERCIGFjY2VzcyByaWdodHNcblxuICAgICAgLy8gYSBmbGFnIHRvIG1ha2Ugc3VyZSB0aGlzIHJlcXVlc3RpbmcgdXNlciBoYXMgdGhlIHJpZ2h0IGFjY2VzcyB0byBtb2RpZnkgdGhpcyBkYXRhXG4gICAgICB2YXIgdXNlckhhc0FjY2Vzc1JpZ2h0cyA9IGZhbHNlO1xuXG4gICAgICB2YXIgdXNlcklzQWRtaW4gPSBmYWxzZTtcblxuICAgICAgdmFyIGRiQWNjZXNzQ2hlY2tlciA9IG5ldyBDaGVja2RiYWNjZXNzKCk7XG5cbiAgICAgIHVzZXJJc0FkbWluID0gZGJBY2Nlc3NDaGVja2VyLmlzUm9sZUFkbWluKHRoaXMudXNlcklkKTsgLy9yZXR1cm5zIHRydWUgaWYgYWRtaW5cbiAgICAgIHVzZXJIYXNBY2Nlc3NSaWdodHMgPSB1c2VySXNBZG1pbjtcblxuICAgICAgaWYgKHVzZXJIYXNBY2Nlc3NSaWdodHMgPT09IHRydWUpIHtcbiAgICAgICAgVG9vbERCLmNvbGxlY3Rpb24ucmVtb3ZlKGRhdGEuX2lkKTtcblxuICAgICAgICByZXNwb25zZS5jb2RlID0gMjAwO1xuICAgICAgICByZXNwb25zZS5mZWVkYmFjayA9IFwiVG9vbCBkZWxldGUgc3VjY2Vzc2Z1bGwhXCI7XG4gICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgIH1cbiAgICAgIGVsc2Uge1xuICAgICAgICAvLyBubyBBY2Nlc3MgcmlnaHRcbiAgICAgICAgcmVzcG9uc2UuY29kZSA9IDk5OTtcbiAgICAgICAgcmVzcG9uc2UuZmVlZGJhY2sgPSBcIkFjY2VzcyBkZW5pZWRcIjtcbiAgICAgIH1cbiAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICB9LFxuXG4gICAgJ2dldEFsbFRvb2xOYW1lJygpIHtcbiAgICAgIHJldHVybiBUb29sREIuZmluZCh7fSkuZmV0Y2goKTtcbiAgICB9XG5cblxuICB9KTsgLy8gRU5EIG9mIG1ldGVvciBtZXRob2RzXG5cbn0gLy8gRU5EIG9mIE1ldGVvci5pc1NlcnZlclxuIiwiaW1wb3J0IHtNZXRlb3J9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHtNb25nb30gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCB7IGNoZWNrIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJztcbmltcG9ydCB7IENoZWNrZGJhY2Nlc3MgfSBmcm9tICcvc2VydmVyL2RiYXBpL3Rvb2xzL2NoZWNrZGJhY2Nlc3MudHMnO1xuXG5pbXBvcnQgeyBDYW1wdXNEQn0gZnJvbSAnL2ltcG9ydHMvYXBpL2luZGV4LnRzJztcblxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xuXG5cblxuLy8gPT09PT0gc3RhcnQgb2YgcHVibGlzaEFsbENhdGVnb3JpZXMgPT09PT09XG5NZXRlb3IucHVibGlzaCgncHVibGlzaEFsbENhbXB1c2VzJywgZnVuY3Rpb24gKCkge1xuXG4gIHJldHVybiBDYW1wdXNEQi5maW5kKHt9KTtcblxufSk7XG4vLyAtLS0gRW5kIG9mIHB1Ymxpc2hBbGxDYXRlZ29yaWVzIC0tLVxuXG5cblxufSAvL2VuZCBvZiBpZiAoTWV0ZW9yLmlzU2VydmVyKVxuIiwiaW1wb3J0IHtNZXRlb3J9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHtNb25nb30gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCB7IGNoZWNrIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJztcbmltcG9ydCB7IENoZWNrZGJhY2Nlc3MgfSBmcm9tICcvc2VydmVyL2RiYXBpL3Rvb2xzL2NoZWNrZGJhY2Nlc3MudHMnO1xuXG5pbXBvcnQgeyBDb21wZXRlbmN5REIgfSBmcm9tICcvaW1wb3J0cy9hcGkvaW5kZXgudHMnO1xuXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG5cblxuXG4vLyA9PT09PSBzdGFydCBvZiBwdWJsaXNoQWxsQ2F0ZWdvcmllcyA9PT09PT1cbk1ldGVvci5wdWJsaXNoKCdwdWJsaXNoQWxsQ29tcGV0ZW5jaWVzJywgZnVuY3Rpb24gKCkge1xuXG4gIHJldHVybiBDb21wZXRlbmN5REIuZmluZCh7fSk7XG5cbn0pO1xuLy8gLS0tIEVuZCBvZiBwdWJsaXNoQWxsQ2F0ZWdvcmllcyAtLS1cblxuXG5cbn0gLy9lbmQgb2YgaWYgKE1ldGVvci5pc1NlcnZlcilcbiIsImltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7TW9uZ299IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjayc7XG5pbXBvcnQgeyBDaGVja2RiYWNjZXNzIH0gZnJvbSAnL3NlcnZlci9kYmFwaS90b29scy9jaGVja2RiYWNjZXNzLnRzJztcblxuaW1wb3J0IHsgQ291cnNlREIgfSBmcm9tICcvaW1wb3J0cy9hcGkvaW5kZXgudHMnO1xuXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG5cblxuXG4vLyA9PT09PSBzdGFydCBvZiBwdWJsaXNoQWxsSW5zdGl0dXRlID09PT09PVxuTWV0ZW9yLnB1Ymxpc2goJ3B1Ymxpc2hBbGxDb3Vyc2VzJywgZnVuY3Rpb24gKCkge1xuXG4gIHJldHVybiBDb3Vyc2VEQi5maW5kKHt9KTtcblxufSk7XG4vLyAtLS0gRW5kIG9mIHB1Ymxpc2hBbGxJbnN0aXR1dGUgLS0tXG5cblxuXG59IC8vZW5kIG9mIGlmIChNZXRlb3IuaXNTZXJ2ZXIpXG4iLCJpbXBvcnQge01ldGVvcn0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQge01vbmdvfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IHsgY2hlY2sgfSBmcm9tICdtZXRlb3IvY2hlY2snO1xuaW1wb3J0IHsgQ2hlY2tkYmFjY2VzcyB9IGZyb20gJy9zZXJ2ZXIvZGJhcGkvdG9vbHMvY2hlY2tkYmFjY2Vzcy50cyc7XG5cbmltcG9ydCB7IEZhY3VsdHlEQiB9IGZyb20gJy9pbXBvcnRzL2FwaS9pbmRleC50cyc7XG5cbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcblxuXG5cbi8vID09PT09IHN0YXJ0IG9mIHB1Ymxpc2hBbGxGYWN1bHR5ID09PT09PVxuTWV0ZW9yLnB1Ymxpc2goJ3B1Ymxpc2hBbGxGYWN1bHRpZXMnLCBmdW5jdGlvbiAoKSB7XG5cbiAgcmV0dXJuIEZhY3VsdHlEQi5maW5kKHt9KTtcblxufSk7XG4vLyAtLS0gRW5kIG9mIHB1Ymxpc2hBbGxGYWN1bHR5IC0tLVxuXG5cbn0gLy9lbmQgb2YgaWYgKE1ldGVvci5pc1NlcnZlcilcbiIsImltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7TW9uZ299IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjayc7XG5pbXBvcnQgeyBDaGVja2RiYWNjZXNzIH0gZnJvbSAnL3NlcnZlci9kYmFwaS90b29scy9jaGVja2RiYWNjZXNzLnRzJztcblxuaW1wb3J0IHsgSW5zdGl0dXRlREIgfSBmcm9tICcvaW1wb3J0cy9hcGkvaW5kZXgudHMnO1xuXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG5cblxuXG4vLyA9PT09PSBzdGFydCBvZiBwdWJsaXNoQWxsSW5zdGl0dXRlID09PT09PVxuTWV0ZW9yLnB1Ymxpc2goJ3B1Ymxpc2hBbGxJbnN0aXR1dGVzJywgZnVuY3Rpb24gKCkge1xuXG4gIHJldHVybiBJbnN0aXR1dGVEQi5maW5kKHt9KTtcblxufSk7XG4vLyAtLS0gRW5kIG9mIHB1Ymxpc2hBbGxJbnN0aXR1dGUgLS0tXG5cblxuXG59IC8vZW5kIG9mIGlmIChNZXRlb3IuaXNTZXJ2ZXIpXG4iLCJpbXBvcnQge01ldGVvcn0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQge01vbmdvfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IHsgY2hlY2sgfSBmcm9tICdtZXRlb3IvY2hlY2snO1xuaW1wb3J0IHsgQ2hlY2tkYmFjY2VzcyB9IGZyb20gJy9zZXJ2ZXIvZGJhcGkvdG9vbHMvY2hlY2tkYmFjY2Vzcy50cyc7XG5cbmltcG9ydCB7IExldmVsREIgfSBmcm9tICcvaW1wb3J0cy9hcGkvaW5kZXgudHMnO1xuXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG5cblxuXG4vLyA9PT09PSBzdGFydCBvZiBwdWJsaXNoQWxsQ2F0ZWdvcmllcyA9PT09PT1cbk1ldGVvci5wdWJsaXNoKCdwdWJsaXNoQWxsTGV2ZWxzJywgZnVuY3Rpb24gKCkge1xuXG4gIHJldHVybiBMZXZlbERCLmZpbmQoe30pO1xuXG59KTtcbi8vIC0tLSBFbmQgb2YgcHVibGlzaEFsbENhdGVnb3JpZXMgLS0tXG5cblxuXG59IC8vZW5kIG9mIGlmIChNZXRlb3IuaXNTZXJ2ZXIpXG4iLCJpbXBvcnQge01ldGVvcn0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQge01vbmdvfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IHsgY2hlY2sgfSBmcm9tICdtZXRlb3IvY2hlY2snO1xuaW1wb3J0IHsgQ2hlY2tkYmFjY2VzcyB9IGZyb20gJy9zZXJ2ZXIvZGJhcGkvdG9vbHMvY2hlY2tkYmFjY2Vzcy50cyc7XG5cbmltcG9ydCB7IE1ldGFkYXRhREIgfSBmcm9tICcvaW1wb3J0cy9hcGkvaW5kZXgudHMnO1xuXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG5cblxuXG4vLyA9PT09PSBzdGFydCBvZiBwdWJsaXNoQWxsTWV0YWRhdGEgPT09PT09XG5NZXRlb3IucHVibGlzaCgncHVibGlzaEFsbE1ldGFkYXRhJywgZnVuY3Rpb24gKCkge1xuXG4gIHJldHVybiBNZXRhZGF0YURCLmZpbmQoe30pO1xuXG59KTtcbi8vIC0tLSBFbmQgb2YgcHVibGlzaEFsbE1ldGFkYXRhIC0tLVxuXG5cblxufSAvL2VuZCBvZiBpZiAoTWV0ZW9yLmlzU2VydmVyKVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjayc7XG5pbXBvcnQgeyBDaGVja2RiYWNjZXNzIH0gZnJvbSAnL3NlcnZlci9kYmFwaS90b29scy9jaGVja2RiYWNjZXNzLnRzJztcblxuaW1wb3J0IHsgUHJvZmlsZURCIH0gZnJvbSAnL2ltcG9ydHMvYXBpL2luZGV4LnRzJztcblxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xuXG5cblxuICAvLyA9PT09PSBzdGFydCBvZiBteVByb2ZpbGVEQiA9PT09PT1cbiAgTWV0ZW9yLnB1Ymxpc2goXCJteVByb2ZpbGVEQlwiLCBmdW5jdGlvbigpIHtcbiAgICAvLyBwdWJsaXNoaW5nIFByb2ZpbGVEQiBmb3IgYSBzaW5nbGUgcmVxdWVzdGluZyB1c2VyXG4gICAgaWYgKHRoaXMudXNlcklkKSB7XG4gICAgICByZXR1cm4gUHJvZmlsZURCLmZpbmQoeyBcInVzZXJBY2NvdW50SURcIjogdGhpcy51c2VySWQgfSk7XG4gICAgfVxuXG4gICAgcmV0dXJuIHRoaXMucmVhZHkoKTtcblxuICB9KTtcblxuICAvLyAtLS0gRW5kIG9mIG15UHJvZmlsZURCIC0tLVxuXG4gIE1ldGVvci5wdWJsaXNoKFwicHVibGlzaEFsbFVzZXJQcm9maWxlRm9yQWRtaW5cIiwgZnVuY3Rpb24oKSB7XG4gICAgcmV0dXJuIFByb2ZpbGVEQi5maW5kKHt9KTtcbiAgfSk7XG5cblxuXG5cbn0gLy9lbmQgb2YgaWYgKE1ldGVvci5pc1NlcnZlcilcbiIsImltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7TW9uZ299IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjayc7XG5pbXBvcnQgeyBDaGVja2RiYWNjZXNzIH0gZnJvbSAnL3NlcnZlci9kYmFwaS90b29scy9jaGVja2RiYWNjZXNzLnRzJztcblxuaW1wb3J0IHsgVG9vbERCIH0gZnJvbSAnL2ltcG9ydHMvYXBpL2luZGV4LnRzJztcblxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xuXG5cblxuLy8gPT09PT0gc3RhcnQgb2YgcHVibGlzaEFsbFRvb2xzID09PT09PVxuTWV0ZW9yLnB1Ymxpc2goJ3B1Ymxpc2hBbGxUb29scycsIGZ1bmN0aW9uICgpIHtcblxuICByZXR1cm4gVG9vbERCLmZpbmQoe30pO1xuXG59KTtcbi8vIC0tLSBFbmQgb2YgcHVibGlzaEFsbFRvb2xzIC0tLVxuXG5cblxufSAvL2VuZCBvZiBpZiAoTWV0ZW9yLmlzU2VydmVyKVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjayc7XG5pbXBvcnQgeyBDaGVja2RiYWNjZXNzIH0gZnJvbSAnL3NlcnZlci9kYmFwaS90b29scy9jaGVja2RiYWNjZXNzLnRzJztcbmltcG9ydCB7IEFwcENvbmZpZyB9IGZyb20gJy4uLy4uL3N0YXJ0dXAvYXBwY29uZmlnJztcblxudmFyIGJhZGdlbG9yQXBwQ29uZmlnID0gbmV3IEFwcENvbmZpZygpO1xuY29uc3Qgc3lzdGVtQWRtaW5FbWFpbCA9IGJhZGdlbG9yQXBwQ29uZmlnLmFkbWluRW1haWw7XG5cbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcblxuXG5cblxuICBNZXRlb3IucHVibGlzaChcInB1Ymxpc2hBbGxVc2VyRm9yQWRtaW5cIiwgZnVuY3Rpb24oKSB7XG5cbiAgICBpZiAodGhpcy51c2VySWQpIHtcblxuICAgICAgcmV0dXJuIE1ldGVvci51c2Vycy5maW5kKCk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLnJlYWR5KCk7XG5cbiAgfSk7XG5cbiAgTWV0ZW9yLnB1Ymxpc2goXCJwdWJsaXNoQWxsVXNlckZvckFkbWluU3RhdGlzdGljc1wiLCBmdW5jdGlvbigpIHtcblxuICAgIGlmICh0aGlzLnVzZXJJZCkge1xuXG5cbiAgICAgIHJldHVybiBNZXRlb3IudXNlcnMuZmluZCh7XCJlbWFpbHMuYWRkcmVzc1wiOnskbmU6c3lzdGVtQWRtaW5FbWFpbH19KTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMucmVhZHkoKTtcblxuICB9KTtcblxuXG5cblxufSAvL2VuZCBvZiBpZiAoTWV0ZW9yLmlzU2VydmVyKVxuIiwiLy8gdGhpcyBjbGFzcyB3aWxsIGhhdmUgY29tbW9uIGZ1bmN0aW9ucyB0byBjaGVjayBkYiBhY2Nlc3MgcmlnaHRzIGZvciBhIHVzZXJcblxuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5cblxuZXhwb3J0IGNsYXNzIENoZWNrZGJhY2Nlc3Mge1xuXG4vL3VzZXJJRCA6IHN0cmluZztcblxuY29uc3RydWN0b3IoKSB7XG5cbn1cblxuLy8gdGhpcyBmdW5jdGlvbiBjaGVjayBpZiB0aGUgcGFzc2VkIHVzZXJJZCBiZWxvbmdzIHRvIGFuIGFkbWluIHVzZXIgKHdobyBoYXMgdGhlIHJvbGU9YWRtaW4pXG4vLyByZXR1cm4gdHJ1ZSBpZiB0aGUgdXNlciBpcyBhbiBhZG1pblxuaXNSb2xlQWRtaW4odXNlcklEKXtcbiAgdmFyIHVzZXJEQjtcbiAgdHJ5IHtcbiAgICB1c2VyREIgPSBNZXRlb3IudXNlcnMuZmluZE9uZSh7IFwiX2lkXCI6dXNlcklEIH0pO1xuICAgIGlmICh1c2VyREJbXCJyb2xlXCJdID09PSBcImFkbWluXCIpIHtcbiAgICAgIC8vIHRoaXMgdXNlciBpcyBhbiBhZG1pblxuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGVsc2V7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICB9IGNhdGNoIChlcnIpIHtcbiAgICAvLyBjb25zb2xlLmxvZyhlcnIpO1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxufSAvL2VuZCBvZiBpc1JvbGVBZG1pblxuXG5pc1JvbGVBcHBsaWNhbnQodXNlcklEKXtcbiAgdmFyIHVzZXJEQjtcbiAgdHJ5IHtcbiAgICB1c2VyREIgPSBNZXRlb3IudXNlcnMuZmluZE9uZSh7IFwiX2lkXCI6dXNlcklEIH0pO1xuICAgIGlmICh1c2VyREJbXCJyb2xlXCJdID09PSBcImFwcGxpY2FudFwiKSB7XG4gICAgICAvLyB0aGlzIHVzZXIgaXMgYW4gYWRtaW5cbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBlbHNle1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgLy8gY29uc29sZS5sb2coZXJyKTtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbn0gLy9lbmQgb2YgaXNSb2xlQXBwbGljYW50XG5cbmlzUm9sZUNyZWF0b3IodXNlcklEKSB7XG4gIHZhciB1c2VyREI7XG4gIHRyeSB7XG4gICAgdXNlckRCID0gTWV0ZW9yLnVzZXJzLmZpbmRPbmUoeyBcIl9pZFwiOnVzZXJJRCB9KTtcbiAgICBpZiAodXNlckRCW1wicm9sZVwiXSA9PT0gXCJjcmVhdG9yXCIpIHtcbiAgICAgIC8vIHRoaXMgdXNlciBpcyBhbiBhZG1pblxuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGVsc2V7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICB9IGNhdGNoIChlcnIpIHtcbiAgICAvLyBjb25zb2xlLmxvZyhlcnIpO1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxufVxuXG5cblxufS8vIGVuZCBvZiBjbGFzc1xuIiwiLy8gdGhpcyBjbGFzcyB3aWxsIGhhdmUgIGZ1bmN0aW9ucyB0byBjaGVjayBmZWF0dXJlIGFjY2VzcyByaWdodHMgXG5cbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuXG5cbmV4cG9ydCBjbGFzcyBGZWF0dXJlQWNjZXNzQ29udHJvbGxlciB7XG5cbiAgY29uc3RydWN0b3IoKSB7XG5cbiAgfVxuXG5cbn0vLyBlbmQgb2YgY2xhc3MgRmVhdHVyZUFjY2Vzc0NvbnRyb2xsZXJcbiIsImltcG9ydCB7IE1ldGVvck9ic2VydmFibGUgfSBmcm9tIFwibWV0ZW9yLXJ4anNcIjtcbmltcG9ydCB7IEhUVFAgfSBmcm9tICdtZXRlb3IvaHR0cCc7XG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IEFjY291bnRzIH0gZnJvbSAnbWV0ZW9yL2FjY291bnRzLWJhc2UnO1xuaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IHsgTW9uZ29PYnNlcnZhYmxlIH0gZnJvbSAnbWV0ZW9yLXJ4anMnO1xuaW1wb3J0IHsgY2hlY2sgfSBmcm9tICdtZXRlb3IvY2hlY2snO1xuXG4vLyBtb2R1bGVzIGZvciBsZGFwIGFuZCBhc3luY2ggbWV0aG9kIHJldHVyblxuaW1wb3J0IEZ1dHVyZSBmcm9tICdmaWJlcnMvZnV0dXJlJztcbmltcG9ydCBhc3NlcnQgZnJvbSAnYXNzZXJ0JztcbmltcG9ydCBsZGFwIGZyb20gJ2xkYXBqcyc7XG5cbmRlY2xhcmUgdmFyIHJlcXVpcmU6IGFueVxuXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG5cbiAgTWV0ZW9yLm1ldGhvZHMoe1xuXG5cblxuICAgIC8vIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuICAgIC8vPT09PT09PT09PT0gTERBUCBhY2Nlc3MgTWV0aG9kID09PT09PT09PVxuICAgIC8vIFRoaXMgbWV0aG9kIGlzIHVzZWQgZm9yIHNlYXJjaCB1c2VyXG4gICAgLy8gb2YgVW5pdmVyc2l0eSBvZiBLb2JsZW56IGFuZCBMYW5kYXVcbiAgICAvLyBGaWxlcyB1c2luZyB0aGlzIG1ldGhvZCA6IGFjY291bnRTZXJ2aWNlLnRzXG4gICAgLy8gLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG5cbiAgICAnYmluZEFuZFNlYXJjaCcoZGF0YSkge1xuXG5cbiAgICAgIC8vIENyZWF0ZSBvdXIgZnV0dXJlIGluc3RhbmNlLlxuICAgICAgdmFyIEZ1dHVyZSA9IE5wbS5yZXF1aXJlKCdmaWJlcnMvZnV0dXJlJyk7XG4gICAgICB2YXIgZnV0dXJlID0gbmV3IEZ1dHVyZSgpO1xuXG4gICAgICB2YXIgY2xpZW50RmVlZGJhY2sgPSB7XG4gICAgICAgIGVycm9yOiBcIm5vIGVycm9yXCIsXG4gICAgICAgIGZpcnN0TmFtZTogXCJcIixcbiAgICAgICAgbGFzdE5hbWU6IFwiXCIsXG4gICAgICAgIGVkdVBlcnNvbkFmZmlsaWF0aW9uOiBcIlwiXG4gICAgICB9O1xuXG4gICAgICB2YXIgbGRhcCA9IHJlcXVpcmUoJ2xkYXBqcycpO1xuICAgICAgdmFyIGNsaWVudCA9IGxkYXAuY3JlYXRlQ2xpZW50KHtcbiAgICAgICAgdXJsOiAnbGRhcDovL2xkYXAudW5pLWtvYmxlbnouZGU6Mzg5J1xuICAgICAgfSk7XG4gICAgICB2YXIgb3B0cyA9IHtcbiAgICAgICAgZmlsdGVyOiAnKG9iamVjdGNsYXNzPSopJyxcbiAgICAgICAgc2NvcGU6ICdiYXNlJyxcbiAgICAgICAgLy8gYXR0cmlidXRlczogWydtYWlsJywgJ2NuJywgJ2VkdVBlcnNvbkFmZmlsaWF0aW9uJ10sXG4gICAgICAgIGF0dHJpYnV0ZXM6IFtdLFxuICAgICAgICBzaXplTGltaXQ6IDAgLy8wPXVubGltaXRlZFxuICAgICAgfTtcblxuXG4gICAgICBjbGllbnQuYmluZCgndWlkPScgKyBkYXRhLnVzZXJuYW1lICsgJyxvdT0nICsgZGF0YS5vdTEgKyAnLG91PScgKyBkYXRhLm91MiArICcsZGM9VW5pLUtvYmxlbnotbGFuZGF1LGRjPWRlJywgZGF0YS5wYXNzd29yZCxcbiAgICAgICAgZnVuY3Rpb24gY2FsbGJhY2soZXJyLCByZXNwb25zZSkge1xuICAgICAgICAgIC8vYXNzZXJ0LmlmRXJyb3IoZXJyKTtcbiAgICAgICAgICAvL2NvbnNvbGUubG9nKHJlc3BvbnNlKTtcbiAgICAgICAgICBpZiAoZXJyKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZygnYmluZCB1bnN1Y2Nlc3NmdWwsIGluIGVycm9yIGJsb2NrJyk7XG4gICAgICAgICAgICBjbGllbnRGZWVkYmFjay5lcnJvciA9IFwiSW52YWxpZCBwYXNzd29yZFwiO1xuICAgICAgICAgICAgZnV0dXJlLnJldHVybihjbGllbnRGZWVkYmFjayk7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgaWYgKCFlcnIpIHtcbiAgICAgICAgICAgIGlmIChyZXNwb25zZSkge1xuICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhyZXNwb25zZSk7XG4gICAgICAgICAgICAgIC8vIG5vdyBiaW5kIGlzIGRvbmVcbiAgICAgICAgICAgICAgLy8gbGV0cyBzZWFyY2hcblxuICAgICAgICAgICAgICBjbGllbnQuc2VhcmNoKCd1aWQ9JyArIGRhdGEuc2VhcmNoVXNlck5hbWUgKyAnLG91PScgKyBkYXRhLm91MyArICcsb3U9JyArIGRhdGEub3U0ICsgJyxkYz1VbmktS29ibGVuei1sYW5kYXUsZGM9ZGUnLCBvcHRzLCBmdW5jdGlvbihlcnIsIHJlc3BvbnNlKSB7XG4gICAgICAgICAgICAgICAgdmFyIGFzc2VydCA9IHJlcXVpcmUoJ2Fzc2VydCcpO1xuICAgICAgICAgICAgICAgIGFzc2VydC5pZkVycm9yKGVycik7XG4gICAgICAgICAgICAgICAgcmVzcG9uc2Uub24oJ3NlYXJjaEVudHJ5JywgZnVuY3Rpb24gY2FsbGJhY2socmVzdWx0KSB7XG4gICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZygnZW50cnk6ICcgKyBKU09OLnN0cmluZ2lmeShyZXN1bHQub2JqZWN0KSk7XG4gICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhyZXN1bHQub2JqZWN0KTtcbiAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiSGVsbG8gOiBcIiArIHJlc3VsdC5vYmplY3QuZ2l2ZW5OYW1lKTsgLy8gZXh0cmFjdCBGaXJzdCBOYW1lXG4gICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhyZXN1bHQub2JqZWN0Lm1haWwpOyAvLyBleHRyYWN0IGVtYWlsIGFkZHJlc3NcblxuXG4gICAgICAgICAgICAgICAgICAvLyB3ZSB1c2UgY29uZGl0aW9uIGhlcmUgYXMgc29tZSBkdW1teSBhY2NvdW50cyBtaWdodCBub3QgaGF2ZSBuYW1lXG4gICAgICAgICAgICAgICAgICAvLyBUT0RPOiBjbGVhbnVwIGNvZGUgb25jZSB3ZSBubyBsb25nZXIgdXNlciBkdW1teSBhY2NvdW50cy5cbiAgICAgICAgICAgICAgICAgIGlmIChyZXN1bHQub2JqZWN0LmdpdmVuTmFtZSAmJiByZXN1bHQub2JqZWN0LnNuKSB7XG4gICAgICAgICAgICAgICAgICAgIGNsaWVudEZlZWRiYWNrLmZpcnN0TmFtZSA9IHJlc3VsdC5vYmplY3QuZ2l2ZW5OYW1lO1xuICAgICAgICAgICAgICAgICAgICBjbGllbnRGZWVkYmFjay5sYXN0TmFtZSA9IHJlc3VsdC5vYmplY3Quc247XG4gICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBjbGllbnRGZWVkYmFjay5maXJzdE5hbWUgPSBcIlVzZXI6XCI7XG4gICAgICAgICAgICAgICAgICAgIGNsaWVudEZlZWRiYWNrLmxhc3ROYW1lID0gZGF0YS5zZWFyY2hVc2VyTmFtZTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIGlmIChyZXN1bHQub2JqZWN0LmVkdVBlcnNvbkFmZmlsaWF0aW9uKSB7XG4gICAgICAgICAgICAgICAgICAgIGNsaWVudEZlZWRiYWNrLmVkdVBlcnNvbkFmZmlsaWF0aW9uID0gcmVzdWx0Lm9iamVjdC5lZHVQZXJzb25BZmZpbGlhdGlvblsxXTtcbiAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGNsaWVudEZlZWRiYWNrLmVkdVBlcnNvbkFmZmlsaWF0aW9uID0gXCJBbHVtbmlcIjtcbiAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgZnV0dXJlLnJldHVybihjbGllbnRGZWVkYmFjayk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgcmVzcG9uc2Uub24oJ2Vycm9yJywgZnVuY3Rpb24oZXJyKSB7XG4gICAgICAgICAgICAgICAgICBjbGllbnRGZWVkYmFjay5lcnJvciA9IFwiVXNlciBub3QgZm91bmQgaW4gdGhlIGRhdGFiYXNlIVwiO1xuICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignZXJyb3I6ICcgKyBlcnIubWVzc2FnZSk7XG4gICAgICAgICAgICAgICAgICBmdXR1cmUucmV0dXJuKGNsaWVudEZlZWRiYWNrKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgIH0gLy8gZW5kIGlmKHJlc3BvbnNlKVxuXG4gICAgICAgICAgfSAvL2VuZCBpZiAoIWVycilcblxuICAgICAgICB9KTsgLy9lbmQgY2xpZW50LmJpbmRcblxuICAgICAgcmV0dXJuIGZ1dHVyZS53YWl0KCk7XG5cbiAgICB9LCAvLyBlbmQgb2YgYmluZEFuZFNlYXJjaCgpIG1ldGhvZFxuXG4gICAgLy8gd2UgYXJlIGdvaW5nIHRvIHVzZSBvbmx5TG9naW4gbWV0aG9kIGZvciBsb2dpbiBwdXJwb3NlXG4gICAgLy8gaW5zdGVhZCBvZiBiaW5kIGFuZCBzZWFyY2ggbWV0aG9kLiBJdCBwZXJmb3JtcyBmYXN0ZXJcbiAgICAvLyAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cbiAgICAvLz09PT09PT09PT09IExEQVAgYWNjZXNzIE1ldGhvZCA9PT09PT09PT1cbiAgICAvLyBUaGlzIG1ldGhvZCBpcyB1c2VkIGZvciBsb2dpbiB1c2VyXG4gICAgLy8gb2YgVW5pdmVyc2l0eSBvZiBLb2JsZW56IGFuZCBMYW5kYXVcbiAgICAvLyBGaWxlcyB1c2luZyB0aGlzIG1ldGhvZCA6IGFjY291bnRTZXJ2aWNlLnRzXG4gICAgLy8gLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG5cbiAgICAnb25seUxvZ2luJyhkYXRhKSB7XG5cbiAgICAgIC8vIENyZWF0ZSBvdXIgZnV0dXJlIGluc3RhbmNlLlxuICAgICAgdmFyIEZ1dHVyZSA9IE5wbS5yZXF1aXJlKCdmaWJlcnMvZnV0dXJlJyk7XG4gICAgICB2YXIgZnV0dXJlID0gbmV3IEZ1dHVyZSgpO1xuXG4gICAgICB2YXIgY2xpZW50RmVlZGJhY2sgPSB7XG4gICAgICAgIGZlZWRiYWNrOiBcImVycm9yXCIsXG4gICAgICAgIG5hbWU6IFwiXCIsXG4gICAgICAgIGVkdVBlcnNvbkFmZmlsaWF0aW9uOiBcIlwiXG4gICAgICB9O1xuICAgICAgdmFyIGxkYXAgPSByZXF1aXJlKCdsZGFwanMnKTtcbiAgICAgIHZhciBjbGllbnQgPSBsZGFwLmNyZWF0ZUNsaWVudCh7XG4gICAgICAgIHVybDogJ2xkYXA6Ly9sZGFwLnVuaS1rb2JsZW56LmRlOjM4OSdcbiAgICAgIH0pO1xuXG4gICAgICBjbGllbnQuYmluZCgndWlkPScgKyBkYXRhLnVzZXJuYW1lICsgJyxvdT0nICsgZGF0YS5vdTEgKyAnLG91PScgKyBkYXRhLm91MiArICcsZGM9VW5pLUtvYmxlbnotbGFuZGF1LGRjPWRlJywgZGF0YS5wYXNzd29yZCxcbiAgICAgICAgZnVuY3Rpb24gY2FsbGJhY2soZXJyLCByZXNwb25zZSkge1xuICAgICAgICAgIC8vIGFzc2VydC5pZkVycm9yKGVycik7XG4gICAgICAgICAgLy8gY29uc29sZS5sb2cocmVzcG9uc2UpO1xuICAgICAgICAgIGlmIChlcnIpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdiaW5kIHVuc3VjY2Vzc2Z1bCwgaW4gZXJyb3IgYmxvY2snKTtcbiAgICAgICAgICAgIGNsaWVudEZlZWRiYWNrLmZlZWRiYWNrID0gXCJJbnZhbGlkIHBhc3N3b3JkXCI7XG4gICAgICAgICAgICBmdXR1cmUucmV0dXJuKGNsaWVudEZlZWRiYWNrKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKCFlcnIpIHtcbiAgICAgICAgICAgIGlmIChyZXNwb25zZSkge1xuICAgICAgICAgICAgICBjbGllbnRGZWVkYmFjay5mZWVkYmFjayA9IFwiTG9naW4gc3VjY2Vzc2Z1bFwiO1xuICAgICAgICAgICAgICBmdXR1cmUucmV0dXJuKGNsaWVudEZlZWRiYWNrKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgcmV0dXJuIGZ1dHVyZS53YWl0KCk7XG4gICAgfVxuXG5cbiAgfSk7IC8vIGVuZCBNZXRlb3IubWV0aG9kc1xuXG59IC8vZW5kIGlmIChNZXRlb3IuaXNTZXJ2ZXIpXG4iLCJpbXBvcnQge01ldGVvck9ic2VydmFibGV9IGZyb20gXCJtZXRlb3Itcnhqc1wiO1xuaW1wb3J0IHsgSFRUUCB9IGZyb20gJ21ldGVvci9odHRwJztcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgQWNjb3VudHMgfSBmcm9tICdtZXRlb3IvYWNjb3VudHMtYmFzZSc7XG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgeyBNb25nb09ic2VydmFibGUgfSBmcm9tICdtZXRlb3Itcnhqcyc7XG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjayc7XG5pbXBvcnQgRnV0dXJlIGZyb20gJ2ZpYmVycy9mdXR1cmUnO1xuXG5pbXBvcnQgeyBBcHBDb25maWcgfSBmcm9tICcvc2VydmVyL3N0YXJ0dXAvYXBwY29uZmlnJztcblxuY29uc3QgYXBpVXJsID0gJ2h0dHBzOi8vb3BlbmJhZGdlZmFjdG9yeS5jb20vdjEvYmFkZ2UvTk03ME9IZTdIQ2VPJztcbmNvbnN0IGFwaVVybEZvckVhcm5hYmxlQmFkZ2UgPSAnaHR0cHM6Ly9vcGVuYmFkZ2VmYWN0b3J5LmNvbS92MS9lYXJuYWJsZWJhZGdlL05NNzBPSGU3SENlTz92aXNpYmxlPTEnO1xuXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG5cbiAgTWV0ZW9yLm1ldGhvZHMoe1xuXG4gICAgLy8gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gICAgLy8gID09PT09PT09PT0gY3JlYXRlIG5ldyBiYWRnZSA9PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgLy8gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG5cbiAgICAnY3JlYXRlQmFkZ2UnKGRhdGEpIHtcbiAgICAgICAgICB0aGlzLnVuYmxvY2soKTtcblxuICAgICAgICAgIHZhciBiYWRnZWxvckFwcENvbmZpZyA9IG5ldyBBcHBDb25maWcoKTtcblxuICAgICAgICAgIGxldCBhcGlDYWxsID0gZnVuY3Rpb24gKGFwaVVybCwgY2FsbGJhY2spIHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAuY2FsbCggXCJQT1NUXCIsIGFwaVVybCxcbiAgICAgICAgICAgICAgICB7bnBtUmVxdWVzdE9wdGlvbnM6IHtcbiAgICAgICAgICAgICAgICAgIGtleTogYmFkZ2Vsb3JBcHBDb25maWcub2JmS2V5LFxuICAgICAgICAgICAgICAgICAgY2VydDogYmFkZ2Vsb3JBcHBDb25maWcub2JmQ2VydGlmaWNhdGUsXG4gICAgICAgICAgICAgICAgfSxkYXRhfSxcbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgY2FsbGJhY2sobnVsbCwgcmVzcG9uc2UpO1xuICAgICAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgbGV0IGVycm9yQ29kZTtcbiAgICAgICAgICAgICAgbGV0IGVycm9yTWVzc2FnZTtcbiAgICAgICAgICAgICAgaWYgKGVycm9yLnJlc3BvbnNlKSB7XG4gICAgICAgICAgICAgICAgZXJyb3JDb2RlID0gZXJyb3IucmVzcG9uc2UuZGF0YS5jb2RlO1xuICAgICAgICAgICAgICAgIGVycm9yTWVzc2FnZSA9IGVycm9yLnJlc3BvbnNlLmRhdGEubWVzc2FnZTtcbiAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBlcnJvckNvZGUgPSA1MDA7XG4gICAgICAgICAgICAgICAgZXJyb3JNZXNzYWdlID0gJ0Nhbm5vdCBhY2Nlc3MgdGhlIEFQSSc7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgbGV0IG15RXJyb3IgPSBuZXcgTWV0ZW9yLkVycm9yKGVycm9yQ29kZSwgZXJyb3JNZXNzYWdlKTtcbiAgICAgICAgICAgICAgY2FsbGJhY2sobXlFcnJvciwgbnVsbCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgbGV0IHJlc3BvbnNlID0gTWV0ZW9yLndyYXBBc3luYyhhcGlDYWxsKShhcGlVcmwpO1xuXG4gICAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuXG5cbiAgICAgIH0sXG5cbiAgICAgICd1cGRhdGVTaW5nbGVCYWRnZScoZGF0YSkge1xuICAgICAgICAgICAgdGhpcy51bmJsb2NrKCk7XG5cbiAgICAgICAgICAgIHZhciBiYWRnZWxvckFwcENvbmZpZyA9IG5ldyBBcHBDb25maWcoKTtcblxuICAgICAgICAgICAgbGV0IGFwaUNhbGwgPSBmdW5jdGlvbiAoYXBpVXJsLCBjYWxsYmFjaykge1xuICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAuY2FsbCggXCJQVVRcIiwgYXBpVXJsKycvJytkYXRhLmJhZGdlX2lkLFxuICAgICAgICAgICAgICAgICAge25wbVJlcXVlc3RPcHRpb25zOiB7XG4gICAgICAgICAgICAgICAgICAgIGtleTogYmFkZ2Vsb3JBcHBDb25maWcub2JmS2V5LFxuICAgICAgICAgICAgICAgICAgICBjZXJ0OiBiYWRnZWxvckFwcENvbmZpZy5vYmZDZXJ0aWZpY2F0ZSxcbiAgICAgICAgICAgICAgICAgIH0sZGF0YX0sXG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICBjYWxsYmFjayhudWxsLCByZXNwb25zZSk7XG4gICAgICAgICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgbGV0IGVycm9yQ29kZTtcbiAgICAgICAgICAgICAgICBsZXQgZXJyb3JNZXNzYWdlO1xuICAgICAgICAgICAgICAgIGlmIChlcnJvci5yZXNwb25zZSkge1xuICAgICAgICAgICAgICAgICAgZXJyb3JDb2RlID0gZXJyb3IucmVzcG9uc2UuZGF0YS5jb2RlO1xuICAgICAgICAgICAgICAgICAgZXJyb3JNZXNzYWdlID0gZXJyb3IucmVzcG9uc2UuZGF0YS5tZXNzYWdlO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICBlcnJvckNvZGUgPSA1MDA7XG4gICAgICAgICAgICAgICAgICBlcnJvck1lc3NhZ2UgPSAnQ2Fubm90IGFjY2VzcyB0aGUgQVBJJztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgbGV0IG15RXJyb3IgPSBuZXcgTWV0ZW9yLkVycm9yKGVycm9yQ29kZSwgZXJyb3JNZXNzYWdlKTtcbiAgICAgICAgICAgICAgICBjYWxsYmFjayhteUVycm9yLCBudWxsKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBsZXQgcmVzcG9uc2UgPSBNZXRlb3Iud3JhcEFzeW5jKGFwaUNhbGwpKGFwaVVybCk7XG5cbiAgICAgICAgICAgIHJldHVybiByZXNwb25zZTtcblxuICAgICAgICB9LFxuXG5cbiAgICAnZ2V0RWFybmFibGVCYWRnZXMnKCkge1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcblxuICAgICAgICB2YXIgYmFkZ2Vsb3JBcHBDb25maWcgPSBuZXcgQXBwQ29uZmlnKCk7XG5cbiAgICAgICAgbGV0IGFwaUNhbGwgPSBmdW5jdGlvbiAoYXBpVXJsRm9yRWFybmFibGVCYWRnZSwgY2FsbGJhY2spIHtcbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5jYWxsKCBcIkdFVFwiLCBhcGlVcmxGb3JFYXJuYWJsZUJhZGdlLFxuICAgICAgICAgICAgICB7bnBtUmVxdWVzdE9wdGlvbnM6IHtcbiAgICAgICAgICAgICAgICBrZXk6IGJhZGdlbG9yQXBwQ29uZmlnLm9iZktleSxcbiAgICAgICAgICAgICAgICBjZXJ0OiBiYWRnZWxvckFwcENvbmZpZy5vYmZDZXJ0aWZpY2F0ZSxcbiAgICAgICAgICAgICAgfX0sXG4gICAgICAgICAgICApLmNvbnRlbnQ7XG4gICAgICAgICAgICBjYWxsYmFjayhudWxsLCByZXNwb25zZSk7XG4gICAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIGxldCBlcnJvckNvZGU7XG4gICAgICAgICAgICBsZXQgZXJyb3JNZXNzYWdlO1xuICAgICAgICAgICAgaWYgKGVycm9yLnJlc3BvbnNlKSB7XG4gICAgICAgICAgICAgIGVycm9yQ29kZSA9IGVycm9yLnJlc3BvbnNlLmRhdGEuY29kZTtcbiAgICAgICAgICAgICAgZXJyb3JNZXNzYWdlID0gZXJyb3IucmVzcG9uc2UuZGF0YS5tZXNzYWdlO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgZXJyb3JDb2RlID0gNTAwO1xuICAgICAgICAgICAgICBlcnJvck1lc3NhZ2UgPSAnQ2Fubm90IGFjY2VzcyB0aGUgQVBJJztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGxldCBteUVycm9yID0gbmV3IE1ldGVvci5FcnJvcihlcnJvckNvZGUsIGVycm9yTWVzc2FnZSk7XG4gICAgICAgICAgICBjYWxsYmFjayhteUVycm9yLCBudWxsKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAvLyBsZXQgYXBpVXJsID0gJ2h0dHBzOi8vb3BlbmJhZGdlZmFjdG9yeS5jb20vdjEvYmFkZ2UvTk03ME9IZTdIQ2VPJztcbiAgICAgICAgbGV0IHJlc3BvbnNlID0gTWV0ZW9yLndyYXBBc3luYyhhcGlDYWxsKShhcGlVcmxGb3JFYXJuYWJsZUJhZGdlKTtcbiAgICAgICAgcmVzcG9uc2UgPSByZXNwb25zZS50cmltKCk7XG4gICAgICAgIHJlc3BvbnNlID0gcmVzcG9uc2Uuc3BsaXQoL1xcclxcbi8pO1xuICAgICAgICByZXNwb25zZSA9IHJlc3BvbnNlLmpvaW4oJywnKTtcbiAgICAgICAgcmVzcG9uc2UgPSBcIltcIiArIHJlc3BvbnNlICsgXCJdXCI7XG4gICAgICAgIHJlc3BvbnNlID0gSlNPTi5wYXJzZShyZXNwb25zZSk7XG5cbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuXG4gICAgICAgIC8vID09PT09PT09PT09PT09PT09PT0gZm9yIGVhcm5hYmxlIGJhZGdlX2lkID09PT09PT1cbiAgICAgICAgLy8gdmFyIGEgPSBbXTtcbiAgICAgICAgLy8gZm9yIChsZXQga2V5IGluIHJlc3BvbnNlKSB7XG4gICAgICAgIC8vICAgYS5wdXNoKHJlc3BvbnNlW2tleV0uYmFkZ2VfaWQpO1xuICAgICAgICAvLyB9XG4gICAgICAgIC8vIGxldCBiID0gYS5qb2luKFwifFwiKTtcbiAgICAgICAgLy8gY29uc29sZS5sb2coYik7XG4gICAgICAgIC8vIHJldHVybiBiO1xuICAgICAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuXG4gICAgICB9LFxuXG4gICAgICAvLyAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gICAgICAvLyAgZ2V0IGEgc2luZ2xlIGJhZGdlXG4gICAgICAvLyAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG5cbiAgICAgICdnZXRTaW5nbGVCYWRnZScoYmFkZ2VfaWQpIHtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG5cbiAgICAgICAgbGV0IGJhZGdlbG9yQXBwQ29uZmlnID0gbmV3IEFwcENvbmZpZygpO1xuICAgICAgICBsZXQgYXBpVXJsRm9yU2luZ2xlQmFkZ2UgPSBhcGlVcmwrJy8nK2JhZGdlX2lkO1xuXG4gICAgICAgIGxldCBhcGlDYWxsID0gZnVuY3Rpb24gKGFwaVVybEZvclNpbmdsZUJhZGdlLCBjYWxsYmFjaykge1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLmNhbGwoIFwiR0VUXCIsIGFwaVVybEZvclNpbmdsZUJhZGdlLFxuICAgICAgICAgICAgICB7bnBtUmVxdWVzdE9wdGlvbnM6IHtcbiAgICAgICAgICAgICAgICBrZXk6IGJhZGdlbG9yQXBwQ29uZmlnLm9iZktleSxcbiAgICAgICAgICAgICAgICBjZXJ0OiBiYWRnZWxvckFwcENvbmZpZy5vYmZDZXJ0aWZpY2F0ZSxcbiAgICAgICAgICAgICAgfX0sXG4gICAgICAgICAgICApLmNvbnRlbnQ7XG4gICAgICAgICAgICBjYWxsYmFjayhudWxsLCByZXNwb25zZSk7XG4gICAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIGxldCBlcnJvckNvZGU7XG4gICAgICAgICAgICBsZXQgZXJyb3JNZXNzYWdlO1xuICAgICAgICAgICAgaWYgKGVycm9yLnJlc3BvbnNlKSB7XG4gICAgICAgICAgICAgIGVycm9yQ29kZSA9IGVycm9yLnJlc3BvbnNlLmRhdGEuY29kZTtcbiAgICAgICAgICAgICAgZXJyb3JNZXNzYWdlID0gZXJyb3IucmVzcG9uc2UuZGF0YS5tZXNzYWdlO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgZXJyb3JDb2RlID0gNTAwO1xuICAgICAgICAgICAgICBlcnJvck1lc3NhZ2UgPSAnQ2Fubm90IGFjY2VzcyB0aGUgQVBJJztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGxldCBteUVycm9yID0gbmV3IE1ldGVvci5FcnJvcihlcnJvckNvZGUsIGVycm9yTWVzc2FnZSk7XG4gICAgICAgICAgICBjYWxsYmFjayhteUVycm9yLCBudWxsKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBsZXQgcmVzcG9uc2UgPSBNZXRlb3Iud3JhcEFzeW5jKGFwaUNhbGwpKGFwaVVybEZvclNpbmdsZUJhZGdlKTtcbiAgICAgICAgcmVzcG9uc2UgPSByZXNwb25zZS50cmltKCk7XG4gICAgICAgIHJlc3BvbnNlID0gcmVzcG9uc2Uuc3BsaXQoL1xcclxcbi8pO1xuICAgICAgICByZXNwb25zZSA9IHJlc3BvbnNlLmpvaW4oJywnKTtcbiAgICAgICAgcmVzcG9uc2UgPSBKU09OLnBhcnNlKHJlc3BvbnNlKTtcblxuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICAgIH0sXG5cblxuICAgICAgLy8gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICAgICAgLy8gIGdldCBsaXN0IG9mIGJhZGdlcyBieSBpZFxuICAgICAgLy8gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICAgICAgJ2dldEJhZGdlc0J5SUQnKGxpc3RPZkJhZGdlSUQpIHtcblxuICAgICAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgICAgICB2YXIgYmFkZ2Vsb3JBcHBDb25maWcgPSBuZXcgQXBwQ29uZmlnKCk7XG5cbiAgICAgICAgICAgIHZhciBhcGlVcmxUb0dldExpc3RPZkJhZGdlRGF0YSA9IGFwaVVybCArIFwiLz9pZD1cIisgbGlzdE9mQmFkZ2VJRDtcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKGFwaVVybFRvR2V0TGlzdE9mQmFkZ2VEYXRhKTtcblxuICAgICAgICAgICAgbGV0IGFwaUNhbGwgPSBmdW5jdGlvbiAoYXBpVXJsVG9HZXRMaXN0T2ZCYWRnZURhdGEsIGNhbGxiYWNrKSB7XG4gICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5jYWxsKFxuICAgICAgICAgICAgICAgICAgXCJHRVRcIixcbiAgICAgICAgICAgICAgICAgIGFwaVVybFRvR2V0TGlzdE9mQmFkZ2VEYXRhLFxuICAgICAgICAgICAgICAgICAge25wbVJlcXVlc3RPcHRpb25zOiB7XG4gICAgICAgICAgICAgICAgICAgIGtleTogYmFkZ2Vsb3JBcHBDb25maWcub2JmS2V5LFxuICAgICAgICAgICAgICAgICAgICBjZXJ0OiBiYWRnZWxvckFwcENvbmZpZy5vYmZDZXJ0aWZpY2F0ZSxcbiAgICAgICAgICAgICAgICAgIH19LFxuICAgICAgICAgICAgICAgICkuY29udGVudDtcbiAgICAgICAgICAgICAgICBjYWxsYmFjayhudWxsLCByZXNwb25zZSk7XG4gICAgICAgICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgbGV0IGVycm9yQ29kZTtcbiAgICAgICAgICAgICAgICBsZXQgZXJyb3JNZXNzYWdlO1xuICAgICAgICAgICAgICAgIGlmIChlcnJvci5yZXNwb25zZSkge1xuICAgICAgICAgICAgICAgICAgZXJyb3JDb2RlID0gZXJyb3IucmVzcG9uc2UuZGF0YS5jb2RlO1xuICAgICAgICAgICAgICAgICAgZXJyb3JNZXNzYWdlID0gZXJyb3IucmVzcG9uc2UuZGF0YS5tZXNzYWdlO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICBlcnJvckNvZGUgPSA1MDA7XG4gICAgICAgICAgICAgICAgICBlcnJvck1lc3NhZ2UgPSAnQ2Fubm90IGFjY2VzcyB0aGUgQVBJJztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgbGV0IG15RXJyb3IgPSBuZXcgTWV0ZW9yLkVycm9yKGVycm9yQ29kZSwgZXJyb3JNZXNzYWdlKTtcbiAgICAgICAgICAgICAgICBjYWxsYmFjayhteUVycm9yLCBudWxsKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyBsZXQgYXBpVXJsID0gJ2h0dHBzOi8vb3BlbmJhZGdlZmFjdG9yeS5jb20vdjEvYmFkZ2UvTk03ME9IZTdIQ2VPJztcbiAgICAgICAgICAgIGxldCByZXNwb25zZSA9IE1ldGVvci53cmFwQXN5bmMoYXBpQ2FsbCkoYXBpVXJsVG9HZXRMaXN0T2ZCYWRnZURhdGEpO1xuICAgICAgICAgICAgcmVzcG9uc2UgPSByZXNwb25zZS50cmltKCk7XG4gICAgICAgICAgICByZXNwb25zZSA9IHJlc3BvbnNlLnNwbGl0KC9cXHJcXG4vKTtcbiAgICAgICAgICAgIHJlc3BvbnNlID0gcmVzcG9uc2Uuam9pbignLCcpO1xuICAgICAgICAgICAgcmVzcG9uc2UgPSBcIltcIiArIHJlc3BvbnNlICsgXCJdXCI7XG4gICAgICAgICAgICByZXNwb25zZSA9IEpTT04ucGFyc2UocmVzcG9uc2UpO1xuICAgICAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgfSxcblxuXG4gICAgICAvLyAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gICAgICAvLyAgZ2V0IGFsbCBiYWRnZXMgZm9yIGFkbWluXG4gICAgICAvLyAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG5cbiAgICAgICdnZXRBbGxCYWRnZXMnIDogZnVuY3Rpb24oKSB7XG4gICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICB2YXIgYmFkZ2Vsb3JBcHBDb25maWcgPSBuZXcgQXBwQ29uZmlnKCk7XG5cbiAgICAgICAgbGV0IGFwaUNhbGwgPSBmdW5jdGlvbiAoYXBpVXJsLCBjYWxsYmFjaykge1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLmNhbGwoXG4gICAgICAgICAgICAgIFwiR0VUXCIsXG4gICAgICAgICAgICAgIGFwaVVybCxcbiAgICAgICAgICAgICAge25wbVJlcXVlc3RPcHRpb25zOiB7XG4gICAgICAgICAgICAgICAga2V5OiBiYWRnZWxvckFwcENvbmZpZy5vYmZLZXksXG4gICAgICAgICAgICAgICAgY2VydDogYmFkZ2Vsb3JBcHBDb25maWcub2JmQ2VydGlmaWNhdGUsXG4gICAgICAgICAgICAgIH19LFxuICAgICAgICAgICAgKS5jb250ZW50O1xuICAgICAgICAgICAgY2FsbGJhY2sobnVsbCwgcmVzcG9uc2UpO1xuICAgICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICBsZXQgZXJyb3JDb2RlO1xuICAgICAgICAgICAgbGV0IGVycm9yTWVzc2FnZTtcbiAgICAgICAgICAgIGlmIChlcnJvci5yZXNwb25zZSkge1xuICAgICAgICAgICAgICBlcnJvckNvZGUgPSBlcnJvci5yZXNwb25zZS5kYXRhLmNvZGU7XG4gICAgICAgICAgICAgIGVycm9yTWVzc2FnZSA9IGVycm9yLnJlc3BvbnNlLmRhdGEubWVzc2FnZTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIGVycm9yQ29kZSA9IDUwMDtcbiAgICAgICAgICAgICAgZXJyb3JNZXNzYWdlID0gJ0Nhbm5vdCBhY2Nlc3MgdGhlIEFQSSc7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBsZXQgbXlFcnJvciA9IG5ldyBNZXRlb3IuRXJyb3IoZXJyb3JDb2RlLCBlcnJvck1lc3NhZ2UpO1xuICAgICAgICAgICAgY2FsbGJhY2sobXlFcnJvciwgbnVsbCk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gbGV0IGFwaVVybCA9ICdodHRwczovL29wZW5iYWRnZWZhY3RvcnkuY29tL3YxL2JhZGdlL05NNzBPSGU3SENlTyc7XG4gICAgICAgIGxldCByZXNwb25zZSA9IE1ldGVvci53cmFwQXN5bmMoYXBpQ2FsbCkoYXBpVXJsKTtcbiAgICAgICAgcmVzcG9uc2UgPSByZXNwb25zZS50cmltKCk7XG4gICAgICAgIHJlc3BvbnNlID0gcmVzcG9uc2Uuc3BsaXQoL1xcclxcbi8pO1xuICAgICAgICByZXNwb25zZSA9IHJlc3BvbnNlLmpvaW4oJywnKTtcbiAgICAgICAgcmVzcG9uc2UgPSBcIltcIiArIHJlc3BvbnNlICsgXCJdXCI7XG4gICAgICAgIHJlc3BvbnNlID0gSlNPTi5wYXJzZShyZXNwb25zZSk7XG5cbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuXG4gICAgICB9LFxuXG5cblxuICB9KTsgLy8gZW5kIE1ldGVvci5tZXRob2RzXG5cbn0gLy9lbmQgaWYgKE1ldGVvci5pc1NlcnZlcilcbiIsIi8vIEFsbCBhcHBsaWNhbnQgcmVsYXRlZCBBUEkgY2FsbCBtZXRob2RzIGFyZSBpbiB0aGlzIGZpbGVcbi8vIFRoaXMgbWV0aG9kcyBhcmUgdXNlZCBpbiB0aGUgZm9sbG93aW5nIGZpbGVzXG4vLyAxLiBhcHBsaWNhbnRQcm9maWxlLnRzXG4vLyAyLlxuLy8gMy5cblxuXG5pbXBvcnQge01ldGVvck9ic2VydmFibGV9IGZyb20gXCJtZXRlb3Itcnhqc1wiO1xuaW1wb3J0IHsgSFRUUCB9IGZyb20gJ21ldGVvci9odHRwJztcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgQWNjb3VudHMgfSBmcm9tICdtZXRlb3IvYWNjb3VudHMtYmFzZSc7XG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgeyBNb25nb09ic2VydmFibGUgfSBmcm9tICdtZXRlb3Itcnhqcyc7XG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjayc7XG5cbmltcG9ydCB7IEFwcENvbmZpZyB9IGZyb20gJy9zZXJ2ZXIvc3RhcnR1cC9hcHBjb25maWcnO1xuXG5jb25zdCBhcGlVcmwgPSAnaHR0cHM6Ly9vcGVuYmFkZ2VmYWN0b3J5LmNvbS92MS9iYWRnZS9OTTcwT0hlN0hDZU8nO1xuXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG5cbiAgTWV0ZW9yLm1ldGhvZHMoe1xuXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIC8vID09PT09PT0gR2V0IGFsbCBlYXJuYWJsZV9pZCA9PT09PT1cbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG5cbiAgICAnZ2V0RWFybmFibGVJZExpc3QnKCkge1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgdmFyIGJhZGdlbG9yQXBwQ29uZmlnID0gbmV3IEFwcENvbmZpZygpO1xuICAgICAgICBjb25zdCBhcGlVcmxGb3JFYXJuYWJsZUJhZGdlID0gJ2h0dHBzOi8vb3BlbmJhZGdlZmFjdG9yeS5jb20vdjEvZWFybmFibGViYWRnZS9OTTcwT0hlN0hDZU8nO1xuICAgICAgICBsZXQgYXBpQ2FsbCA9IGZ1bmN0aW9uIChhcGlVcmxGb3JFYXJuYWJsZUJhZGdlLCBjYWxsYmFjaykge1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLmNhbGwoIFwiR0VUXCIsIGFwaVVybEZvckVhcm5hYmxlQmFkZ2UsXG4gICAgICAgICAgICAgIHtucG1SZXF1ZXN0T3B0aW9uczoge1xuICAgICAgICAgICAgICAgIGtleTogYmFkZ2Vsb3JBcHBDb25maWcub2JmS2V5LFxuICAgICAgICAgICAgICAgIGNlcnQ6IGJhZGdlbG9yQXBwQ29uZmlnLm9iZkNlcnRpZmljYXRlLFxuICAgICAgICAgICAgICB9fSxcbiAgICAgICAgICAgICkuY29udGVudDtcbiAgICAgICAgICAgIGNhbGxiYWNrKG51bGwsIHJlc3BvbnNlKTtcbiAgICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgbGV0IGVycm9yQ29kZTtcbiAgICAgICAgICAgIGxldCBlcnJvck1lc3NhZ2U7XG4gICAgICAgICAgICBpZiAoZXJyb3IucmVzcG9uc2UpIHtcbiAgICAgICAgICAgICAgZXJyb3JDb2RlID0gZXJyb3IucmVzcG9uc2UuZGF0YS5jb2RlO1xuICAgICAgICAgICAgICBlcnJvck1lc3NhZ2UgPSBlcnJvci5yZXNwb25zZS5kYXRhLm1lc3NhZ2U7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICBlcnJvckNvZGUgPSA1MDA7XG4gICAgICAgICAgICAgIGVycm9yTWVzc2FnZSA9ICdDYW5ub3QgYWNjZXNzIHRoZSBBUEknO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbGV0IG15RXJyb3IgPSBuZXcgTWV0ZW9yLkVycm9yKGVycm9yQ29kZSwgZXJyb3JNZXNzYWdlKTtcbiAgICAgICAgICAgIGNhbGxiYWNrKG15RXJyb3IsIG51bGwpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGxldCByZXNwb25zZSA9IE1ldGVvci53cmFwQXN5bmMoYXBpQ2FsbCkoYXBpVXJsRm9yRWFybmFibGVCYWRnZSk7XG4gICAgICAgIHJlc3BvbnNlID0gcmVzcG9uc2UudHJpbSgpO1xuICAgICAgICByZXNwb25zZSA9IHJlc3BvbnNlLnNwbGl0KC9cXHJcXG4vKTtcbiAgICAgICAgcmVzcG9uc2UgPSByZXNwb25zZS5qb2luKCcsJyk7XG4gICAgICAgIHJlc3BvbnNlID0gXCJbXCIgKyByZXNwb25zZSArIFwiXVwiO1xuICAgICAgICByZXNwb25zZSA9IEpTT04ucGFyc2UocmVzcG9uc2UpO1xuXG4gICAgICAgIC8vID09PT09PT09PT09PT09PT0gZm9yIGVhcm5hYmxlX2lkID09PT09PT09PT09PT09PT09XG5cbiAgICAgICAgICBsZXQgb2JqID0gW107XG5cbiAgICAgICAgICBmb3IgKGxldCBrZXkgaW4gcmVzcG9uc2UpIHtcblxuICAgICAgICAgICAgICBvYmoucHVzaCh7XG4gICAgICAgICAgICAgICAgYmFkZ2VfaWQ6IHJlc3BvbnNlW2tleV0uYmFkZ2VfaWQsXG4gICAgICAgICAgICAgICAgZWFybmFibGVfaWQ6IHJlc3BvbnNlW2tleV0uaWQsXG4gICAgICAgICAgICAgICAgbmFtZTogcmVzcG9uc2Vba2V5XS5uYW1lXG4gICAgICAgICAgICAgIH0pXG5cbiAgICAgICAgICB9XG5cbiAgICAgICAgICByZXR1cm4gb2JqO1xuXG4gICAgICB9LFxuXG4gICAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgICAgLy8gPT09PT09PT0gR2V0IGFsbCBiYWRnZSBhcHBsaWNhdGlvbnMgPT09PT1cbiAgICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgICAvLyB3ZSBnZXQgYWxsIGFwcGxpY2F0aW9uIG9mIGFuIGFwcGxpY2FudFxuICAgICAgLy8gZmlsdGVyZWQgYnkgdGhlaXIgZW1haWwgYWRkcmVzc1xuXG4gICAgICAnZ2V0QWxsQmFkZ2VBcHBsaWNhdGlvbicoZWFybmFibGVJRCwgdXNlckVtYWlsKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKHVzZXJFbWFpbCk7XG4gICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICB2YXIgYmFkZ2Vsb3JBcHBDb25maWcgPSBuZXcgQXBwQ29uZmlnKCk7XG5cbiAgICAgICAgdmFyIGFwaVVybGZvckJhZGdlQXBwbGljYXRpb24gPSBcImh0dHBzOi8vb3BlbmJhZGdlZmFjdG9yeS5jb20vdjEvZWFybmFibGViYWRnZS9OTTcwT0hlN0hDZU9cIiArIFwiL1wiKyBlYXJuYWJsZUlEICsgXCIvYXBwbGljYXRpb25cIiA7XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKGFwaVVybFRvR2V0TGlzdE9mQmFkZ2VEYXRhKTtcblxuICAgICAgICBsZXQgYXBpQ2FsbCA9IGZ1bmN0aW9uIChhcGlVcmxmb3JCYWRnZUFwcGxpY2F0aW9uLCBjYWxsYmFjaykge1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLmNhbGwoIFwiR0VUXCIsIGFwaVVybGZvckJhZGdlQXBwbGljYXRpb24sXG4gICAgICAgICAgICAgIHtucG1SZXF1ZXN0T3B0aW9uczoge1xuICAgICAgICAgICAgICAgIGtleTogYmFkZ2Vsb3JBcHBDb25maWcub2JmS2V5LFxuICAgICAgICAgICAgICAgIGNlcnQ6IGJhZGdlbG9yQXBwQ29uZmlnLm9iZkNlcnRpZmljYXRlLFxuICAgICAgICAgICAgICB9fSxcbiAgICAgICAgICAgICkuY29udGVudDtcbiAgICAgICAgICAgIGNhbGxiYWNrKG51bGwsIHJlc3BvbnNlKTtcbiAgICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgbGV0IGVycm9yQ29kZTtcbiAgICAgICAgICAgIGxldCBlcnJvck1lc3NhZ2U7XG4gICAgICAgICAgICBpZiAoZXJyb3IucmVzcG9uc2UpIHtcbiAgICAgICAgICAgICAgZXJyb3JDb2RlID0gZXJyb3IucmVzcG9uc2UuZGF0YS5jb2RlO1xuICAgICAgICAgICAgICBlcnJvck1lc3NhZ2UgPSBlcnJvci5yZXNwb25zZS5kYXRhLm1lc3NhZ2U7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICBlcnJvckNvZGUgPSA1MDA7XG4gICAgICAgICAgICAgIGVycm9yTWVzc2FnZSA9ICdDYW5ub3QgYWNjZXNzIHRoZSBBUEknO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbGV0IG15RXJyb3IgPSBuZXcgTWV0ZW9yLkVycm9yKGVycm9yQ29kZSwgZXJyb3JNZXNzYWdlKTtcbiAgICAgICAgICAgIGNhbGxiYWNrKG15RXJyb3IsIG51bGwpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGxldCByZXNwb25zZSA9IE1ldGVvci53cmFwQXN5bmMoYXBpQ2FsbCkoYXBpVXJsZm9yQmFkZ2VBcHBsaWNhdGlvbik7XG4gICAgICAgIHJlc3BvbnNlID0gcmVzcG9uc2UudHJpbSgpO1xuICAgICAgICByZXNwb25zZSA9IHJlc3BvbnNlLnNwbGl0KC9cXHJcXG4vKTtcbiAgICAgICAgcmVzcG9uc2UgPSByZXNwb25zZS5qb2luKCcsJyk7XG4gICAgICAgIHJlc3BvbnNlID0gXCJbXCIgKyByZXNwb25zZSArIFwiXVwiO1xuICAgICAgICByZXNwb25zZSA9IEpTT04ucGFyc2UocmVzcG9uc2UpO1xuXG4gICAgICAgIHJlc3BvbnNlID0gcmVzcG9uc2UuZmlsdGVyKGZ1bmN0aW9uIChlbCkge1xuICAgICAgICAgICAgcmV0dXJuIChlbC5lbWFpbCA9PT0gdXNlckVtYWlsKTtcbiAgICAgICAgfSk7XG5cblxuICAgICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgICAgXG5cbiAgICAgIH0sXG5cbiAgfSk7IC8vIGVuZCBNZXRlb3IubWV0aG9kc1xuXG59IC8vZW5kIGlmIChNZXRlb3IuaXNTZXJ2ZXIpXG4iLCIvLyB0aGlzIG1vZHVsZSBjYW4gYmUgaW1wb3J0ZWQgdG8gYW55IG90aGVyIHNlcnZlciBzaWRlIG1vZHVsZVxuLy8gdG8gdXNlIGNvbmZpZyBkYXRhIHN1Y2ggYXMgKGFwaSB1cmwsIHRva2VuIGV0YykuXG4vLyBmb3IgcHJvZHVjdGlvbiBzZXJ2ZXIsIGFsbCB0aGUgc2VjcmV0IHZhbHVlcyB3aWxsIGJlIGltcG9ydGVkIGZyb20gc2V0dGluZ3MuanNvbiBmaWxlIChwcm9kdWN0aW9uIHZlcnNpb24pIGR1cmluZyBkZXBsb3ltZW50IHByb2Nlc3MuXG5pbXBvcnQge01ldGVvcn0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgKiBhcyBkYXRhIGZyb20gJy4uLy4uL3NlZWREYXRhLmpzb24nO1xuXG5leHBvcnQgY2xhc3MgQXBwQ29uZmlnIHtcbiAgICBhZG1pblBhc3N3b3JkIDogc3RyaW5nO1xuICAgIGFkbWluRW1haWwgOiBzdHJpbmc7XG4gICAgb2JmQ2VydGlmaWNhdGUgOiBzdHJpbmc7XG4gICAgb2JmS2V5IDogc3RyaW5nO1xuICAgIGNhbXB1c0FycmF5O1xuICAgIGtvYmxlbnpGYWN1bHRpZXM7XG4gICAgbGFuZGF1RmFjdWx0aWVzO1xuICAgIGxldmVscztcbiAgICBjb21wZXRlbmNpZXM7XG4gICAgdG9vbHM7XG5cbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgIHRoaXMuYWRtaW5QYXNzd29yZCA9IE1ldGVvcltcInNldHRpbmdzXCJdW1wicHJpdmF0ZVwiXVtcImFkbWluTG9naW5cIl07XG4gICAgICB0aGlzLmFkbWluRW1haWwgPSBNZXRlb3JbXCJzZXR0aW5nc1wiXVtcInByaXZhdGVcIl1bXCJhZG1pbkVtYWlsXCJdO1xuICAgICAgdGhpcy5vYmZDZXJ0aWZpY2F0ZSA9IE1ldGVvcltcInNldHRpbmdzXCJdW1wicHJpdmF0ZVwiXVtcIm9iZkNlcnRpZmljYXRlXCJdLmpvaW4oJ1xcbicpO1xuICAgICAgdGhpcy5vYmZLZXkgPSBNZXRlb3JbXCJzZXR0aW5nc1wiXVtcInByaXZhdGVcIl1bXCJvYmZLZXlcIl0uam9pbignXFxuJyk7XG4gICAgICB0aGlzLmNhbXB1c0FycmF5ID0gZGF0YS5jYW1wdXNlcztcbiAgICAgIHRoaXMua29ibGVuekZhY3VsdGllcyA9IGRhdGEua29ibGVuekZhY3VsdGllcztcbiAgICAgIHRoaXMubGFuZGF1RmFjdWx0aWVzID0gZGF0YS5sYW5kYXVGYWN1bHRpZXM7XG4gICAgICB0aGlzLmxldmVscyA9IGRhdGEubGV2ZWxzO1xuICAgICAgdGhpcy5jb21wZXRlbmNpZXMgPSBkYXRhLmNvbXBldGVuY2llcztcbiAgICAgIHRoaXMudG9vbHMgPSBkYXRhLnRvb2xzO1xuICAgIH1cblxuXG59IC8vIGVuZCBvZiBjbGFzc1xuIiwiLy8gc3RhcnR1cCBjb2RlcyBmb3Igc2VydmVyIC0gZS5nIDogYXBpIGluaXQgZm9yIHJlbW90ZSBzZXJ2aWNlc1xuXG4vLyAtLS0gYWRkaW5nIHNvbWUgc2VlZCBkYXRhIGlmIHRoZSBkYiBpcyBlbXB0eSAtIGp1c3QgZm9yIGJvb3RzdHJhcHBpbmcgLS0tXG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tIFwibWV0ZW9yL21ldGVvclwiO1xuaW1wb3J0IHsgQXBwQ29uZmlnIH0gZnJvbSBcIi9zZXJ2ZXIvc3RhcnR1cC9hcHBjb25maWdcIjtcbmltcG9ydCB7IENhbXB1c0RCLCBGYWN1bHR5REIsIEluc3RpdHV0ZURCLCBDb21wZXRlbmN5REIsIExldmVsREIsIFRvb2xEQiB9IGZyb20gXCIuLi8uLi9pbXBvcnRzL2FwaVwiO1xuXG5NZXRlb3Iuc3RhcnR1cChmdW5jdGlvbigpIHt9KTsgLy9lbmQgTWV0ZW9yLnN0YXJ0dXBcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tIENyZWF0aW5nIGFkbWluIGFjY291bnQgb24gc3RhcnR1cCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxudmFyIGJhZGdlbG9yQXBwQ29uZmlnID0gbmV3IEFwcENvbmZpZygpO1xuXG4vLyBjcmVhdGluZyBhbiBhZG1pbiBhY2NvdW50IGlmIG5vbmUgZXhpc3RzLlxuXG5pZiAoTWV0ZW9yLnVzZXJzLmZpbmQoeyB1c2VybmFtZTogXCJhZG1pblwiIH0pLmNvdW50KCkgIT0gMSkge1xuICAvL1xuICAvLyAgIC8vIGNyZWF0aW5nIGFkbWluIHVzZXIgZm9yIHRoZSBmaXJzdCB0aW1lXG4gIC8vXG4gIHRyeSB7XG4gICAgQWNjb3VudHMuY3JlYXRlVXNlcih7XG4gICAgICBlbWFpbDogYmFkZ2Vsb3JBcHBDb25maWcuYWRtaW5FbWFpbCxcbiAgICAgIHBhc3N3b3JkOiBiYWRnZWxvckFwcENvbmZpZy5hZG1pblBhc3N3b3JkLFxuICAgICAgdXNlcm5hbWU6IFwiYWRtaW5cIlxuICAgIH0pO1xuXG4gICAgLy8gbm93IGFkbWluIGFjY291bnQgaXMgY3JlYXRlZC4gc28gc2V0dGluZyB0aGlzIHVzZXIgcm9sZSBhcyBhZG1pblxuXG4gICAgbGV0IGFkbWluREIgPSBNZXRlb3IudXNlcnMuZmluZE9uZSh7IHVzZXJuYW1lOiBcImFkbWluXCIgfSk7XG5cbiAgICBNZXRlb3IudXNlcnMudXBkYXRlKGFkbWluREIuX2lkLCB7XG4gICAgICAkc2V0OiB7XG4gICAgICAgIHJvbGU6IFwiYWRtaW5cIixcbiAgICAgICAgb2JmSUQ6IFwiXCJcbiAgICAgIH1cbiAgICB9KTtcbiAgfSBjYXRjaCAoZSkge1xuICAgIC8vZW5kIHRyeVxuXG4gICAgY29uc29sZS5sb2coXCJlcnJvciA6IFwiICsgZSk7XG4gIH1cbn0gLy9lbmQgaWYgYWRtaW4gZG9lc24ndCBleGlzdFxuXG4vLyBpZiB0aGVyZSBpcyBubyBjYW1wdXMgaW4gdGhlIHNlcnZlclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tIGNyZWF0ZSBjYW1wdXNlcyBvbiBzdGFydHVwIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuaWYgKENhbXB1c0RCLmNvbGxlY3Rpb24uZmluZCh7fSkuY291bnQoKSA9PSAwKSB7XG4gIHRyeSB7XG4gICAgZm9yIChsZXQga2V5IGluIGJhZGdlbG9yQXBwQ29uZmlnLmNhbXB1c0FycmF5KSB7XG4gICAgICBDYW1wdXNEQi5jb2xsZWN0aW9uLmluc2VydCh7XG4gICAgICAgIG5hbWU6IGJhZGdlbG9yQXBwQ29uZmlnLmNhbXB1c0FycmF5W2tleV0sXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIlwiLFxuICAgICAgICBjcmVhdGVkQnk6IGJhZGdlbG9yQXBwQ29uZmlnLmFkbWluRW1haWwsXG4gICAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKVxuICAgICAgfSk7IC8vZW5kIGluc2VydFxuICAgIH0gLy8gZW5kIG9mIGZvciBsb29wXG4gIH0gY2F0Y2ggKGUpIHtcbiAgICBjb25zb2xlLmxvZyhcImVycm9yIDogXCIgKyBlKTtcbiAgfVxufVxuXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tIGNyZWF0ZSBGYWN1bHRpZXMgYW5kIGluc3RpdHV0ZXMgb24gc3RhcnR1cCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbi8vIG5vdyB3ZSBsb2FkIHRoZSBmYWN1bHRpZXMgZm9yIGNhbXB1c2VzIFtLb2JsZW56LCBMYW5kYXVdXG5sZXQga29ibGVuekNhbXB1c0RCID0gQ2FtcHVzREIuY29sbGVjdGlvbi5maW5kT25lKHsgbmFtZTogXCJrb2JsZW56XCIgfSk7XG4vLyBjb25zb2xlLmxvZyhrb2JsZW56Q2FtcHVzREJbXCJfaWRcIl0pO1xubGV0IGxhbmRhdUNhbXB1c0RCID0gQ2FtcHVzREIuY29sbGVjdGlvbi5maW5kT25lKHsgbmFtZTogXCJsYW5kYXVcIiB9KTtcbi8vIGNvbnNvbGUubG9nKGxhbmRhdUNhbXB1c0RCW1wiX2lkXCJdKTtcblxuaWYgKEZhY3VsdHlEQi5jb2xsZWN0aW9uLmZpbmQoe30pLmNvdW50KCkgPT0gMCkge1xuICB0cnkge1xuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIC8vIGZpcnN0IGVudGVyIGtvYmxlbnogZmFjdWx0aWVzIGFuZCBpbnN0aXR1dGVzXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgZm9yIChsZXQga2V5IGluIGJhZGdlbG9yQXBwQ29uZmlnLmtvYmxlbnpGYWN1bHRpZXMpIHtcbiAgICAgIEZhY3VsdHlEQi5jb2xsZWN0aW9uLmluc2VydCh7XG4gICAgICAgIG5hbWU6IGJhZGdlbG9yQXBwQ29uZmlnLmtvYmxlbnpGYWN1bHRpZXNba2V5XVtcIm5hbWVcIl0sXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIlwiLFxuICAgICAgICBjYW1wdXNJRDoga29ibGVuekNhbXB1c0RCW1wiX2lkXCJdLFxuICAgICAgICBjcmVhdGVkQnk6IGJhZGdlbG9yQXBwQ29uZmlnLmFkbWluRW1haWwsXG4gICAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKVxuICAgICAgfSk7IC8vZW5kIGluc2VydFxuICAgICAgbGV0IHRoaXNGYWN1bHR5ID0gRmFjdWx0eURCLmNvbGxlY3Rpb24uZmluZE9uZSh7XG4gICAgICAgIG5hbWU6IGJhZGdlbG9yQXBwQ29uZmlnLmtvYmxlbnpGYWN1bHRpZXNba2V5XVtcIm5hbWVcIl1cbiAgICAgIH0pO1xuICAgICAgaWYgKGJhZGdlbG9yQXBwQ29uZmlnLmtvYmxlbnpGYWN1bHRpZXNba2V5XS5pbnN0aXR1dGVzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgZm9yIChsZXQgaSBpbiBiYWRnZWxvckFwcENvbmZpZy5rb2JsZW56RmFjdWx0aWVzW2tleV0uaW5zdGl0dXRlcykge1xuICAgICAgICAgIEluc3RpdHV0ZURCLmNvbGxlY3Rpb24uaW5zZXJ0KHtcbiAgICAgICAgICAgIG5hbWU6IGJhZGdlbG9yQXBwQ29uZmlnLmtvYmxlbnpGYWN1bHRpZXNba2V5XS5pbnN0aXR1dGVzW2ldLFxuICAgICAgICAgICAgZGVzY3JpcHRpb246IFwiXCIsXG4gICAgICAgICAgICBjYW1wdXNJRDoga29ibGVuekNhbXB1c0RCW1wiX2lkXCJdLFxuICAgICAgICAgICAgZmFjdWx0eUlEOiB0aGlzRmFjdWx0eVtcIl9pZFwiXSxcbiAgICAgICAgICAgIGNyZWF0ZWRCeTogYmFkZ2Vsb3JBcHBDb25maWcuYWRtaW5FbWFpbCxcbiAgICAgICAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKVxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIC8vIFRoZW4gbGFuZGF1IGZhY3VsdGllcyBhbmQgaW5zdGl0dXRlcyA9PT09PT09PVxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIGZvciAobGV0IGtleSBpbiBiYWRnZWxvckFwcENvbmZpZy5sYW5kYXVGYWN1bHRpZXMpIHtcbiAgICAgIEZhY3VsdHlEQi5jb2xsZWN0aW9uLmluc2VydCh7XG4gICAgICAgIG5hbWU6IGJhZGdlbG9yQXBwQ29uZmlnLmxhbmRhdUZhY3VsdGllc1trZXldW1wibmFtZVwiXSxcbiAgICAgICAgZGVzY3JpcHRpb246IFwiXCIsXG4gICAgICAgIGNhbXB1c0lEOiBsYW5kYXVDYW1wdXNEQltcIl9pZFwiXSxcbiAgICAgICAgY3JlYXRlZEJ5OiBiYWRnZWxvckFwcENvbmZpZy5hZG1pbkVtYWlsLFxuICAgICAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKClcbiAgICAgIH0pOyAvL2VuZCBpbnNlcnRcbiAgICAgIGxldCB0aGlzRmFjdWx0eSA9IEZhY3VsdHlEQi5jb2xsZWN0aW9uLmZpbmRPbmUoe1xuICAgICAgICBuYW1lOiBiYWRnZWxvckFwcENvbmZpZy5sYW5kYXVGYWN1bHRpZXNba2V5XVtcIm5hbWVcIl1cbiAgICAgIH0pO1xuICAgICAgaWYgKGJhZGdlbG9yQXBwQ29uZmlnLmxhbmRhdUZhY3VsdGllc1trZXldLmluc3RpdHV0ZXMubGVuZ3RoID4gMCkge1xuICAgICAgICBmb3IgKGxldCBpIGluIGJhZGdlbG9yQXBwQ29uZmlnLmxhbmRhdUZhY3VsdGllc1trZXldLmluc3RpdHV0ZXMpIHtcbiAgICAgICAgICBJbnN0aXR1dGVEQi5jb2xsZWN0aW9uLmluc2VydCh7XG4gICAgICAgICAgICBuYW1lOiBiYWRnZWxvckFwcENvbmZpZy5sYW5kYXVGYWN1bHRpZXNba2V5XS5pbnN0aXR1dGVzW2ldLFxuICAgICAgICAgICAgZGVzY3JpcHRpb246IFwiXCIsXG4gICAgICAgICAgICBjYW1wdXNJRDogbGFuZGF1Q2FtcHVzREJbXCJfaWRcIl0sXG4gICAgICAgICAgICBmYWN1bHR5SUQ6IHRoaXNGYWN1bHR5W1wiX2lkXCJdLFxuICAgICAgICAgICAgY3JlYXRlZEJ5OiBiYWRnZWxvckFwcENvbmZpZy5hZG1pbkVtYWlsLFxuICAgICAgICAgICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH0gY2F0Y2ggKGUpIHtcbiAgICBjb25zb2xlLmxvZyhcImVycm9yIDpcIiArIGUpO1xuICB9XG59XG5cbmlmIChMZXZlbERCLmNvbGxlY3Rpb24uZmluZCh7fSkuY291bnQoKSA9PSAwKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgZm9yIChsZXQga2V5IGluIGJhZGdlbG9yQXBwQ29uZmlnLmxldmVscykge1xuICAgICAgICAgICAgTGV2ZWxEQi5jb2xsZWN0aW9uLmluc2VydCh7XG4gICAgICAgICAgICAgICAgbmFtZTogYmFkZ2Vsb3JBcHBDb25maWcubGV2ZWxzW2tleV0sXG4gICAgICAgICAgICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgICAgICAgICAgIGNyZWF0ZWRCeTogYmFkZ2Vsb3JBcHBDb25maWcuYWRtaW5FbWFpbCxcbiAgICAgICAgICAgICAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKClcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgICBjb25zb2xlLmxvZyhcImVycm9yIDpcIiArIGUpO1xuICAgIH1cbn1cblxuaWYgKENvbXBldGVuY3lEQi5jb2xsZWN0aW9uLmZpbmQoe30pLmNvdW50KCkgPT0gMCkge1xuICAgIHRyeSB7XG4gICAgICAgIGZvciAobGV0IGtleSBpbiBiYWRnZWxvckFwcENvbmZpZy5jb21wZXRlbmNpZXMpIHtcbiAgICAgICAgICAgIENvbXBldGVuY3lEQi5jb2xsZWN0aW9uLmluc2VydCh7XG4gICAgICAgICAgICAgICAgbmFtZTogYmFkZ2Vsb3JBcHBDb25maWcuY29tcGV0ZW5jaWVzW2tleV0sXG4gICAgICAgICAgICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgICAgICAgICAgIGNyZWF0ZWRCeTogYmFkZ2Vsb3JBcHBDb25maWcuYWRtaW5FbWFpbCxcbiAgICAgICAgICAgICAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKClcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgICBjb25zb2xlLmxvZyhcImVycm9yIDpcIiArIGUpO1xuICAgIH1cbn1cblxuaWYgKFRvb2xEQi5jb2xsZWN0aW9uLmZpbmQoe30pLmNvdW50KCkgPT0gMCkge1xuICAgIHRyeSB7XG4gICAgICAgIGZvciAobGV0IGtleSBpbiBiYWRnZWxvckFwcENvbmZpZy50b29scykge1xuICAgICAgICAgICAgVG9vbERCLmNvbGxlY3Rpb24uaW5zZXJ0KHtcbiAgICAgICAgICAgICAgICBuYW1lOiBiYWRnZWxvckFwcENvbmZpZy50b29sc1trZXldLFxuICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgICAgICAgICAgICBjcmVhdGVkQnk6IGJhZGdlbG9yQXBwQ29uZmlnLmFkbWluRW1haWwsXG4gICAgICAgICAgICAgICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgY29uc29sZS5sb2coXCJlcnJvciA6XCIgKyBlKTtcbiAgICB9XG59XG5cbi8vIFRPRE8gOiByZXNldCBwYXNzd29yZCBhbmQgZW1haWwgZnJvbSB0aGUgc2V0dGluZ3MgZmlsZSBvbiBlYWNoIHN0YXJ0dXAgLSBzbyB0aGF0IGFkbWluIHBhc3N3b3JkIGlzXG4vLyBhbHdheXMgdXAgdG8gZGF0ZSBhcyBwZXIgdGhlIGxhdGVzdCBzZXR0aW5ncy5qc29uIGZpbGUuXG5cbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyAtLS0tLSBFTkQgb2YgZGF0YWJhc2Ugc2VlZCBvbiBzdGFydHVwIC0tLS0tLVxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiIsIi8vIGltcG9ydCAnLi4vaW1wb3J0cy9hcGkvY29sbGVjdGlvbnMuanMnO1xuIiwiLy8gVGhpcyBmaWxlIGNvbnRhaW5zIGFsbCB0aGUgZGVjbGFyYXRpb25zIGZvciBtb25nbyBkYXRhYmFzZS9jb2xsZWN0aW9uc1xuLy8gbW9kdWxlcyBvZiB0aGlzIGZpbGUgd2lsbCBuZWVkIHRvIGJlIGltcG9ydGVkIGluIGJvdGggc2VydmVyIGFuZCBjbGllbnQgc2NyaXB0cyAtIHdoZW5ldmVyIGEgREIgYWNjZXNzIGlzIG5lZWRlZC5cbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IHsgTW9uZ29PYnNlcnZhYmxlIH0gZnJvbSAnbWV0ZW9yLXJ4anMnO1xuXG4vL2hlcmUgY2FtcHVzIGlzIHRoZSBuYW1lIG9mIG1vbmdvIGNvbGxlY3Rpb24gaW4gdGhlIGRhdGFiYXNlIGFuZCBDYW1wdXNEQiBwb2ludHMgdG8gdGhhdCBjb2xsZWN0aW9uLlxuZXhwb3J0IGNvbnN0IENhbXB1c0RCID0gbmV3IE1vbmdvT2JzZXJ2YWJsZS5Db2xsZWN0aW9uKCdjYW1wdXMnKTtcbmV4cG9ydCBjb25zdCBGYWN1bHR5REIgPSBuZXcgTW9uZ29PYnNlcnZhYmxlLkNvbGxlY3Rpb24oJ2ZhY3VsdHknKTtcbmV4cG9ydCBjb25zdCBJbnN0aXR1dGVEQiA9IG5ldyBNb25nb09ic2VydmFibGUuQ29sbGVjdGlvbignaW5zdGl0dXRlJyk7XG5leHBvcnQgY29uc3QgQ291cnNlREIgPSBuZXcgTW9uZ29PYnNlcnZhYmxlLkNvbGxlY3Rpb24oJ2NvdXJzZScpO1xuZXhwb3J0IGNvbnN0IExldmVsREIgPSBuZXcgTW9uZ29PYnNlcnZhYmxlLkNvbGxlY3Rpb24oJ2xldmVsJyk7XG5leHBvcnQgY29uc3QgQ29tcGV0ZW5jeURCID0gbmV3IE1vbmdvT2JzZXJ2YWJsZS5Db2xsZWN0aW9uKCdjb21wZXRlbmN5Jyk7XG5leHBvcnQgY29uc3QgVG9vbERCID0gbmV3IE1vbmdvT2JzZXJ2YWJsZS5Db2xsZWN0aW9uKCd0b29sJyk7XG5leHBvcnQgY29uc3QgTWV0YWRhdGFEQiA9IG5ldyBNb25nb09ic2VydmFibGUuQ29sbGVjdGlvbignbWV0YWRhdGEnKTtcblxuZXhwb3J0IGNvbnN0IFByb2ZpbGVEQiA9IG5ldyBNb25nb09ic2VydmFibGUuQ29sbGVjdGlvbigncHJvZmlsZScpO1xuXG5cblxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xuXG5cbn0gLy8gZW5kIGlmIChNZXRlb3IuaXNTZXJ2ZXIpXG4iLCJleHBvcnQgKiBmcm9tICcuL2NvbGxlY3Rpb25zJzsiXX0=
