(function () {



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['angular2-compilers'] = {};

})();
