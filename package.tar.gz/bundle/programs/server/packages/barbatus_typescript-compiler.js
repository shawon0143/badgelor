(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var check = Package.check.check;
var Match = Package.check.Match;
var _ = Package.underscore._;
var meteorInstall = Package.modules.meteorInstall;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var Logger, TypeScriptCompiler, inputFiles, TypeScript, options;

var require = meteorInstall({"node_modules":{"meteor":{"barbatus:typescript-compiler":{"logger.js":function(require){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/barbatus_typescript-compiler/logger.js                                                                  //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
const util = Npm.require('util');

class Logger_ {
  constructor() {
    this.llevel = process.env.TYPESCRIPT_LOG;
  }

  newProfiler(name) {
    let profiler = new Profiler(name);
    if (this.isProfile) profiler.start();
    return profiler;
  }

  get isDebug() {
    return this.llevel >= 2;
  }

  get isProfile() {
    return this.llevel >= 3;
  }

  get isAssert() {
    return this.llevel >= 4;
  }

  log(msg, ...args) {
    if (this.llevel >= 1) {
      console.log.apply(null, [msg].concat(args));
    }
  }

  debug(msg, ...args) {
    if (this.isDebug) {
      this.log.apply(this, msg, args);
    }
  }

  assert(msg, ...args) {
    if (this.isAssert) {
      this.log.apply(this, msg, args);
    }
  }

}

;
Logger = new Logger_();

class Profiler {
  constructor(name) {
    this.name = name;
  }

  start() {
    console.log('%s started', this.name);
    console.time(util.format('%s time', this.name));
    this._started = true;
  }

  end() {
    if (this._started) {
      console.timeEnd(util.format('%s time', this.name));
    }
  }

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"file-utils.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/barbatus_typescript-compiler/file-utils.js                                                              //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  isBare: () => isBare,
  isMainConfig: () => isMainConfig,
  isConfig: () => isConfig,
  isServerConfig: () => isServerConfig,
  isDeclaration: () => isDeclaration,
  isWeb: () => isWeb,
  getExtendedPath: () => getExtendedPath,
  getES6ModuleName: () => getES6ModuleName,
  WarnMixin: () => WarnMixin,
  extendFiles: () => extendFiles
});

function isBare(inputFile) {
  const fileOptions = inputFile.getFileOptions();
  return fileOptions && fileOptions.bare;
}

function isMainConfig(inputFile) {
  if (!isWeb(inputFile)) return false;
  const filePath = inputFile.getPathInPackage();
  return (/^tsconfig\.json$/.test(filePath)
  );
}

function isConfig(inputFile) {
  const filePath = inputFile.getPathInPackage();
  return (/tsconfig\.json$/.test(filePath)
  );
}

function isServerConfig(inputFile) {
  if (isWeb(inputFile)) return false;
  const filePath = inputFile.getPathInPackage();
  return (/^server\/tsconfig\.json$/.test(filePath)
  );
}

function isDeclaration(inputFile) {
  return TypeScript.isDeclarationFile(inputFile.getBasename());
}

function isWeb(inputFile) {
  const arch = inputFile.getArch();
  return (/^web/.test(arch)
  );
}

function getExtendedPath(inputFile) {
  let packageName = inputFile.getPackageName();
  packageName = packageName ? packageName.replace(':', '_') + '/' : '';
  const inputFilePath = inputFile.getPathInPackage();
  return packageName + inputFilePath;
}

function getES6ModuleName(inputFile) {
  const extended = getExtendedPath(inputFile);
  return TypeScript.removeTsExt(extended);
}

const WarnMixin = {
  warn: error => {
    console.log(`${error.sourcePath} (${error.line}, ${error.column}): ${error.message}`);
  }
};

function extendFiles(inputFiles, fileMixin) {
  inputFiles.forEach(inputFile => _.defaults(inputFile, fileMixin));
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"typescript-compiler.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/barbatus_typescript-compiler/typescript-compiler.js                                                     //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
const module1 = module;
let getExtendedPath, isDeclaration, isConfig, isMainConfig, isServerConfig, isBare, getES6ModuleName, WarnMixin, extendFiles, isWeb;
module1.watch(require("./file-utils"), {
  getExtendedPath(v) {
    getExtendedPath = v;
  },

  isDeclaration(v) {
    isDeclaration = v;
  },

  isConfig(v) {
    isConfig = v;
  },

  isMainConfig(v) {
    isMainConfig = v;
  },

  isServerConfig(v) {
    isServerConfig = v;
  },

  isBare(v) {
    isBare = v;
  },

  getES6ModuleName(v) {
    getES6ModuleName = v;
  },

  WarnMixin(v) {
    WarnMixin = v;
  },

  extendFiles(v) {
    extendFiles = v;
  },

  isWeb(v) {
    isWeb = v;
  }

}, 0);
let getShallowHash;
module1.watch(require("./utils"), {
  getShallowHash(v) {
    getShallowHash = v;
  }

}, 1);

const async = Npm.require('async');

const path = Npm.require('path');

const fs = Npm.require('fs');

const Future = Npm.require('fibers/future');

const {
  TSBuild,
  validateTsConfig,
  getExcludeRegExp
} = Npm.require('meteor-typescript');

const {
  createHash
} = Npm.require('crypto');

// Default exclude paths.
const defExclude = new RegExp(getExcludeRegExp(['node_modules/**'])); // What to exclude when compiling for the server.

const exlWebRegExp = new RegExp(getExcludeRegExp(['typings/main/**', 'typings/main.d.ts'])); // What to exclude when compiling for the client.

const exlMainRegExp = new RegExp(getExcludeRegExp(['typings/browser/**', 'typings/browser.d.ts']));
const COMPILER_REGEXP = /(\.d.ts|\.ts|\.tsx|\.tsconfig)$/;
TypeScriptCompiler = class TypeScriptCompiler {
  constructor(extraOptions, maxParallelism) {
    TypeScript.validateExtraOptions(extraOptions);
    this.extraOptions = extraOptions;
    this.maxParallelism = maxParallelism || 10;
    this.serverOptions = null;
    this.tsconfig = TypeScript.getDefaultOptions();
    this.cfgHash = null;
    this.diagHash = new Set();
    this.archSet = new Set();
  }

  getFilesToProcess(inputFiles) {
    const pexclude = Logger.newProfiler('exclude');
    inputFiles = this._filterByDefault(inputFiles);

    this._processConfig(inputFiles);

    inputFiles = this._filterByConfig(inputFiles);

    if (inputFiles.length) {
      const arch = inputFiles[0].getArch();
      inputFiles = this._filterByArch(inputFiles, arch);
    }

    pexclude.end();
    return inputFiles;
  }

  getBuildOptions(inputFiles) {
    this._processConfig(inputFiles);

    const inputFile = inputFiles[0];
    let {
      compilerOptions
    } = this.tsconfig; // Make a copy.

    compilerOptions = Object.assign({}, compilerOptions);

    if (!isWeb(inputFile) && this.serverOptions) {
      Object.assign(compilerOptions, this.serverOptions);
    } // Apply extra options.


    if (this.extraOptions) {
      Object.assign(compilerOptions, this.extraOptions);
    }

    const arch = inputFile.getArch();
    const {
      typings,
      useCache
    } = this.tsconfig;
    return {
      arch,
      compilerOptions,
      typings,
      useCache
    };
  }

  processFilesForTarget(inputFiles, getDepsContent) {
    extendFiles(inputFiles, WarnMixin);
    const options = this.getBuildOptions(inputFiles);
    Logger.log('compiler options: %j', options.compilerOptions);
    inputFiles = this.getFilesToProcess(inputFiles);
    if (!inputFiles.length) return;
    const pcompile = Logger.newProfiler('compilation');
    const filePaths = inputFiles.map(file => getExtendedPath(file));
    Logger.log('compile files: %s', filePaths);
    const pbuild = Logger.newProfiler('tsBuild');

    const defaultGet = this._getContentGetter(inputFiles);

    const getContent = filePath => getDepsContent && getDepsContent(filePath) || defaultGet(filePath);

    const tsBuild = new TSBuild(filePaths, getContent, options);
    pbuild.end();
    const pfiles = Logger.newProfiler('tsEmitFiles');
    const future = new Future(); // Don't emit typings.

    const compileFiles = inputFiles.filter(file => !isDeclaration(file));
    const {
      compilerOptions
    } = options;
    async.eachLimit(compileFiles, this.maxParallelism, (file, done) => {
      const co = compilerOptions;
      const filePath = getExtendedPath(file); // Module set none explicitly, don't use ES6 modules.

      const moduleName = co.module === 'none' ? null : getES6ModuleName(file);
      const pemit = Logger.newProfiler('tsEmit');
      const result = tsBuild.emit(filePath, moduleName);
      pemit.end();

      const throwSyntax = this._processDiagnostics(file, result.diagnostics, co);

      if (!throwSyntax) {
        const module = compilerOptions.module;

        this._addJavaScript(file, result, module === 'none');
      }

      done();
    }, future.resolver());
    pfiles.end();
    future.wait();
    pcompile.end();
  }

  _getContentGetter(inputFiles) {
    const filesMap = new Map();
    inputFiles.forEach((inputFile, index) => {
      filesMap.set(getExtendedPath(inputFile), index);
    });
    return filePath => {
      let index = filesMap.get(filePath);

      if (index === undefined) {
        const filePathNoRootSlash = filePath.replace(/^\//, '');
        index = filesMap.get(filePathNoRootSlash);
      }

      return index !== undefined ? inputFiles[index].getContentsAsString() : null;
    };
  }

  _addJavaScript(inputFile, tsResult, forceBare) {
    const source = inputFile.getContentsAsString();
    const inputPath = inputFile.getPathInPackage();
    const outputPath = TypeScript.removeTsExt(inputPath) + '.js';
    const toBeAdded = {
      sourcePath: inputPath,
      path: outputPath,
      data: tsResult.code,
      hash: tsResult.hash,
      sourceMap: tsResult.sourceMap,
      bare: forceBare || isBare(inputFile)
    };
    inputFile.addJavaScript(toBeAdded);
  }

  _processDiagnostics(inputFile, diagnostics, tsOptions) {
    // Remove duplicated warnings for shared files
    // by saving hashes of already shown warnings.
    const reduce = (diagnostic, cb) => {
      let dob = {
        message: diagnostic.message,
        sourcePath: getExtendedPath(inputFile),
        line: diagnostic.line,
        column: diagnostic.column
      };
      const arch = inputFile.getArch(); // TODO: find out how to get list of architectures.

      this.archSet.add(arch);
      let shown = false;

      for (const key of this.archSet.keys()) {
        if (key !== arch) {
          dob.arch = key;
          const hash = getShallowHash(dob);

          if (this.diagHash.has(hash)) {
            shown = true;
            break;
          }
        }
      }

      if (!shown) {
        dob.arch = arch;
        const hash = getShallowHash(dob);
        this.diagHash.add(hash);
        cb(dob);
      }
    }; // Always throw syntax errors.


    const throwSyntax = !!diagnostics.syntacticErrors.length;
    diagnostics.syntacticErrors.forEach(diagnostic => {
      reduce(diagnostic, dob => inputFile.error(dob));
    });
    const packageName = inputFile.getPackageName();
    if (packageName) return throwSyntax; // And log out other errors except package files.

    if (tsOptions && tsOptions.diagnostics) {
      diagnostics.semanticErrors.forEach(diagnostic => {
        reduce(diagnostic, dob => inputFile.warn(dob));
      });
    }

    return throwSyntax;
  }

  _getFileModuleName(inputFile, options) {
    if (options.module === 'none') return null;
    return getES6ModuleName(inputFile);
  }

  _processConfig(inputFiles) {
    for (const inputFile of inputFiles) {
      // Parse root config.
      if (isMainConfig(inputFile)) {
        const source = inputFile.getContentsAsString();
        const hash = inputFile.getSourceHash(); // If hashes differ, create new tsconfig. 

        if (hash !== this.cfgHash) {
          this.tsconfig = this._parseConfig(source);
          this.cfgHash = hash;
        }
      } // Parse server config.
      // Take only target and lib values.


      if (isServerConfig(inputFile)) {
        const source = inputFile.getContentsAsString();

        const {
          compilerOptions
        } = this._parseConfig(source);

        if (compilerOptions) {
          const {
            target,
            lib
          } = compilerOptions;
          this.serverOptions = {
            target,
            lib
          };
        }
      }
    }
  }

  _parseConfig(cfgContent) {
    let tsconfig = null;

    try {
      tsconfig = JSON.parse(cfgContent);
      validateTsConfig(tsconfig);
    } catch (err) {
      throw new Error(`Format of the tsconfig is invalid: ${err}`);
    }

    const exclude = tsconfig.exclude || [];

    try {
      const regExp = getExcludeRegExp(exclude);
      tsconfig.exclude = regExp && new RegExp(regExp);
    } catch (err) {
      throw new Error(`Format of an exclude path is invalid: ${err}`);
    }

    return tsconfig;
  }

  _filterByDefault(inputFiles) {
    inputFiles = inputFiles.filter(inputFile => {
      const path = inputFile.getPathInPackage();
      return COMPILER_REGEXP.test(path) && !defExclude.test('/' + path);
    });
    return inputFiles;
  }

  _filterByConfig(inputFiles) {
    let resultFiles = inputFiles;

    if (this.tsconfig.exclude) {
      resultFiles = resultFiles.filter(inputFile => {
        const path = inputFile.getPathInPackage(); // There seems to an issue with getRegularExpressionForWildcard:
        // result regexp always starts with /.

        return !this.tsconfig.exclude.test('/' + path);
      });
    }

    return resultFiles;
  }

  _filterByArch(inputFiles, arch) {
    check(arch, String); /**
                          * Include only typings that current arch needs,
                          * typings/main is for the server only and
                          * typings/browser - for the client.
                          */
    const filterRegExp = /^web/.test(arch) ? exlWebRegExp : exlMainRegExp;
    inputFiles = inputFiles.filter(inputFile => {
      const path = inputFile.getPathInPackage();
      return !filterRegExp.test('/' + path);
    });
    return inputFiles;
  }

};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"typescript.js":function(require){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/barbatus_typescript-compiler/typescript.js                                                              //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
const meteorTS = Npm.require('meteor-typescript');

TypeScript = {
  validateOptions(options) {
    if (!options) return;
    meteorTS.validateAndConvertOptions(options);
  },

  // Extra options are the same compiler options
  // but passed in the compiler constructor.
  validateExtraOptions(options) {
    if (!options) return;
    meteorTS.validateAndConvertOptions({
      compilerOptions: options
    });
  },

  getDefaultOptions: meteorTS.getDefaultOptions,

  compile(source, options) {
    options = options || meteorTS.getDefaultOptions();
    return meteorTS.compile(source, options);
  },

  setCacheDir(cacheDir) {
    meteorTS.setCacheDir(cacheDir);
  },

  isDeclarationFile(filePath) {
    return (/^.*\.d\.ts$/.test(filePath)
    );
  },

  removeTsExt(path) {
    return path && path.replace(/(\.tsx|\.ts)$/g, '');
  }

};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"utils.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/barbatus_typescript-compiler/utils.js                                                                   //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  getShallowHash: () => getShallowHash
});

const {
  createHash
} = Npm.require('crypto');

function getShallowHash(ob) {
  const hash = createHash('sha1');
  const keys = Object.keys(ob);
  keys.sort();
  keys.forEach(key => {
    hash.update(key).update('' + ob[key]);
  });
  return hash.digest('hex');
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./node_modules/meteor/barbatus:typescript-compiler/logger.js");
require("./node_modules/meteor/barbatus:typescript-compiler/file-utils.js");
require("./node_modules/meteor/barbatus:typescript-compiler/typescript-compiler.js");
require("./node_modules/meteor/barbatus:typescript-compiler/typescript.js");
require("./node_modules/meteor/barbatus:typescript-compiler/utils.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['barbatus:typescript-compiler'] = {}, {
  TypeScript: TypeScript,
  TypeScriptCompiler: TypeScriptCompiler
});

})();

//# sourceURL=meteor://💻app/packages/barbatus_typescript-compiler.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvYmFyYmF0dXM6dHlwZXNjcmlwdC1jb21waWxlci9sb2dnZXIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL2JhcmJhdHVzOnR5cGVzY3JpcHQtY29tcGlsZXIvZmlsZS11dGlscy5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvYmFyYmF0dXM6dHlwZXNjcmlwdC1jb21waWxlci90eXBlc2NyaXB0LWNvbXBpbGVyLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9iYXJiYXR1czp0eXBlc2NyaXB0LWNvbXBpbGVyL3R5cGVzY3JpcHQuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL2JhcmJhdHVzOnR5cGVzY3JpcHQtY29tcGlsZXIvdXRpbHMuanMiXSwibmFtZXMiOlsidXRpbCIsIk5wbSIsInJlcXVpcmUiLCJMb2dnZXJfIiwiY29uc3RydWN0b3IiLCJsbGV2ZWwiLCJwcm9jZXNzIiwiZW52IiwiVFlQRVNDUklQVF9MT0ciLCJuZXdQcm9maWxlciIsIm5hbWUiLCJwcm9maWxlciIsIlByb2ZpbGVyIiwiaXNQcm9maWxlIiwic3RhcnQiLCJpc0RlYnVnIiwiaXNBc3NlcnQiLCJsb2ciLCJtc2ciLCJhcmdzIiwiY29uc29sZSIsImFwcGx5IiwiY29uY2F0IiwiZGVidWciLCJhc3NlcnQiLCJMb2dnZXIiLCJ0aW1lIiwiZm9ybWF0IiwiX3N0YXJ0ZWQiLCJlbmQiLCJ0aW1lRW5kIiwibW9kdWxlIiwiZXhwb3J0IiwiaXNCYXJlIiwiaXNNYWluQ29uZmlnIiwiaXNDb25maWciLCJpc1NlcnZlckNvbmZpZyIsImlzRGVjbGFyYXRpb24iLCJpc1dlYiIsImdldEV4dGVuZGVkUGF0aCIsImdldEVTNk1vZHVsZU5hbWUiLCJXYXJuTWl4aW4iLCJleHRlbmRGaWxlcyIsImlucHV0RmlsZSIsImZpbGVPcHRpb25zIiwiZ2V0RmlsZU9wdGlvbnMiLCJiYXJlIiwiZmlsZVBhdGgiLCJnZXRQYXRoSW5QYWNrYWdlIiwidGVzdCIsIlR5cGVTY3JpcHQiLCJpc0RlY2xhcmF0aW9uRmlsZSIsImdldEJhc2VuYW1lIiwiYXJjaCIsImdldEFyY2giLCJwYWNrYWdlTmFtZSIsImdldFBhY2thZ2VOYW1lIiwicmVwbGFjZSIsImlucHV0RmlsZVBhdGgiLCJleHRlbmRlZCIsInJlbW92ZVRzRXh0Iiwid2FybiIsImVycm9yIiwic291cmNlUGF0aCIsImxpbmUiLCJjb2x1bW4iLCJtZXNzYWdlIiwiaW5wdXRGaWxlcyIsImZpbGVNaXhpbiIsImZvckVhY2giLCJfIiwiZGVmYXVsdHMiLCJtb2R1bGUxIiwid2F0Y2giLCJ2IiwiZ2V0U2hhbGxvd0hhc2giLCJhc3luYyIsInBhdGgiLCJmcyIsIkZ1dHVyZSIsIlRTQnVpbGQiLCJ2YWxpZGF0ZVRzQ29uZmlnIiwiZ2V0RXhjbHVkZVJlZ0V4cCIsImNyZWF0ZUhhc2giLCJkZWZFeGNsdWRlIiwiUmVnRXhwIiwiZXhsV2ViUmVnRXhwIiwiZXhsTWFpblJlZ0V4cCIsIkNPTVBJTEVSX1JFR0VYUCIsIlR5cGVTY3JpcHRDb21waWxlciIsImV4dHJhT3B0aW9ucyIsIm1heFBhcmFsbGVsaXNtIiwidmFsaWRhdGVFeHRyYU9wdGlvbnMiLCJzZXJ2ZXJPcHRpb25zIiwidHNjb25maWciLCJnZXREZWZhdWx0T3B0aW9ucyIsImNmZ0hhc2giLCJkaWFnSGFzaCIsIlNldCIsImFyY2hTZXQiLCJnZXRGaWxlc1RvUHJvY2VzcyIsInBleGNsdWRlIiwiX2ZpbHRlckJ5RGVmYXVsdCIsIl9wcm9jZXNzQ29uZmlnIiwiX2ZpbHRlckJ5Q29uZmlnIiwibGVuZ3RoIiwiX2ZpbHRlckJ5QXJjaCIsImdldEJ1aWxkT3B0aW9ucyIsImNvbXBpbGVyT3B0aW9ucyIsIk9iamVjdCIsImFzc2lnbiIsInR5cGluZ3MiLCJ1c2VDYWNoZSIsInByb2Nlc3NGaWxlc0ZvclRhcmdldCIsImdldERlcHNDb250ZW50Iiwib3B0aW9ucyIsInBjb21waWxlIiwiZmlsZVBhdGhzIiwibWFwIiwiZmlsZSIsInBidWlsZCIsImRlZmF1bHRHZXQiLCJfZ2V0Q29udGVudEdldHRlciIsImdldENvbnRlbnQiLCJ0c0J1aWxkIiwicGZpbGVzIiwiZnV0dXJlIiwiY29tcGlsZUZpbGVzIiwiZmlsdGVyIiwiZWFjaExpbWl0IiwiZG9uZSIsImNvIiwibW9kdWxlTmFtZSIsInBlbWl0IiwicmVzdWx0IiwiZW1pdCIsInRocm93U3ludGF4IiwiX3Byb2Nlc3NEaWFnbm9zdGljcyIsImRpYWdub3N0aWNzIiwiX2FkZEphdmFTY3JpcHQiLCJyZXNvbHZlciIsIndhaXQiLCJmaWxlc01hcCIsIk1hcCIsImluZGV4Iiwic2V0IiwiZ2V0IiwidW5kZWZpbmVkIiwiZmlsZVBhdGhOb1Jvb3RTbGFzaCIsImdldENvbnRlbnRzQXNTdHJpbmciLCJ0c1Jlc3VsdCIsImZvcmNlQmFyZSIsInNvdXJjZSIsImlucHV0UGF0aCIsIm91dHB1dFBhdGgiLCJ0b0JlQWRkZWQiLCJkYXRhIiwiY29kZSIsImhhc2giLCJzb3VyY2VNYXAiLCJhZGRKYXZhU2NyaXB0IiwidHNPcHRpb25zIiwicmVkdWNlIiwiZGlhZ25vc3RpYyIsImNiIiwiZG9iIiwiYWRkIiwic2hvd24iLCJrZXkiLCJrZXlzIiwiaGFzIiwic3ludGFjdGljRXJyb3JzIiwic2VtYW50aWNFcnJvcnMiLCJfZ2V0RmlsZU1vZHVsZU5hbWUiLCJnZXRTb3VyY2VIYXNoIiwiX3BhcnNlQ29uZmlnIiwidGFyZ2V0IiwibGliIiwiY2ZnQ29udGVudCIsIkpTT04iLCJwYXJzZSIsImVyciIsIkVycm9yIiwiZXhjbHVkZSIsInJlZ0V4cCIsInJlc3VsdEZpbGVzIiwiY2hlY2siLCJTdHJpbmciLCJmaWx0ZXJSZWdFeHAiLCJtZXRlb3JUUyIsInZhbGlkYXRlT3B0aW9ucyIsInZhbGlkYXRlQW5kQ29udmVydE9wdGlvbnMiLCJjb21waWxlIiwic2V0Q2FjaGVEaXIiLCJjYWNoZURpciIsIm9iIiwic29ydCIsInVwZGF0ZSIsImRpZ2VzdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLE1BQU1BLE9BQU9DLElBQUlDLE9BQUosQ0FBWSxNQUFaLENBQWI7O0FBRUEsTUFBTUMsT0FBTixDQUFjO0FBQ1pDLGdCQUFjO0FBQ1osU0FBS0MsTUFBTCxHQUFjQyxRQUFRQyxHQUFSLENBQVlDLGNBQTFCO0FBQ0Q7O0FBRURDLGNBQVlDLElBQVosRUFBa0I7QUFDaEIsUUFBSUMsV0FBVyxJQUFJQyxRQUFKLENBQWFGLElBQWIsQ0FBZjtBQUNBLFFBQUksS0FBS0csU0FBVCxFQUFvQkYsU0FBU0csS0FBVDtBQUNwQixXQUFPSCxRQUFQO0FBQ0Q7O0FBRUQsTUFBSUksT0FBSixHQUFjO0FBQ1osV0FBTyxLQUFLVixNQUFMLElBQWUsQ0FBdEI7QUFDRDs7QUFFRCxNQUFJUSxTQUFKLEdBQWdCO0FBQ2QsV0FBTyxLQUFLUixNQUFMLElBQWUsQ0FBdEI7QUFDRDs7QUFFRCxNQUFJVyxRQUFKLEdBQWU7QUFDYixXQUFPLEtBQUtYLE1BQUwsSUFBZSxDQUF0QjtBQUNEOztBQUVEWSxNQUFJQyxHQUFKLEVBQVMsR0FBR0MsSUFBWixFQUFrQjtBQUNoQixRQUFJLEtBQUtkLE1BQUwsSUFBZSxDQUFuQixFQUFzQjtBQUNwQmUsY0FBUUgsR0FBUixDQUFZSSxLQUFaLENBQWtCLElBQWxCLEVBQXdCLENBQUNILEdBQUQsRUFBTUksTUFBTixDQUFhSCxJQUFiLENBQXhCO0FBQ0Q7QUFDRjs7QUFFREksUUFBTUwsR0FBTixFQUFXLEdBQUdDLElBQWQsRUFBb0I7QUFDbEIsUUFBSSxLQUFLSixPQUFULEVBQWtCO0FBQ2hCLFdBQUtFLEdBQUwsQ0FBU0ksS0FBVCxDQUFlLElBQWYsRUFBcUJILEdBQXJCLEVBQTBCQyxJQUExQjtBQUNEO0FBQ0Y7O0FBRURLLFNBQU9OLEdBQVAsRUFBWSxHQUFHQyxJQUFmLEVBQXFCO0FBQ25CLFFBQUksS0FBS0gsUUFBVCxFQUFtQjtBQUNqQixXQUFLQyxHQUFMLENBQVNJLEtBQVQsQ0FBZSxJQUFmLEVBQXFCSCxHQUFyQixFQUEwQkMsSUFBMUI7QUFDRDtBQUNGOztBQXZDVzs7QUF3Q2I7QUFFRE0sU0FBUyxJQUFJdEIsT0FBSixFQUFUOztBQUVBLE1BQU1TLFFBQU4sQ0FBZTtBQUNiUixjQUFZTSxJQUFaLEVBQWtCO0FBQ2hCLFNBQUtBLElBQUwsR0FBWUEsSUFBWjtBQUNEOztBQUVESSxVQUFRO0FBQ05NLFlBQVFILEdBQVIsQ0FBWSxZQUFaLEVBQTBCLEtBQUtQLElBQS9CO0FBQ0FVLFlBQVFNLElBQVIsQ0FBYTFCLEtBQUsyQixNQUFMLENBQVksU0FBWixFQUF1QixLQUFLakIsSUFBNUIsQ0FBYjtBQUNBLFNBQUtrQixRQUFMLEdBQWdCLElBQWhCO0FBQ0Q7O0FBRURDLFFBQU07QUFDSixRQUFJLEtBQUtELFFBQVQsRUFBbUI7QUFDakJSLGNBQVFVLE9BQVIsQ0FBZ0I5QixLQUFLMkIsTUFBTCxDQUFZLFNBQVosRUFBdUIsS0FBS2pCLElBQTVCLENBQWhCO0FBQ0Q7QUFDRjs7QUFmWSxDOzs7Ozs7Ozs7OztBQzlDZnFCLE9BQU9DLE1BQVAsQ0FBYztBQUFDQyxVQUFPLE1BQUlBLE1BQVo7QUFBbUJDLGdCQUFhLE1BQUlBLFlBQXBDO0FBQWlEQyxZQUFTLE1BQUlBLFFBQTlEO0FBQXVFQyxrQkFBZSxNQUFJQSxjQUExRjtBQUF5R0MsaUJBQWMsTUFBSUEsYUFBM0g7QUFBeUlDLFNBQU0sTUFBSUEsS0FBbko7QUFBeUpDLG1CQUFnQixNQUFJQSxlQUE3SztBQUE2TEMsb0JBQWlCLE1BQUlBLGdCQUFsTjtBQUFtT0MsYUFBVSxNQUFJQSxTQUFqUDtBQUEyUEMsZUFBWSxNQUFJQTtBQUEzUSxDQUFkOztBQUNPLFNBQVNULE1BQVQsQ0FBZ0JVLFNBQWhCLEVBQTJCO0FBQ2hDLFFBQU1DLGNBQWNELFVBQVVFLGNBQVYsRUFBcEI7QUFDQSxTQUFPRCxlQUFlQSxZQUFZRSxJQUFsQztBQUNEOztBQUdNLFNBQVNaLFlBQVQsQ0FBc0JTLFNBQXRCLEVBQWlDO0FBQ3RDLE1BQUksQ0FBRUwsTUFBTUssU0FBTixDQUFOLEVBQXdCLE9BQU8sS0FBUDtBQUV4QixRQUFNSSxXQUFXSixVQUFVSyxnQkFBVixFQUFqQjtBQUNBLFNBQU8sb0JBQW1CQyxJQUFuQixDQUF3QkYsUUFBeEI7QUFBUDtBQUNEOztBQUVNLFNBQVNaLFFBQVQsQ0FBa0JRLFNBQWxCLEVBQTZCO0FBQ2xDLFFBQU1JLFdBQVdKLFVBQVVLLGdCQUFWLEVBQWpCO0FBQ0EsU0FBTyxtQkFBa0JDLElBQWxCLENBQXVCRixRQUF2QjtBQUFQO0FBQ0Q7O0FBR00sU0FBU1gsY0FBVCxDQUF3Qk8sU0FBeEIsRUFBbUM7QUFDeEMsTUFBSUwsTUFBTUssU0FBTixDQUFKLEVBQXNCLE9BQU8sS0FBUDtBQUV0QixRQUFNSSxXQUFXSixVQUFVSyxnQkFBVixFQUFqQjtBQUNBLFNBQU8sNEJBQTJCQyxJQUEzQixDQUFnQ0YsUUFBaEM7QUFBUDtBQUNEOztBQUdNLFNBQVNWLGFBQVQsQ0FBdUJNLFNBQXZCLEVBQWtDO0FBQ3ZDLFNBQU9PLFdBQVdDLGlCQUFYLENBQTZCUixVQUFVUyxXQUFWLEVBQTdCLENBQVA7QUFDRDs7QUFFTSxTQUFTZCxLQUFULENBQWVLLFNBQWYsRUFBMEI7QUFDL0IsUUFBTVUsT0FBT1YsVUFBVVcsT0FBVixFQUFiO0FBQ0EsU0FBTyxRQUFPTCxJQUFQLENBQVlJLElBQVo7QUFBUDtBQUNEOztBQUdNLFNBQVNkLGVBQVQsQ0FBeUJJLFNBQXpCLEVBQW9DO0FBQ3pDLE1BQUlZLGNBQWNaLFVBQVVhLGNBQVYsRUFBbEI7QUFDQUQsZ0JBQWNBLGNBQ1hBLFlBQVlFLE9BQVosQ0FBb0IsR0FBcEIsRUFBeUIsR0FBekIsSUFBZ0MsR0FEckIsR0FDNEIsRUFEMUM7QUFFQSxRQUFNQyxnQkFBZ0JmLFVBQVVLLGdCQUFWLEVBQXRCO0FBQ0EsU0FBT08sY0FBY0csYUFBckI7QUFDRDs7QUFFTSxTQUFTbEIsZ0JBQVQsQ0FBMEJHLFNBQTFCLEVBQXFDO0FBQzFDLFFBQU1nQixXQUFXcEIsZ0JBQWdCSSxTQUFoQixDQUFqQjtBQUNBLFNBQU9PLFdBQVdVLFdBQVgsQ0FBdUJELFFBQXZCLENBQVA7QUFDRDs7QUFFTSxNQUFNbEIsWUFBWTtBQUN2Qm9CLFFBQU9DLEtBQUQsSUFBVztBQUNmMUMsWUFBUUgsR0FBUixDQUFhLEdBQUU2QyxNQUFNQyxVQUFXLEtBQUlELE1BQU1FLElBQUssS0FBSUYsTUFBTUcsTUFBTyxNQUFLSCxNQUFNSSxPQUFRLEVBQW5GO0FBQ0Q7QUFIc0IsQ0FBbEI7O0FBTUEsU0FBU3hCLFdBQVQsQ0FBcUJ5QixVQUFyQixFQUFpQ0MsU0FBakMsRUFBNEM7QUFDakRELGFBQVdFLE9BQVgsQ0FBbUIxQixhQUFhMkIsRUFBRUMsUUFBRixDQUFXNUIsU0FBWCxFQUFzQnlCLFNBQXRCLENBQWhDO0FBQ0QsQzs7Ozs7Ozs7Ozs7QUMzREQsTUFBTUksVUFBUXpDLE1BQWQ7QUFBcUIsSUFBSVEsZUFBSixFQUFvQkYsYUFBcEIsRUFBa0NGLFFBQWxDLEVBQTJDRCxZQUEzQyxFQUF3REUsY0FBeEQsRUFBdUVILE1BQXZFLEVBQThFTyxnQkFBOUUsRUFBK0ZDLFNBQS9GLEVBQXlHQyxXQUF6RyxFQUFxSEosS0FBckg7QUFBMkhrQyxRQUFRQyxLQUFSLENBQWN2RSxRQUFRLGNBQVIsQ0FBZCxFQUFzQztBQUFDcUMsa0JBQWdCbUMsQ0FBaEIsRUFBa0I7QUFBQ25DLHNCQUFnQm1DLENBQWhCO0FBQWtCLEdBQXRDOztBQUF1Q3JDLGdCQUFjcUMsQ0FBZCxFQUFnQjtBQUFDckMsb0JBQWNxQyxDQUFkO0FBQWdCLEdBQXhFOztBQUF5RXZDLFdBQVN1QyxDQUFULEVBQVc7QUFBQ3ZDLGVBQVN1QyxDQUFUO0FBQVcsR0FBaEc7O0FBQWlHeEMsZUFBYXdDLENBQWIsRUFBZTtBQUFDeEMsbUJBQWF3QyxDQUFiO0FBQWUsR0FBaEk7O0FBQWlJdEMsaUJBQWVzQyxDQUFmLEVBQWlCO0FBQUN0QyxxQkFBZXNDLENBQWY7QUFBaUIsR0FBcEs7O0FBQXFLekMsU0FBT3lDLENBQVAsRUFBUztBQUFDekMsYUFBT3lDLENBQVA7QUFBUyxHQUF4TDs7QUFBeUxsQyxtQkFBaUJrQyxDQUFqQixFQUFtQjtBQUFDbEMsdUJBQWlCa0MsQ0FBakI7QUFBbUIsR0FBaE87O0FBQWlPakMsWUFBVWlDLENBQVYsRUFBWTtBQUFDakMsZ0JBQVVpQyxDQUFWO0FBQVksR0FBMVA7O0FBQTJQaEMsY0FBWWdDLENBQVosRUFBYztBQUFDaEMsa0JBQVlnQyxDQUFaO0FBQWMsR0FBeFI7O0FBQXlScEMsUUFBTW9DLENBQU4sRUFBUTtBQUFDcEMsWUFBTW9DLENBQU47QUFBUTs7QUFBMVMsQ0FBdEMsRUFBa1YsQ0FBbFY7QUFBcVYsSUFBSUMsY0FBSjtBQUFtQkgsUUFBUUMsS0FBUixDQUFjdkUsUUFBUSxTQUFSLENBQWQsRUFBaUM7QUFBQ3lFLGlCQUFlRCxDQUFmLEVBQWlCO0FBQUNDLHFCQUFlRCxDQUFmO0FBQWlCOztBQUFwQyxDQUFqQyxFQUF1RSxDQUF2RTs7QUFBeGYsTUFBTUUsUUFBUTNFLElBQUlDLE9BQUosQ0FBWSxPQUFaLENBQWQ7O0FBQ0EsTUFBTTJFLE9BQU81RSxJQUFJQyxPQUFKLENBQVksTUFBWixDQUFiOztBQUNBLE1BQU00RSxLQUFLN0UsSUFBSUMsT0FBSixDQUFZLElBQVosQ0FBWDs7QUFDQSxNQUFNNkUsU0FBUzlFLElBQUlDLE9BQUosQ0FBWSxlQUFaLENBQWY7O0FBRUEsTUFBTTtBQUNKOEUsU0FESTtBQUVKQyxrQkFGSTtBQUdKQztBQUhJLElBSUZqRixJQUFJQyxPQUFKLENBQVksbUJBQVosQ0FKSjs7QUFNQSxNQUFNO0FBQUNpRjtBQUFELElBQWVsRixJQUFJQyxPQUFKLENBQVksUUFBWixDQUFyQjs7QUFtQkE7QUFDQSxNQUFNa0YsYUFBYSxJQUFJQyxNQUFKLENBQ2pCSCxpQkFBaUIsQ0FBQyxpQkFBRCxDQUFqQixDQURpQixDQUFuQixDLENBR0E7O0FBQ0EsTUFBTUksZUFBZSxJQUFJRCxNQUFKLENBQ25CSCxpQkFBaUIsQ0FBQyxpQkFBRCxFQUFvQixtQkFBcEIsQ0FBakIsQ0FEbUIsQ0FBckIsQyxDQUdBOztBQUNBLE1BQU1LLGdCQUFnQixJQUFJRixNQUFKLENBQ3BCSCxpQkFBaUIsQ0FBQyxvQkFBRCxFQUF1QixzQkFBdkIsQ0FBakIsQ0FEb0IsQ0FBdEI7QUFHQSxNQUFNTSxrQkFBa0IsaUNBQXhCO0FBRUFDLHFCQUFxQixNQUFNQSxrQkFBTixDQUF5QjtBQUM1Q3JGLGNBQVlzRixZQUFaLEVBQTBCQyxjQUExQixFQUEwQztBQUN4Q3pDLGVBQVcwQyxvQkFBWCxDQUFnQ0YsWUFBaEM7QUFFQSxTQUFLQSxZQUFMLEdBQW9CQSxZQUFwQjtBQUNBLFNBQUtDLGNBQUwsR0FBc0JBLGtCQUFrQixFQUF4QztBQUNBLFNBQUtFLGFBQUwsR0FBcUIsSUFBckI7QUFDQSxTQUFLQyxRQUFMLEdBQWdCNUMsV0FBVzZDLGlCQUFYLEVBQWhCO0FBQ0EsU0FBS0MsT0FBTCxHQUFlLElBQWY7QUFDQSxTQUFLQyxRQUFMLEdBQWdCLElBQUlDLEdBQUosRUFBaEI7QUFDQSxTQUFLQyxPQUFMLEdBQWUsSUFBSUQsR0FBSixFQUFmO0FBQ0Q7O0FBRURFLG9CQUFrQmpDLFVBQWxCLEVBQThCO0FBQzVCLFVBQU1rQyxXQUFXNUUsT0FBT2hCLFdBQVAsQ0FBbUIsU0FBbkIsQ0FBakI7QUFFQTBELGlCQUFhLEtBQUttQyxnQkFBTCxDQUFzQm5DLFVBQXRCLENBQWI7O0FBRUEsU0FBS29DLGNBQUwsQ0FBb0JwQyxVQUFwQjs7QUFFQUEsaUJBQWEsS0FBS3FDLGVBQUwsQ0FBcUJyQyxVQUFyQixDQUFiOztBQUVBLFFBQUlBLFdBQVdzQyxNQUFmLEVBQXVCO0FBQ3JCLFlBQU1wRCxPQUFPYyxXQUFXLENBQVgsRUFBY2IsT0FBZCxFQUFiO0FBQ0FhLG1CQUFhLEtBQUt1QyxhQUFMLENBQW1CdkMsVUFBbkIsRUFBK0JkLElBQS9CLENBQWI7QUFDRDs7QUFFRGdELGFBQVN4RSxHQUFUO0FBRUEsV0FBT3NDLFVBQVA7QUFDRDs7QUFFRHdDLGtCQUFnQnhDLFVBQWhCLEVBQTRCO0FBQzFCLFNBQUtvQyxjQUFMLENBQW9CcEMsVUFBcEI7O0FBRUEsVUFBTXhCLFlBQVl3QixXQUFXLENBQVgsQ0FBbEI7QUFDQSxRQUFJO0FBQUV5QztBQUFGLFFBQXNCLEtBQUtkLFFBQS9CLENBSjBCLENBSzFCOztBQUNBYyxzQkFBa0JDLE9BQU9DLE1BQVAsQ0FBYyxFQUFkLEVBQWtCRixlQUFsQixDQUFsQjs7QUFDQSxRQUFJLENBQUV0RSxNQUFNSyxTQUFOLENBQUYsSUFBc0IsS0FBS2tELGFBQS9CLEVBQThDO0FBQzVDZ0IsYUFBT0MsTUFBUCxDQUFjRixlQUFkLEVBQStCLEtBQUtmLGFBQXBDO0FBQ0QsS0FUeUIsQ0FXMUI7OztBQUNBLFFBQUksS0FBS0gsWUFBVCxFQUF1QjtBQUNyQm1CLGFBQU9DLE1BQVAsQ0FBY0YsZUFBZCxFQUErQixLQUFLbEIsWUFBcEM7QUFDRDs7QUFFRCxVQUFNckMsT0FBT1YsVUFBVVcsT0FBVixFQUFiO0FBQ0EsVUFBTTtBQUFFeUQsYUFBRjtBQUFXQztBQUFYLFFBQXdCLEtBQUtsQixRQUFuQztBQUNBLFdBQU87QUFBRXpDLFVBQUY7QUFBUXVELHFCQUFSO0FBQXlCRyxhQUF6QjtBQUFrQ0M7QUFBbEMsS0FBUDtBQUNEOztBQUVEQyx3QkFBc0I5QyxVQUF0QixFQUFrQytDLGNBQWxDLEVBQWtEO0FBQ2hEeEUsZ0JBQVl5QixVQUFaLEVBQXdCMUIsU0FBeEI7QUFFQSxVQUFNMEUsVUFBVSxLQUFLUixlQUFMLENBQXFCeEMsVUFBckIsQ0FBaEI7QUFDQTFDLFdBQU9SLEdBQVAsQ0FBVyxzQkFBWCxFQUFtQ2tHLFFBQVFQLGVBQTNDO0FBRUF6QyxpQkFBYSxLQUFLaUMsaUJBQUwsQ0FBdUJqQyxVQUF2QixDQUFiO0FBRUEsUUFBSSxDQUFFQSxXQUFXc0MsTUFBakIsRUFBeUI7QUFFekIsVUFBTVcsV0FBVzNGLE9BQU9oQixXQUFQLENBQW1CLGFBQW5CLENBQWpCO0FBQ0EsVUFBTTRHLFlBQVlsRCxXQUFXbUQsR0FBWCxDQUFlQyxRQUFRaEYsZ0JBQWdCZ0YsSUFBaEIsQ0FBdkIsQ0FBbEI7QUFDQTlGLFdBQU9SLEdBQVAsQ0FBVyxtQkFBWCxFQUFnQ29HLFNBQWhDO0FBRUEsVUFBTUcsU0FBUy9GLE9BQU9oQixXQUFQLENBQW1CLFNBQW5CLENBQWY7O0FBQ0EsVUFBTWdILGFBQWEsS0FBS0MsaUJBQUwsQ0FBdUJ2RCxVQUF2QixDQUFuQjs7QUFDQSxVQUFNd0QsYUFBYTVFLFlBQ2hCbUUsa0JBQWtCQSxlQUFlbkUsUUFBZixDQUFuQixJQUFnRDBFLFdBQVcxRSxRQUFYLENBRGxEOztBQUVBLFVBQU02RSxVQUFVLElBQUk1QyxPQUFKLENBQVlxQyxTQUFaLEVBQXVCTSxVQUF2QixFQUFtQ1IsT0FBbkMsQ0FBaEI7QUFDQUssV0FBTzNGLEdBQVA7QUFFQSxVQUFNZ0csU0FBU3BHLE9BQU9oQixXQUFQLENBQW1CLGFBQW5CLENBQWY7QUFDQSxVQUFNcUgsU0FBUyxJQUFJL0MsTUFBSixFQUFmLENBdEJnRCxDQXVCaEQ7O0FBQ0EsVUFBTWdELGVBQWU1RCxXQUFXNkQsTUFBWCxDQUFrQlQsUUFBUSxDQUFFbEYsY0FBY2tGLElBQWQsQ0FBNUIsQ0FBckI7QUFDQSxVQUFNO0FBQUVYO0FBQUYsUUFBc0JPLE9BQTVCO0FBQ0F2QyxVQUFNcUQsU0FBTixDQUFnQkYsWUFBaEIsRUFBOEIsS0FBS3BDLGNBQW5DLEVBQW1ELENBQUM0QixJQUFELEVBQU9XLElBQVAsS0FBZ0I7QUFDakUsWUFBTUMsS0FBS3ZCLGVBQVg7QUFFQSxZQUFNN0QsV0FBV1IsZ0JBQWdCZ0YsSUFBaEIsQ0FBakIsQ0FIaUUsQ0FJakU7O0FBQ0EsWUFBTWEsYUFBYUQsR0FBR3BHLE1BQUgsS0FBYyxNQUFkLEdBQXVCLElBQXZCLEdBQThCUyxpQkFBaUIrRSxJQUFqQixDQUFqRDtBQUVBLFlBQU1jLFFBQVE1RyxPQUFPaEIsV0FBUCxDQUFtQixRQUFuQixDQUFkO0FBQ0EsWUFBTTZILFNBQVNWLFFBQVFXLElBQVIsQ0FBYXhGLFFBQWIsRUFBdUJxRixVQUF2QixDQUFmO0FBQ0FDLFlBQU14RyxHQUFOOztBQUVBLFlBQU0yRyxjQUFjLEtBQUtDLG1CQUFMLENBQXlCbEIsSUFBekIsRUFBK0JlLE9BQU9JLFdBQXRDLEVBQW1EUCxFQUFuRCxDQUFwQjs7QUFDQSxVQUFJLENBQUVLLFdBQU4sRUFBbUI7QUFDakIsY0FBTXpHLFNBQVM2RSxnQkFBZ0I3RSxNQUEvQjs7QUFDQSxhQUFLNEcsY0FBTCxDQUFvQnBCLElBQXBCLEVBQTBCZSxNQUExQixFQUFrQ3ZHLFdBQVcsTUFBN0M7QUFDRDs7QUFFRG1HO0FBQ0QsS0FsQkQsRUFrQkdKLE9BQU9jLFFBQVAsRUFsQkg7QUFvQkFmLFdBQU9oRyxHQUFQO0FBRUFpRyxXQUFPZSxJQUFQO0FBRUF6QixhQUFTdkYsR0FBVDtBQUNEOztBQUVENkYsb0JBQWtCdkQsVUFBbEIsRUFBOEI7QUFDNUIsVUFBTTJFLFdBQVcsSUFBSUMsR0FBSixFQUFqQjtBQUNBNUUsZUFBV0UsT0FBWCxDQUFtQixDQUFDMUIsU0FBRCxFQUFZcUcsS0FBWixLQUFzQjtBQUN2Q0YsZUFBU0csR0FBVCxDQUFhMUcsZ0JBQWdCSSxTQUFoQixDQUFiLEVBQXlDcUcsS0FBekM7QUFDRCxLQUZEO0FBSUEsV0FBT2pHLFlBQVk7QUFDakIsVUFBSWlHLFFBQVFGLFNBQVNJLEdBQVQsQ0FBYW5HLFFBQWIsQ0FBWjs7QUFDQSxVQUFJaUcsVUFBVUcsU0FBZCxFQUF5QjtBQUN2QixjQUFNQyxzQkFBc0JyRyxTQUFTVSxPQUFULENBQWlCLEtBQWpCLEVBQXdCLEVBQXhCLENBQTVCO0FBQ0F1RixnQkFBUUYsU0FBU0ksR0FBVCxDQUFhRSxtQkFBYixDQUFSO0FBQ0Q7O0FBQ0QsYUFBT0osVUFBVUcsU0FBVixHQUNMaEYsV0FBVzZFLEtBQVgsRUFBa0JLLG1CQUFsQixFQURLLEdBQ3FDLElBRDVDO0FBRUQsS0FSRDtBQVNEOztBQUVEVixpQkFBZWhHLFNBQWYsRUFBMEIyRyxRQUExQixFQUFvQ0MsU0FBcEMsRUFBK0M7QUFDN0MsVUFBTUMsU0FBUzdHLFVBQVUwRyxtQkFBVixFQUFmO0FBQ0EsVUFBTUksWUFBWTlHLFVBQVVLLGdCQUFWLEVBQWxCO0FBQ0EsVUFBTTBHLGFBQWF4RyxXQUFXVSxXQUFYLENBQXVCNkYsU0FBdkIsSUFBb0MsS0FBdkQ7QUFDQSxVQUFNRSxZQUFZO0FBQ2hCNUYsa0JBQVkwRixTQURJO0FBRWhCNUUsWUFBTTZFLFVBRlU7QUFHaEJFLFlBQU1OLFNBQVNPLElBSEM7QUFJaEJDLFlBQU1SLFNBQVNRLElBSkM7QUFLaEJDLGlCQUFXVCxTQUFTUyxTQUxKO0FBTWhCakgsWUFBTXlHLGFBQWF0SCxPQUFPVSxTQUFQO0FBTkgsS0FBbEI7QUFRQUEsY0FBVXFILGFBQVYsQ0FBd0JMLFNBQXhCO0FBQ0Q7O0FBRURsQixzQkFBb0I5RixTQUFwQixFQUErQitGLFdBQS9CLEVBQTRDdUIsU0FBNUMsRUFBdUQ7QUFDckQ7QUFDQTtBQUNBLFVBQU1DLFNBQVMsQ0FBQ0MsVUFBRCxFQUFhQyxFQUFiLEtBQW9CO0FBQ2pDLFVBQUlDLE1BQU07QUFDUm5HLGlCQUFTaUcsV0FBV2pHLE9BRFo7QUFFUkgsb0JBQVl4QixnQkFBZ0JJLFNBQWhCLENBRko7QUFHUnFCLGNBQU1tRyxXQUFXbkcsSUFIVDtBQUlSQyxnQkFBUWtHLFdBQVdsRztBQUpYLE9BQVY7QUFNQSxZQUFNWixPQUFPVixVQUFVVyxPQUFWLEVBQWIsQ0FQaUMsQ0FRakM7O0FBQ0EsV0FBSzZDLE9BQUwsQ0FBYW1FLEdBQWIsQ0FBaUJqSCxJQUFqQjtBQUVBLFVBQUlrSCxRQUFRLEtBQVo7O0FBQ0EsV0FBSyxNQUFNQyxHQUFYLElBQWtCLEtBQUtyRSxPQUFMLENBQWFzRSxJQUFiLEVBQWxCLEVBQXVDO0FBQ3JDLFlBQUlELFFBQVFuSCxJQUFaLEVBQWtCO0FBQ2hCZ0gsY0FBSWhILElBQUosR0FBV21ILEdBQVg7QUFDQSxnQkFBTVYsT0FBT25GLGVBQWUwRixHQUFmLENBQWI7O0FBQ0EsY0FBSSxLQUFLcEUsUUFBTCxDQUFjeUUsR0FBZCxDQUFrQlosSUFBbEIsQ0FBSixFQUE2QjtBQUMzQlMsb0JBQVEsSUFBUjtBQUFjO0FBQ2Y7QUFDRjtBQUNGOztBQUNELFVBQUksQ0FBRUEsS0FBTixFQUFhO0FBQ1hGLFlBQUloSCxJQUFKLEdBQVdBLElBQVg7QUFDQSxjQUFNeUcsT0FBT25GLGVBQWUwRixHQUFmLENBQWI7QUFDQSxhQUFLcEUsUUFBTCxDQUFjcUUsR0FBZCxDQUFrQlIsSUFBbEI7QUFDQU0sV0FBR0MsR0FBSDtBQUNEO0FBQ0YsS0EzQkQsQ0FIcUQsQ0FnQ3JEOzs7QUFDQSxVQUFNN0IsY0FBYyxDQUFDLENBQUVFLFlBQVlpQyxlQUFaLENBQTRCbEUsTUFBbkQ7QUFDQWlDLGdCQUFZaUMsZUFBWixDQUE0QnRHLE9BQTVCLENBQW9DOEYsY0FBYztBQUNoREQsYUFBT0MsVUFBUCxFQUFtQkUsT0FBTzFILFVBQVVtQixLQUFWLENBQWdCdUcsR0FBaEIsQ0FBMUI7QUFDRCxLQUZEO0FBSUEsVUFBTTlHLGNBQWNaLFVBQVVhLGNBQVYsRUFBcEI7QUFDQSxRQUFJRCxXQUFKLEVBQWlCLE9BQU9pRixXQUFQLENBdkNvQyxDQXlDckQ7O0FBQ0EsUUFBSXlCLGFBQWFBLFVBQVV2QixXQUEzQixFQUF3QztBQUN0Q0Esa0JBQVlrQyxjQUFaLENBQTJCdkcsT0FBM0IsQ0FBbUM4RixjQUFjO0FBQy9DRCxlQUFPQyxVQUFQLEVBQW1CRSxPQUFPMUgsVUFBVWtCLElBQVYsQ0FBZXdHLEdBQWYsQ0FBMUI7QUFDRCxPQUZEO0FBR0Q7O0FBRUQsV0FBTzdCLFdBQVA7QUFDRDs7QUFFRHFDLHFCQUFtQmxJLFNBQW5CLEVBQThCd0UsT0FBOUIsRUFBdUM7QUFDckMsUUFBSUEsUUFBUXBGLE1BQVIsS0FBbUIsTUFBdkIsRUFBK0IsT0FBTyxJQUFQO0FBRS9CLFdBQU9TLGlCQUFpQkcsU0FBakIsQ0FBUDtBQUNEOztBQUVENEQsaUJBQWVwQyxVQUFmLEVBQTJCO0FBQ3pCLFNBQUssTUFBTXhCLFNBQVgsSUFBd0J3QixVQUF4QixFQUFvQztBQUNsQztBQUNBLFVBQUlqQyxhQUFhUyxTQUFiLENBQUosRUFBNkI7QUFDM0IsY0FBTTZHLFNBQVM3RyxVQUFVMEcsbUJBQVYsRUFBZjtBQUNBLGNBQU1TLE9BQU9uSCxVQUFVbUksYUFBVixFQUFiLENBRjJCLENBRzNCOztBQUNBLFlBQUloQixTQUFTLEtBQUs5RCxPQUFsQixFQUEyQjtBQUN6QixlQUFLRixRQUFMLEdBQWdCLEtBQUtpRixZQUFMLENBQWtCdkIsTUFBbEIsQ0FBaEI7QUFDQSxlQUFLeEQsT0FBTCxHQUFlOEQsSUFBZjtBQUNEO0FBQ0YsT0FWaUMsQ0FZbEM7QUFDQTs7O0FBQ0EsVUFBSTFILGVBQWVPLFNBQWYsQ0FBSixFQUErQjtBQUM3QixjQUFPNkcsU0FBUzdHLFVBQVUwRyxtQkFBVixFQUFoQjs7QUFDQSxjQUFNO0FBQUV6QztBQUFGLFlBQXNCLEtBQUttRSxZQUFMLENBQWtCdkIsTUFBbEIsQ0FBNUI7O0FBQ0EsWUFBSTVDLGVBQUosRUFBcUI7QUFDbkIsZ0JBQU07QUFBRW9FLGtCQUFGO0FBQVVDO0FBQVYsY0FBa0JyRSxlQUF4QjtBQUNBLGVBQUtmLGFBQUwsR0FBcUI7QUFBRW1GLGtCQUFGO0FBQVVDO0FBQVYsV0FBckI7QUFDRDtBQUNGO0FBQ0Y7QUFDRjs7QUFFREYsZUFBYUcsVUFBYixFQUF5QjtBQUN2QixRQUFJcEYsV0FBVyxJQUFmOztBQUVBLFFBQUk7QUFDRkEsaUJBQVdxRixLQUFLQyxLQUFMLENBQVdGLFVBQVgsQ0FBWDtBQUVBakcsdUJBQWlCYSxRQUFqQjtBQUNELEtBSkQsQ0FJRSxPQUFNdUYsR0FBTixFQUFXO0FBQ1gsWUFBTSxJQUFJQyxLQUFKLENBQVcsc0NBQXFDRCxHQUFJLEVBQXBELENBQU47QUFDRDs7QUFFRCxVQUFNRSxVQUFVekYsU0FBU3lGLE9BQVQsSUFBb0IsRUFBcEM7O0FBQ0EsUUFBSTtBQUNGLFlBQU1DLFNBQVN0RyxpQkFBaUJxRyxPQUFqQixDQUFmO0FBQ0F6RixlQUFTeUYsT0FBVCxHQUFtQkMsVUFBVSxJQUFJbkcsTUFBSixDQUFXbUcsTUFBWCxDQUE3QjtBQUNELEtBSEQsQ0FHRSxPQUFNSCxHQUFOLEVBQVc7QUFDWCxZQUFNLElBQUlDLEtBQUosQ0FBVyx5Q0FBd0NELEdBQUksRUFBdkQsQ0FBTjtBQUNEOztBQUVELFdBQU92RixRQUFQO0FBQ0Q7O0FBRURRLG1CQUFpQm5DLFVBQWpCLEVBQTZCO0FBQzNCQSxpQkFBYUEsV0FBVzZELE1BQVgsQ0FBa0JyRixhQUFhO0FBQzFDLFlBQU1rQyxPQUFPbEMsVUFBVUssZ0JBQVYsRUFBYjtBQUNBLGFBQU93QyxnQkFBZ0J2QyxJQUFoQixDQUFxQjRCLElBQXJCLEtBQThCLENBQUVPLFdBQVduQyxJQUFYLENBQWdCLE1BQU00QixJQUF0QixDQUF2QztBQUNELEtBSFksQ0FBYjtBQUlBLFdBQU9WLFVBQVA7QUFDRDs7QUFFRHFDLGtCQUFnQnJDLFVBQWhCLEVBQTRCO0FBQzFCLFFBQUlzSCxjQUFjdEgsVUFBbEI7O0FBQ0EsUUFBSSxLQUFLMkIsUUFBTCxDQUFjeUYsT0FBbEIsRUFBMkI7QUFDekJFLG9CQUFjQSxZQUFZekQsTUFBWixDQUFtQnJGLGFBQWE7QUFDNUMsY0FBTWtDLE9BQU9sQyxVQUFVSyxnQkFBVixFQUFiLENBRDRDLENBRTVDO0FBQ0E7O0FBQ0EsZUFBTyxDQUFFLEtBQUs4QyxRQUFMLENBQWN5RixPQUFkLENBQXNCdEksSUFBdEIsQ0FBMkIsTUFBTTRCLElBQWpDLENBQVQ7QUFDRCxPQUxhLENBQWQ7QUFNRDs7QUFDRCxXQUFPNEcsV0FBUDtBQUNEOztBQUVEL0UsZ0JBQWN2QyxVQUFkLEVBQTBCZCxJQUExQixFQUFnQztBQUM5QnFJLFVBQU1ySSxJQUFOLEVBQVlzSSxNQUFaLEVBRDhCLENBRzlCOzs7OztBQUtBLFVBQU1DLGVBQWUsT0FBTzNJLElBQVAsQ0FBWUksSUFBWixJQUFvQmlDLFlBQXBCLEdBQW1DQyxhQUF4RDtBQUNBcEIsaUJBQWFBLFdBQVc2RCxNQUFYLENBQWtCckYsYUFBYTtBQUMxQyxZQUFNa0MsT0FBT2xDLFVBQVVLLGdCQUFWLEVBQWI7QUFDQSxhQUFPLENBQUU0SSxhQUFhM0ksSUFBYixDQUFrQixNQUFNNEIsSUFBeEIsQ0FBVDtBQUNELEtBSFksQ0FBYjtBQUtBLFdBQU9WLFVBQVA7QUFDRDs7QUF2UjJDLENBQTlDLEM7Ozs7Ozs7Ozs7O0FDNUNBLE1BQU0wSCxXQUFXNUwsSUFBSUMsT0FBSixDQUFZLG1CQUFaLENBQWpCOztBQUVBZ0QsYUFBYTtBQUNYNEksa0JBQWdCM0UsT0FBaEIsRUFBeUI7QUFDdkIsUUFBSSxDQUFFQSxPQUFOLEVBQWU7QUFFZjBFLGFBQVNFLHlCQUFULENBQW1DNUUsT0FBbkM7QUFDRCxHQUxVOztBQU9YO0FBQ0E7QUFDQXZCLHVCQUFxQnVCLE9BQXJCLEVBQThCO0FBQzVCLFFBQUksQ0FBRUEsT0FBTixFQUFlO0FBRWYwRSxhQUFTRSx5QkFBVCxDQUFtQztBQUNqQ25GLHVCQUFpQk87QUFEZ0IsS0FBbkM7QUFHRCxHQWZVOztBQWlCWHBCLHFCQUFtQjhGLFNBQVM5RixpQkFqQmpCOztBQW1CWGlHLFVBQVF4QyxNQUFSLEVBQWdCckMsT0FBaEIsRUFBeUI7QUFDdkJBLGNBQVVBLFdBQVcwRSxTQUFTOUYsaUJBQVQsRUFBckI7QUFDQSxXQUFPOEYsU0FBU0csT0FBVCxDQUFpQnhDLE1BQWpCLEVBQXlCckMsT0FBekIsQ0FBUDtBQUNELEdBdEJVOztBQXdCWDhFLGNBQVlDLFFBQVosRUFBc0I7QUFDcEJMLGFBQVNJLFdBQVQsQ0FBcUJDLFFBQXJCO0FBQ0QsR0ExQlU7O0FBNEJYL0ksb0JBQWtCSixRQUFsQixFQUE0QjtBQUMxQixXQUFPLGVBQWNFLElBQWQsQ0FBbUJGLFFBQW5CO0FBQVA7QUFDRCxHQTlCVTs7QUFnQ1hhLGNBQVlpQixJQUFaLEVBQWtCO0FBQ2hCLFdBQU9BLFFBQVFBLEtBQUtwQixPQUFMLENBQWEsZ0JBQWIsRUFBK0IsRUFBL0IsQ0FBZjtBQUNEOztBQWxDVSxDQUFiLEM7Ozs7Ozs7Ozs7O0FDRkExQixPQUFPQyxNQUFQLENBQWM7QUFBQzJDLGtCQUFlLE1BQUlBO0FBQXBCLENBQWQ7O0FBQUEsTUFBTTtBQUFDUTtBQUFELElBQWVsRixJQUFJQyxPQUFKLENBQVksUUFBWixDQUFyQjs7QUFFTyxTQUFTeUUsY0FBVCxDQUF3QndILEVBQXhCLEVBQTRCO0FBQ2pDLFFBQU1yQyxPQUFPM0UsV0FBVyxNQUFYLENBQWI7QUFDQSxRQUFNc0YsT0FBTzVELE9BQU80RCxJQUFQLENBQVkwQixFQUFaLENBQWI7QUFDQTFCLE9BQUsyQixJQUFMO0FBRUEzQixPQUFLcEcsT0FBTCxDQUFhbUcsT0FBTztBQUNsQlYsU0FBS3VDLE1BQUwsQ0FBWTdCLEdBQVosRUFBaUI2QixNQUFqQixDQUF3QixLQUFLRixHQUFHM0IsR0FBSCxDQUE3QjtBQUNELEdBRkQ7QUFJQSxTQUFPVixLQUFLd0MsTUFBTCxDQUFZLEtBQVosQ0FBUDtBQUNELEMiLCJmaWxlIjoiL3BhY2thZ2VzL2JhcmJhdHVzX3R5cGVzY3JpcHQtY29tcGlsZXIuanMiLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCB1dGlsID0gTnBtLnJlcXVpcmUoJ3V0aWwnKTtcblxuY2xhc3MgTG9nZ2VyXyB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHRoaXMubGxldmVsID0gcHJvY2Vzcy5lbnYuVFlQRVNDUklQVF9MT0c7XG4gIH1cblxuICBuZXdQcm9maWxlcihuYW1lKSB7XG4gICAgbGV0IHByb2ZpbGVyID0gbmV3IFByb2ZpbGVyKG5hbWUpO1xuICAgIGlmICh0aGlzLmlzUHJvZmlsZSkgcHJvZmlsZXIuc3RhcnQoKTtcbiAgICByZXR1cm4gcHJvZmlsZXI7XG4gIH1cblxuICBnZXQgaXNEZWJ1ZygpIHtcbiAgICByZXR1cm4gdGhpcy5sbGV2ZWwgPj0gMjtcbiAgfVxuXG4gIGdldCBpc1Byb2ZpbGUoKSB7XG4gICAgcmV0dXJuIHRoaXMubGxldmVsID49IDM7XG4gIH1cblxuICBnZXQgaXNBc3NlcnQoKSB7XG4gICAgcmV0dXJuIHRoaXMubGxldmVsID49IDQ7XG4gIH1cblxuICBsb2cobXNnLCAuLi5hcmdzKSB7XG4gICAgaWYgKHRoaXMubGxldmVsID49IDEpIHtcbiAgICAgIGNvbnNvbGUubG9nLmFwcGx5KG51bGwsIFttc2ddLmNvbmNhdChhcmdzKSk7XG4gICAgfVxuICB9XG5cbiAgZGVidWcobXNnLCAuLi5hcmdzKSB7XG4gICAgaWYgKHRoaXMuaXNEZWJ1Zykge1xuICAgICAgdGhpcy5sb2cuYXBwbHkodGhpcywgbXNnLCBhcmdzKTtcbiAgICB9XG4gIH1cblxuICBhc3NlcnQobXNnLCAuLi5hcmdzKSB7XG4gICAgaWYgKHRoaXMuaXNBc3NlcnQpIHtcbiAgICAgIHRoaXMubG9nLmFwcGx5KHRoaXMsIG1zZywgYXJncyk7XG4gICAgfVxuICB9XG59O1xuXG5Mb2dnZXIgPSBuZXcgTG9nZ2VyXygpO1xuXG5jbGFzcyBQcm9maWxlciB7XG4gIGNvbnN0cnVjdG9yKG5hbWUpIHtcbiAgICB0aGlzLm5hbWUgPSBuYW1lO1xuICB9XG5cbiAgc3RhcnQoKSB7XG4gICAgY29uc29sZS5sb2coJyVzIHN0YXJ0ZWQnLCB0aGlzLm5hbWUpO1xuICAgIGNvbnNvbGUudGltZSh1dGlsLmZvcm1hdCgnJXMgdGltZScsIHRoaXMubmFtZSkpO1xuICAgIHRoaXMuX3N0YXJ0ZWQgPSB0cnVlO1xuICB9XG5cbiAgZW5kKCkge1xuICAgIGlmICh0aGlzLl9zdGFydGVkKSB7XG4gICAgICBjb25zb2xlLnRpbWVFbmQodXRpbC5mb3JtYXQoJyVzIHRpbWUnLCB0aGlzLm5hbWUpKTtcbiAgICB9XG4gIH1cbn1cbiIsIlxuZXhwb3J0IGZ1bmN0aW9uIGlzQmFyZShpbnB1dEZpbGUpIHtcbiAgY29uc3QgZmlsZU9wdGlvbnMgPSBpbnB1dEZpbGUuZ2V0RmlsZU9wdGlvbnMoKTtcbiAgcmV0dXJuIGZpbGVPcHRpb25zICYmIGZpbGVPcHRpb25zLmJhcmU7XG59XG5cbi8vIEdldHMgcm9vdCBhcHAgdHNjb25maWcuXG5leHBvcnQgZnVuY3Rpb24gaXNNYWluQ29uZmlnKGlucHV0RmlsZSkge1xuICBpZiAoISBpc1dlYihpbnB1dEZpbGUpKSByZXR1cm4gZmFsc2U7XG5cbiAgY29uc3QgZmlsZVBhdGggPSBpbnB1dEZpbGUuZ2V0UGF0aEluUGFja2FnZSgpO1xuICByZXR1cm4gL150c2NvbmZpZ1xcLmpzb24kLy50ZXN0KGZpbGVQYXRoKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzQ29uZmlnKGlucHV0RmlsZSkge1xuICBjb25zdCBmaWxlUGF0aCA9IGlucHV0RmlsZS5nZXRQYXRoSW5QYWNrYWdlKCk7XG4gIHJldHVybiAvdHNjb25maWdcXC5qc29uJC8udGVzdChmaWxlUGF0aCk7XG59XG5cbi8vIEdldHMgc2VydmVyIHRzY29uZmlnLlxuZXhwb3J0IGZ1bmN0aW9uIGlzU2VydmVyQ29uZmlnKGlucHV0RmlsZSkge1xuICBpZiAoaXNXZWIoaW5wdXRGaWxlKSkgcmV0dXJuIGZhbHNlO1xuXG4gIGNvbnN0IGZpbGVQYXRoID0gaW5wdXRGaWxlLmdldFBhdGhJblBhY2thZ2UoKTtcbiAgcmV0dXJuIC9ec2VydmVyXFwvdHNjb25maWdcXC5qc29uJC8udGVzdChmaWxlUGF0aCk7XG59XG5cbi8vIENoZWNrcyBpZiBpdCdzIC5kLnRzLWZpbGUuXG5leHBvcnQgZnVuY3Rpb24gaXNEZWNsYXJhdGlvbihpbnB1dEZpbGUpIHtcbiAgcmV0dXJuIFR5cGVTY3JpcHQuaXNEZWNsYXJhdGlvbkZpbGUoaW5wdXRGaWxlLmdldEJhc2VuYW1lKCkpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gaXNXZWIoaW5wdXRGaWxlKSB7XG4gIGNvbnN0IGFyY2ggPSBpbnB1dEZpbGUuZ2V0QXJjaCgpO1xuICByZXR1cm4gL153ZWIvLnRlc3QoYXJjaCk7XG59XG5cbi8vIEdldHMgcGF0aCB3aXRoIHBhY2thZ2UgcHJlZml4IGlmIGFueS5cbmV4cG9ydCBmdW5jdGlvbiBnZXRFeHRlbmRlZFBhdGgoaW5wdXRGaWxlKSB7XG4gIGxldCBwYWNrYWdlTmFtZSA9IGlucHV0RmlsZS5nZXRQYWNrYWdlTmFtZSgpO1xuICBwYWNrYWdlTmFtZSA9IHBhY2thZ2VOYW1lID9cbiAgICAocGFja2FnZU5hbWUucmVwbGFjZSgnOicsICdfJykgKyAnLycpIDogJyc7XG4gIGNvbnN0IGlucHV0RmlsZVBhdGggPSBpbnB1dEZpbGUuZ2V0UGF0aEluUGFja2FnZSgpO1xuICByZXR1cm4gcGFja2FnZU5hbWUgKyBpbnB1dEZpbGVQYXRoO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZ2V0RVM2TW9kdWxlTmFtZShpbnB1dEZpbGUpIHtcbiAgY29uc3QgZXh0ZW5kZWQgPSBnZXRFeHRlbmRlZFBhdGgoaW5wdXRGaWxlKTtcbiAgcmV0dXJuIFR5cGVTY3JpcHQucmVtb3ZlVHNFeHQoZXh0ZW5kZWQpO1xufVxuXG5leHBvcnQgY29uc3QgV2Fybk1peGluID0ge1xuICB3YXJuOiAoZXJyb3IpID0+IHtcbiAgICBjb25zb2xlLmxvZyhgJHtlcnJvci5zb3VyY2VQYXRofSAoJHtlcnJvci5saW5lfSwgJHtlcnJvci5jb2x1bW59KTogJHtlcnJvci5tZXNzYWdlfWApO1xuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBleHRlbmRGaWxlcyhpbnB1dEZpbGVzLCBmaWxlTWl4aW4pIHtcbiAgaW5wdXRGaWxlcy5mb3JFYWNoKGlucHV0RmlsZSA9PiBfLmRlZmF1bHRzKGlucHV0RmlsZSwgZmlsZU1peGluKSk7XG59XG4iLCJjb25zdCBhc3luYyA9IE5wbS5yZXF1aXJlKCdhc3luYycpO1xuY29uc3QgcGF0aCA9IE5wbS5yZXF1aXJlKCdwYXRoJyk7XG5jb25zdCBmcyA9IE5wbS5yZXF1aXJlKCdmcycpO1xuY29uc3QgRnV0dXJlID0gTnBtLnJlcXVpcmUoJ2ZpYmVycy9mdXR1cmUnKTtcblxuY29uc3Qge1xuICBUU0J1aWxkLFxuICB2YWxpZGF0ZVRzQ29uZmlnLFxuICBnZXRFeGNsdWRlUmVnRXhwLFxufSA9IE5wbS5yZXF1aXJlKCdtZXRlb3ItdHlwZXNjcmlwdCcpO1xuXG5jb25zdCB7Y3JlYXRlSGFzaH0gPSBOcG0ucmVxdWlyZSgnY3J5cHRvJyk7XG5cbmltcG9ydCB7XG4gIGdldEV4dGVuZGVkUGF0aCxcbiAgaXNEZWNsYXJhdGlvbixcbiAgaXNDb25maWcsXG4gIGlzTWFpbkNvbmZpZyxcbiAgaXNTZXJ2ZXJDb25maWcsXG4gIGlzQmFyZSxcbiAgZ2V0RVM2TW9kdWxlTmFtZSxcbiAgV2Fybk1peGluLFxuICBleHRlbmRGaWxlcyxcbiAgaXNXZWIsXG59IGZyb20gJy4vZmlsZS11dGlscyc7XG5cbmltcG9ydCB7XG4gIGdldFNoYWxsb3dIYXNoLFxufSBmcm9tICcuL3V0aWxzJztcblxuLy8gRGVmYXVsdCBleGNsdWRlIHBhdGhzLlxuY29uc3QgZGVmRXhjbHVkZSA9IG5ldyBSZWdFeHAoXG4gIGdldEV4Y2x1ZGVSZWdFeHAoWydub2RlX21vZHVsZXMvKionXSkpO1xuXG4vLyBXaGF0IHRvIGV4Y2x1ZGUgd2hlbiBjb21waWxpbmcgZm9yIHRoZSBzZXJ2ZXIuXG5jb25zdCBleGxXZWJSZWdFeHAgPSBuZXcgUmVnRXhwKFxuICBnZXRFeGNsdWRlUmVnRXhwKFsndHlwaW5ncy9tYWluLyoqJywgJ3R5cGluZ3MvbWFpbi5kLnRzJ10pKTtcblxuLy8gV2hhdCB0byBleGNsdWRlIHdoZW4gY29tcGlsaW5nIGZvciB0aGUgY2xpZW50LlxuY29uc3QgZXhsTWFpblJlZ0V4cCA9IG5ldyBSZWdFeHAoXG4gIGdldEV4Y2x1ZGVSZWdFeHAoWyd0eXBpbmdzL2Jyb3dzZXIvKionLCAndHlwaW5ncy9icm93c2VyLmQudHMnXSkpO1xuXG5jb25zdCBDT01QSUxFUl9SRUdFWFAgPSAvKFxcLmQudHN8XFwudHN8XFwudHN4fFxcLnRzY29uZmlnKSQvO1xuXG5UeXBlU2NyaXB0Q29tcGlsZXIgPSBjbGFzcyBUeXBlU2NyaXB0Q29tcGlsZXIge1xuICBjb25zdHJ1Y3RvcihleHRyYU9wdGlvbnMsIG1heFBhcmFsbGVsaXNtKSB7XG4gICAgVHlwZVNjcmlwdC52YWxpZGF0ZUV4dHJhT3B0aW9ucyhleHRyYU9wdGlvbnMpO1xuXG4gICAgdGhpcy5leHRyYU9wdGlvbnMgPSBleHRyYU9wdGlvbnM7XG4gICAgdGhpcy5tYXhQYXJhbGxlbGlzbSA9IG1heFBhcmFsbGVsaXNtIHx8IDEwO1xuICAgIHRoaXMuc2VydmVyT3B0aW9ucyA9IG51bGw7XG4gICAgdGhpcy50c2NvbmZpZyA9IFR5cGVTY3JpcHQuZ2V0RGVmYXVsdE9wdGlvbnMoKTtcbiAgICB0aGlzLmNmZ0hhc2ggPSBudWxsO1xuICAgIHRoaXMuZGlhZ0hhc2ggPSBuZXcgU2V0O1xuICAgIHRoaXMuYXJjaFNldCA9IG5ldyBTZXQ7XG4gIH1cblxuICBnZXRGaWxlc1RvUHJvY2VzcyhpbnB1dEZpbGVzKSB7XG4gICAgY29uc3QgcGV4Y2x1ZGUgPSBMb2dnZXIubmV3UHJvZmlsZXIoJ2V4Y2x1ZGUnKTtcblxuICAgIGlucHV0RmlsZXMgPSB0aGlzLl9maWx0ZXJCeURlZmF1bHQoaW5wdXRGaWxlcyk7XG5cbiAgICB0aGlzLl9wcm9jZXNzQ29uZmlnKGlucHV0RmlsZXMpO1xuXG4gICAgaW5wdXRGaWxlcyA9IHRoaXMuX2ZpbHRlckJ5Q29uZmlnKGlucHV0RmlsZXMpO1xuXG4gICAgaWYgKGlucHV0RmlsZXMubGVuZ3RoKSB7XG4gICAgICBjb25zdCBhcmNoID0gaW5wdXRGaWxlc1swXS5nZXRBcmNoKCk7XG4gICAgICBpbnB1dEZpbGVzID0gdGhpcy5fZmlsdGVyQnlBcmNoKGlucHV0RmlsZXMsIGFyY2gpO1xuICAgIH1cblxuICAgIHBleGNsdWRlLmVuZCgpO1xuXG4gICAgcmV0dXJuIGlucHV0RmlsZXM7XG4gIH1cblxuICBnZXRCdWlsZE9wdGlvbnMoaW5wdXRGaWxlcykge1xuICAgIHRoaXMuX3Byb2Nlc3NDb25maWcoaW5wdXRGaWxlcyk7XG5cbiAgICBjb25zdCBpbnB1dEZpbGUgPSBpbnB1dEZpbGVzWzBdO1xuICAgIGxldCB7IGNvbXBpbGVyT3B0aW9ucyB9ID0gdGhpcy50c2NvbmZpZztcbiAgICAvLyBNYWtlIGEgY29weS5cbiAgICBjb21waWxlck9wdGlvbnMgPSBPYmplY3QuYXNzaWduKHt9LCBjb21waWxlck9wdGlvbnMpO1xuICAgIGlmICghIGlzV2ViKGlucHV0RmlsZSkgJiYgdGhpcy5zZXJ2ZXJPcHRpb25zKSB7XG4gICAgICBPYmplY3QuYXNzaWduKGNvbXBpbGVyT3B0aW9ucywgdGhpcy5zZXJ2ZXJPcHRpb25zKTtcbiAgICB9XG5cbiAgICAvLyBBcHBseSBleHRyYSBvcHRpb25zLlxuICAgIGlmICh0aGlzLmV4dHJhT3B0aW9ucykge1xuICAgICAgT2JqZWN0LmFzc2lnbihjb21waWxlck9wdGlvbnMsIHRoaXMuZXh0cmFPcHRpb25zKTtcbiAgICB9XG5cbiAgICBjb25zdCBhcmNoID0gaW5wdXRGaWxlLmdldEFyY2goKTtcbiAgICBjb25zdCB7IHR5cGluZ3MsIHVzZUNhY2hlIH0gPSB0aGlzLnRzY29uZmlnO1xuICAgIHJldHVybiB7IGFyY2gsIGNvbXBpbGVyT3B0aW9ucywgdHlwaW5ncywgdXNlQ2FjaGUgfTtcbiAgfVxuXG4gIHByb2Nlc3NGaWxlc0ZvclRhcmdldChpbnB1dEZpbGVzLCBnZXREZXBzQ29udGVudCkge1xuICAgIGV4dGVuZEZpbGVzKGlucHV0RmlsZXMsIFdhcm5NaXhpbik7XG5cbiAgICBjb25zdCBvcHRpb25zID0gdGhpcy5nZXRCdWlsZE9wdGlvbnMoaW5wdXRGaWxlcyk7XG4gICAgTG9nZ2VyLmxvZygnY29tcGlsZXIgb3B0aW9uczogJWonLCBvcHRpb25zLmNvbXBpbGVyT3B0aW9ucyk7XG5cbiAgICBpbnB1dEZpbGVzID0gdGhpcy5nZXRGaWxlc1RvUHJvY2VzcyhpbnB1dEZpbGVzKTtcblxuICAgIGlmICghIGlucHV0RmlsZXMubGVuZ3RoKSByZXR1cm47XG5cbiAgICBjb25zdCBwY29tcGlsZSA9IExvZ2dlci5uZXdQcm9maWxlcignY29tcGlsYXRpb24nKTtcbiAgICBjb25zdCBmaWxlUGF0aHMgPSBpbnB1dEZpbGVzLm1hcChmaWxlID0+IGdldEV4dGVuZGVkUGF0aChmaWxlKSk7XG4gICAgTG9nZ2VyLmxvZygnY29tcGlsZSBmaWxlczogJXMnLCBmaWxlUGF0aHMpO1xuXG4gICAgY29uc3QgcGJ1aWxkID0gTG9nZ2VyLm5ld1Byb2ZpbGVyKCd0c0J1aWxkJyk7XG4gICAgY29uc3QgZGVmYXVsdEdldCA9IHRoaXMuX2dldENvbnRlbnRHZXR0ZXIoaW5wdXRGaWxlcyk7XG4gICAgY29uc3QgZ2V0Q29udGVudCA9IGZpbGVQYXRoID0+XG4gICAgICAoZ2V0RGVwc0NvbnRlbnQgJiYgZ2V0RGVwc0NvbnRlbnQoZmlsZVBhdGgpKSB8fCBkZWZhdWx0R2V0KGZpbGVQYXRoKTtcbiAgICBjb25zdCB0c0J1aWxkID0gbmV3IFRTQnVpbGQoZmlsZVBhdGhzLCBnZXRDb250ZW50LCBvcHRpb25zKTtcbiAgICBwYnVpbGQuZW5kKCk7XG5cbiAgICBjb25zdCBwZmlsZXMgPSBMb2dnZXIubmV3UHJvZmlsZXIoJ3RzRW1pdEZpbGVzJyk7XG4gICAgY29uc3QgZnV0dXJlID0gbmV3IEZ1dHVyZTtcbiAgICAvLyBEb24ndCBlbWl0IHR5cGluZ3MuXG4gICAgY29uc3QgY29tcGlsZUZpbGVzID0gaW5wdXRGaWxlcy5maWx0ZXIoZmlsZSA9PiAhIGlzRGVjbGFyYXRpb24oZmlsZSkpO1xuICAgIGNvbnN0IHsgY29tcGlsZXJPcHRpb25zIH0gPSBvcHRpb25zO1xuICAgIGFzeW5jLmVhY2hMaW1pdChjb21waWxlRmlsZXMsIHRoaXMubWF4UGFyYWxsZWxpc20sIChmaWxlLCBkb25lKSA9PiB7XG4gICAgICBjb25zdCBjbyA9IGNvbXBpbGVyT3B0aW9ucztcblxuICAgICAgY29uc3QgZmlsZVBhdGggPSBnZXRFeHRlbmRlZFBhdGgoZmlsZSk7XG4gICAgICAvLyBNb2R1bGUgc2V0IG5vbmUgZXhwbGljaXRseSwgZG9uJ3QgdXNlIEVTNiBtb2R1bGVzLlxuICAgICAgY29uc3QgbW9kdWxlTmFtZSA9IGNvLm1vZHVsZSA9PT0gJ25vbmUnID8gbnVsbCA6IGdldEVTNk1vZHVsZU5hbWUoZmlsZSk7XG5cbiAgICAgIGNvbnN0IHBlbWl0ID0gTG9nZ2VyLm5ld1Byb2ZpbGVyKCd0c0VtaXQnKTtcbiAgICAgIGNvbnN0IHJlc3VsdCA9IHRzQnVpbGQuZW1pdChmaWxlUGF0aCwgbW9kdWxlTmFtZSk7XG4gICAgICBwZW1pdC5lbmQoKTtcblxuICAgICAgY29uc3QgdGhyb3dTeW50YXggPSB0aGlzLl9wcm9jZXNzRGlhZ25vc3RpY3MoZmlsZSwgcmVzdWx0LmRpYWdub3N0aWNzLCBjbyk7XG4gICAgICBpZiAoISB0aHJvd1N5bnRheCkge1xuICAgICAgICBjb25zdCBtb2R1bGUgPSBjb21waWxlck9wdGlvbnMubW9kdWxlO1xuICAgICAgICB0aGlzLl9hZGRKYXZhU2NyaXB0KGZpbGUsIHJlc3VsdCwgbW9kdWxlID09PSAnbm9uZScpO1xuICAgICAgfVxuXG4gICAgICBkb25lKCk7XG4gICAgfSwgZnV0dXJlLnJlc29sdmVyKCkpO1xuXG4gICAgcGZpbGVzLmVuZCgpO1xuXG4gICAgZnV0dXJlLndhaXQoKTtcblxuICAgIHBjb21waWxlLmVuZCgpO1xuICB9XG5cbiAgX2dldENvbnRlbnRHZXR0ZXIoaW5wdXRGaWxlcykge1xuICAgIGNvbnN0IGZpbGVzTWFwID0gbmV3IE1hcDtcbiAgICBpbnB1dEZpbGVzLmZvckVhY2goKGlucHV0RmlsZSwgaW5kZXgpID0+IHtcbiAgICAgIGZpbGVzTWFwLnNldChnZXRFeHRlbmRlZFBhdGgoaW5wdXRGaWxlKSwgaW5kZXgpO1xuICAgIH0pO1xuXG4gICAgcmV0dXJuIGZpbGVQYXRoID0+IHtcbiAgICAgIGxldCBpbmRleCA9IGZpbGVzTWFwLmdldChmaWxlUGF0aCk7XG4gICAgICBpZiAoaW5kZXggPT09IHVuZGVmaW5lZCkge1xuICAgICAgICBjb25zdCBmaWxlUGF0aE5vUm9vdFNsYXNoID0gZmlsZVBhdGgucmVwbGFjZSgvXlxcLy8sICcnKTtcbiAgICAgICAgaW5kZXggPSBmaWxlc01hcC5nZXQoZmlsZVBhdGhOb1Jvb3RTbGFzaCk7XG4gICAgICB9XG4gICAgICByZXR1cm4gaW5kZXggIT09IHVuZGVmaW5lZCA/XG4gICAgICAgIGlucHV0RmlsZXNbaW5kZXhdLmdldENvbnRlbnRzQXNTdHJpbmcoKSA6IG51bGw7XG4gICAgfTtcbiAgfVxuXG4gIF9hZGRKYXZhU2NyaXB0KGlucHV0RmlsZSwgdHNSZXN1bHQsIGZvcmNlQmFyZSkge1xuICAgIGNvbnN0IHNvdXJjZSA9IGlucHV0RmlsZS5nZXRDb250ZW50c0FzU3RyaW5nKCk7XG4gICAgY29uc3QgaW5wdXRQYXRoID0gaW5wdXRGaWxlLmdldFBhdGhJblBhY2thZ2UoKTtcbiAgICBjb25zdCBvdXRwdXRQYXRoID0gVHlwZVNjcmlwdC5yZW1vdmVUc0V4dChpbnB1dFBhdGgpICsgJy5qcyc7XG4gICAgY29uc3QgdG9CZUFkZGVkID0ge1xuICAgICAgc291cmNlUGF0aDogaW5wdXRQYXRoLFxuICAgICAgcGF0aDogb3V0cHV0UGF0aCxcbiAgICAgIGRhdGE6IHRzUmVzdWx0LmNvZGUsXG4gICAgICBoYXNoOiB0c1Jlc3VsdC5oYXNoLFxuICAgICAgc291cmNlTWFwOiB0c1Jlc3VsdC5zb3VyY2VNYXAsXG4gICAgICBiYXJlOiBmb3JjZUJhcmUgfHwgaXNCYXJlKGlucHV0RmlsZSlcbiAgICB9O1xuICAgIGlucHV0RmlsZS5hZGRKYXZhU2NyaXB0KHRvQmVBZGRlZCk7XG4gIH1cblxuICBfcHJvY2Vzc0RpYWdub3N0aWNzKGlucHV0RmlsZSwgZGlhZ25vc3RpY3MsIHRzT3B0aW9ucykge1xuICAgIC8vIFJlbW92ZSBkdXBsaWNhdGVkIHdhcm5pbmdzIGZvciBzaGFyZWQgZmlsZXNcbiAgICAvLyBieSBzYXZpbmcgaGFzaGVzIG9mIGFscmVhZHkgc2hvd24gd2FybmluZ3MuXG4gICAgY29uc3QgcmVkdWNlID0gKGRpYWdub3N0aWMsIGNiKSA9PiB7XG4gICAgICBsZXQgZG9iID0ge1xuICAgICAgICBtZXNzYWdlOiBkaWFnbm9zdGljLm1lc3NhZ2UsXG4gICAgICAgIHNvdXJjZVBhdGg6IGdldEV4dGVuZGVkUGF0aChpbnB1dEZpbGUpLFxuICAgICAgICBsaW5lOiBkaWFnbm9zdGljLmxpbmUsXG4gICAgICAgIGNvbHVtbjogZGlhZ25vc3RpYy5jb2x1bW5cbiAgICAgIH07XG4gICAgICBjb25zdCBhcmNoID0gaW5wdXRGaWxlLmdldEFyY2goKTtcbiAgICAgIC8vIFRPRE86IGZpbmQgb3V0IGhvdyB0byBnZXQgbGlzdCBvZiBhcmNoaXRlY3R1cmVzLlxuICAgICAgdGhpcy5hcmNoU2V0LmFkZChhcmNoKTtcblxuICAgICAgbGV0IHNob3duID0gZmFsc2U7XG4gICAgICBmb3IgKGNvbnN0IGtleSBvZiB0aGlzLmFyY2hTZXQua2V5cygpKSB7XG4gICAgICAgIGlmIChrZXkgIT09IGFyY2gpIHtcbiAgICAgICAgICBkb2IuYXJjaCA9IGtleTtcbiAgICAgICAgICBjb25zdCBoYXNoID0gZ2V0U2hhbGxvd0hhc2goZG9iKTtcbiAgICAgICAgICBpZiAodGhpcy5kaWFnSGFzaC5oYXMoaGFzaCkpIHtcbiAgICAgICAgICAgIHNob3duID0gdHJ1ZTsgYnJlYWs7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICBpZiAoISBzaG93bikge1xuICAgICAgICBkb2IuYXJjaCA9IGFyY2g7XG4gICAgICAgIGNvbnN0IGhhc2ggPSBnZXRTaGFsbG93SGFzaChkb2IpO1xuICAgICAgICB0aGlzLmRpYWdIYXNoLmFkZChoYXNoKTtcbiAgICAgICAgY2IoZG9iKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBBbHdheXMgdGhyb3cgc3ludGF4IGVycm9ycy5cbiAgICBjb25zdCB0aHJvd1N5bnRheCA9ICEhIGRpYWdub3N0aWNzLnN5bnRhY3RpY0Vycm9ycy5sZW5ndGg7XG4gICAgZGlhZ25vc3RpY3Muc3ludGFjdGljRXJyb3JzLmZvckVhY2goZGlhZ25vc3RpYyA9PiB7XG4gICAgICByZWR1Y2UoZGlhZ25vc3RpYywgZG9iID0+IGlucHV0RmlsZS5lcnJvcihkb2IpKTtcbiAgICB9KTtcblxuICAgIGNvbnN0IHBhY2thZ2VOYW1lID0gaW5wdXRGaWxlLmdldFBhY2thZ2VOYW1lKCk7XG4gICAgaWYgKHBhY2thZ2VOYW1lKSByZXR1cm4gdGhyb3dTeW50YXg7XG5cbiAgICAvLyBBbmQgbG9nIG91dCBvdGhlciBlcnJvcnMgZXhjZXB0IHBhY2thZ2UgZmlsZXMuXG4gICAgaWYgKHRzT3B0aW9ucyAmJiB0c09wdGlvbnMuZGlhZ25vc3RpY3MpIHtcbiAgICAgIGRpYWdub3N0aWNzLnNlbWFudGljRXJyb3JzLmZvckVhY2goZGlhZ25vc3RpYyA9PiB7XG4gICAgICAgIHJlZHVjZShkaWFnbm9zdGljLCBkb2IgPT4gaW5wdXRGaWxlLndhcm4oZG9iKSk7XG4gICAgICB9KTtcbiAgICB9XG5cbiAgICByZXR1cm4gdGhyb3dTeW50YXg7XG4gIH1cblxuICBfZ2V0RmlsZU1vZHVsZU5hbWUoaW5wdXRGaWxlLCBvcHRpb25zKSB7XG4gICAgaWYgKG9wdGlvbnMubW9kdWxlID09PSAnbm9uZScpIHJldHVybiBudWxsO1xuXG4gICAgcmV0dXJuIGdldEVTNk1vZHVsZU5hbWUoaW5wdXRGaWxlKTtcbiAgfVxuXG4gIF9wcm9jZXNzQ29uZmlnKGlucHV0RmlsZXMpIHtcbiAgICBmb3IgKGNvbnN0IGlucHV0RmlsZSBvZiBpbnB1dEZpbGVzKSB7XG4gICAgICAvLyBQYXJzZSByb290IGNvbmZpZy5cbiAgICAgIGlmIChpc01haW5Db25maWcoaW5wdXRGaWxlKSkge1xuICAgICAgICBjb25zdCBzb3VyY2UgPSBpbnB1dEZpbGUuZ2V0Q29udGVudHNBc1N0cmluZygpO1xuICAgICAgICBjb25zdCBoYXNoID0gaW5wdXRGaWxlLmdldFNvdXJjZUhhc2goKTtcbiAgICAgICAgLy8gSWYgaGFzaGVzIGRpZmZlciwgY3JlYXRlIG5ldyB0c2NvbmZpZy4gXG4gICAgICAgIGlmIChoYXNoICE9PSB0aGlzLmNmZ0hhc2gpIHtcbiAgICAgICAgICB0aGlzLnRzY29uZmlnID0gdGhpcy5fcGFyc2VDb25maWcoc291cmNlKTtcbiAgICAgICAgICB0aGlzLmNmZ0hhc2ggPSBoYXNoO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIC8vIFBhcnNlIHNlcnZlciBjb25maWcuXG4gICAgICAvLyBUYWtlIG9ubHkgdGFyZ2V0IGFuZCBsaWIgdmFsdWVzLlxuICAgICAgaWYgKGlzU2VydmVyQ29uZmlnKGlucHV0RmlsZSkpIHtcbiAgICAgICAgY29uc3QgIHNvdXJjZSA9IGlucHV0RmlsZS5nZXRDb250ZW50c0FzU3RyaW5nKCk7XG4gICAgICAgIGNvbnN0IHsgY29tcGlsZXJPcHRpb25zIH0gPSB0aGlzLl9wYXJzZUNvbmZpZyhzb3VyY2UpO1xuICAgICAgICBpZiAoY29tcGlsZXJPcHRpb25zKSB7XG4gICAgICAgICAgY29uc3QgeyB0YXJnZXQsIGxpYiB9ID0gY29tcGlsZXJPcHRpb25zO1xuICAgICAgICAgIHRoaXMuc2VydmVyT3B0aW9ucyA9IHsgdGFyZ2V0LCBsaWIgfTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIF9wYXJzZUNvbmZpZyhjZmdDb250ZW50KSB7XG4gICAgbGV0IHRzY29uZmlnID0gbnVsbDtcblxuICAgIHRyeSB7XG4gICAgICB0c2NvbmZpZyA9IEpTT04ucGFyc2UoY2ZnQ29udGVudCk7XG5cbiAgICAgIHZhbGlkYXRlVHNDb25maWcodHNjb25maWcpO1xuICAgIH0gY2F0Y2goZXJyKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYEZvcm1hdCBvZiB0aGUgdHNjb25maWcgaXMgaW52YWxpZDogJHtlcnJ9YCk7XG4gICAgfVxuXG4gICAgY29uc3QgZXhjbHVkZSA9IHRzY29uZmlnLmV4Y2x1ZGUgfHwgW107XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlZ0V4cCA9IGdldEV4Y2x1ZGVSZWdFeHAoZXhjbHVkZSk7XG4gICAgICB0c2NvbmZpZy5leGNsdWRlID0gcmVnRXhwICYmIG5ldyBSZWdFeHAocmVnRXhwKTtcbiAgICB9IGNhdGNoKGVycikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKGBGb3JtYXQgb2YgYW4gZXhjbHVkZSBwYXRoIGlzIGludmFsaWQ6ICR7ZXJyfWApO1xuICAgIH1cblxuICAgIHJldHVybiB0c2NvbmZpZztcbiAgfVxuXG4gIF9maWx0ZXJCeURlZmF1bHQoaW5wdXRGaWxlcykge1xuICAgIGlucHV0RmlsZXMgPSBpbnB1dEZpbGVzLmZpbHRlcihpbnB1dEZpbGUgPT4ge1xuICAgICAgY29uc3QgcGF0aCA9IGlucHV0RmlsZS5nZXRQYXRoSW5QYWNrYWdlKCk7XG4gICAgICByZXR1cm4gQ09NUElMRVJfUkVHRVhQLnRlc3QocGF0aCkgJiYgISBkZWZFeGNsdWRlLnRlc3QoJy8nICsgcGF0aCk7XG4gICAgfSk7XG4gICAgcmV0dXJuIGlucHV0RmlsZXM7XG4gIH1cblxuICBfZmlsdGVyQnlDb25maWcoaW5wdXRGaWxlcykge1xuICAgIGxldCByZXN1bHRGaWxlcyA9IGlucHV0RmlsZXM7XG4gICAgaWYgKHRoaXMudHNjb25maWcuZXhjbHVkZSkge1xuICAgICAgcmVzdWx0RmlsZXMgPSByZXN1bHRGaWxlcy5maWx0ZXIoaW5wdXRGaWxlID0+IHtcbiAgICAgICAgY29uc3QgcGF0aCA9IGlucHV0RmlsZS5nZXRQYXRoSW5QYWNrYWdlKCk7XG4gICAgICAgIC8vIFRoZXJlIHNlZW1zIHRvIGFuIGlzc3VlIHdpdGggZ2V0UmVndWxhckV4cHJlc3Npb25Gb3JXaWxkY2FyZDpcbiAgICAgICAgLy8gcmVzdWx0IHJlZ2V4cCBhbHdheXMgc3RhcnRzIHdpdGggLy5cbiAgICAgICAgcmV0dXJuICEgdGhpcy50c2NvbmZpZy5leGNsdWRlLnRlc3QoJy8nICsgcGF0aCk7XG4gICAgICB9KTtcbiAgICB9XG4gICAgcmV0dXJuIHJlc3VsdEZpbGVzO1xuICB9XG5cbiAgX2ZpbHRlckJ5QXJjaChpbnB1dEZpbGVzLCBhcmNoKSB7XG4gICAgY2hlY2soYXJjaCwgU3RyaW5nKTtcblxuICAgIC8qKlxuICAgICAqIEluY2x1ZGUgb25seSB0eXBpbmdzIHRoYXQgY3VycmVudCBhcmNoIG5lZWRzLFxuICAgICAqIHR5cGluZ3MvbWFpbiBpcyBmb3IgdGhlIHNlcnZlciBvbmx5IGFuZFxuICAgICAqIHR5cGluZ3MvYnJvd3NlciAtIGZvciB0aGUgY2xpZW50LlxuICAgICAqL1xuICAgIGNvbnN0IGZpbHRlclJlZ0V4cCA9IC9ed2ViLy50ZXN0KGFyY2gpID8gZXhsV2ViUmVnRXhwIDogZXhsTWFpblJlZ0V4cDtcbiAgICBpbnB1dEZpbGVzID0gaW5wdXRGaWxlcy5maWx0ZXIoaW5wdXRGaWxlID0+IHtcbiAgICAgIGNvbnN0IHBhdGggPSBpbnB1dEZpbGUuZ2V0UGF0aEluUGFja2FnZSgpO1xuICAgICAgcmV0dXJuICEgZmlsdGVyUmVnRXhwLnRlc3QoJy8nICsgcGF0aCk7XG4gICAgfSk7XG5cbiAgICByZXR1cm4gaW5wdXRGaWxlcztcbiAgfVxufVxuIiwiY29uc3QgbWV0ZW9yVFMgPSBOcG0ucmVxdWlyZSgnbWV0ZW9yLXR5cGVzY3JpcHQnKTtcblxuVHlwZVNjcmlwdCA9IHtcbiAgdmFsaWRhdGVPcHRpb25zKG9wdGlvbnMpIHtcbiAgICBpZiAoISBvcHRpb25zKSByZXR1cm47XG5cbiAgICBtZXRlb3JUUy52YWxpZGF0ZUFuZENvbnZlcnRPcHRpb25zKG9wdGlvbnMpO1xuICB9LFxuXG4gIC8vIEV4dHJhIG9wdGlvbnMgYXJlIHRoZSBzYW1lIGNvbXBpbGVyIG9wdGlvbnNcbiAgLy8gYnV0IHBhc3NlZCBpbiB0aGUgY29tcGlsZXIgY29uc3RydWN0b3IuXG4gIHZhbGlkYXRlRXh0cmFPcHRpb25zKG9wdGlvbnMpIHtcbiAgICBpZiAoISBvcHRpb25zKSByZXR1cm47XG5cbiAgICBtZXRlb3JUUy52YWxpZGF0ZUFuZENvbnZlcnRPcHRpb25zKHtcbiAgICAgIGNvbXBpbGVyT3B0aW9uczogb3B0aW9uc1xuICAgIH0pO1xuICB9LFxuXG4gIGdldERlZmF1bHRPcHRpb25zOiBtZXRlb3JUUy5nZXREZWZhdWx0T3B0aW9ucyxcblxuICBjb21waWxlKHNvdXJjZSwgb3B0aW9ucykge1xuICAgIG9wdGlvbnMgPSBvcHRpb25zIHx8IG1ldGVvclRTLmdldERlZmF1bHRPcHRpb25zKCk7XG4gICAgcmV0dXJuIG1ldGVvclRTLmNvbXBpbGUoc291cmNlLCBvcHRpb25zKTtcbiAgfSxcblxuICBzZXRDYWNoZURpcihjYWNoZURpcikge1xuICAgIG1ldGVvclRTLnNldENhY2hlRGlyKGNhY2hlRGlyKTtcbiAgfSxcblxuICBpc0RlY2xhcmF0aW9uRmlsZShmaWxlUGF0aCkge1xuICAgIHJldHVybiAvXi4qXFwuZFxcLnRzJC8udGVzdChmaWxlUGF0aCk7XG4gIH0sXG5cbiAgcmVtb3ZlVHNFeHQocGF0aCkge1xuICAgIHJldHVybiBwYXRoICYmIHBhdGgucmVwbGFjZSgvKFxcLnRzeHxcXC50cykkL2csICcnKTtcbiAgfVxufTtcbiIsImNvbnN0IHtjcmVhdGVIYXNofSA9IE5wbS5yZXF1aXJlKCdjcnlwdG8nKTtcblxuZXhwb3J0IGZ1bmN0aW9uIGdldFNoYWxsb3dIYXNoKG9iKSB7XG4gIGNvbnN0IGhhc2ggPSBjcmVhdGVIYXNoKCdzaGExJyk7XG4gIGNvbnN0IGtleXMgPSBPYmplY3Qua2V5cyhvYik7XG4gIGtleXMuc29ydCgpO1xuXG4gIGtleXMuZm9yRWFjaChrZXkgPT4ge1xuICAgIGhhc2gudXBkYXRlKGtleSkudXBkYXRlKCcnICsgb2Jba2V5XSk7XG4gIH0pO1xuXG4gIHJldHVybiBoYXNoLmRpZ2VzdCgnaGV4Jyk7XG59XG4iXX0=
